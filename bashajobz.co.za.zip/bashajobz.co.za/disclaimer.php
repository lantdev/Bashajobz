<?php
// disclaimer.php - Disclaimer Page for www.bashajobz.co.za

// No direct database connection needed for this static content,
// but including it for consistency with other pages that might
// require it or share session logic (e.g., for header/footer).
$db = mysqli_connect('localhost', 'prolance_prolance', '@Airbus360', 'prolance_bashajobz');
if (!$db) {
    error_log("Website DB Connection Failed: " . mysqli_connect_error());
    // Display a general message to the user if DB connection fails
    $db_connection_error = "We are currently experiencing technical difficulties. Please try again later.";
} else {
    $db_connection_error = null;
    mysqli_close($db); // Close immediately if not used for this page
}

// SEO Meta Tags
$pageTitle = "Disclaimer | Bashajobz";
$pageDescription = "Read the disclaimer notice for Bashajobz. Understand the limitations of liability and accuracy of information provided on our job portal.";
$pageKeywords = "disclaimer, Bashajobz disclaimer, legal notice, website liability, accuracy of information";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($pageKeywords); ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://www.bashajobz.co.za/disclaimer.php">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
          <link rel="icon" href="https://bashajobz.co.za/logo.png" type="image/x-icon">
          <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="apple-touch-icon" sizes="57x57" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://www.bashajobz.co.za/logo.png">
    <style>
        /* General Body and Layout (consistent with other pages) */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #f4f6f9;
            color: #333;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            overflow-x: hidden; /* Prevent horizontal scrolling */
            box-sizing: border-box;
        }

        /* Header/Navbar (Copied for consistency) */
        .main-header {
            background-color: #fff;
            padding: 15px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            width: 100%;
            z-index: 1000;
            box-sizing: border-box;
        }

        .main-header .logo {
            display: flex;
            align-items: center;
        }

        .header-logo {
            height: 50px;
            width: auto;
            max-width: 150px;
            border-radius: 4px;
            object-fit: contain;
            filter: drop-shadow(0 0 2px rgba(0,0,0,0.1));
        }

        .main-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
        }

        .main-nav ul li {
            margin-left: 20px;
        }

        .main-nav ul li a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            padding: 5px 10px;
            transition: color 0.3s ease;
        }

        .main-nav ul li a:hover {
            color: #e67e22; /* Orange hover color */
        }

        .main-nav ul li.signup-btn a {
            background-color: #e67e22; /* Orange button */
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .main-nav ul li.signup-btn a:hover {
            background-color: #d35400; /* Darker orange */
            color: white;
        }
        
        .hamburger-menu {
            display: none;
            font-size: 1.8em;
            cursor: pointer;
            color: #333;
            z-index: 1001;
        }

        .mobile-nav-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background-color: #fff;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            z-index: 998;
            padding: 10px 0;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            overflow-y: auto;
            max-height: calc(100vh - 70px);
            box-sizing: border-box;
            transform: translateY(-10px);
            opacity: 0;
            visibility: hidden;
            transition: transform 0.3s ease-out, opacity 0.3s ease-out, visibility 0.3s ease-out;
        }

        .mobile-nav-dropdown.open {
            display: block;
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }

        .mobile-nav-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center;
            width: 100%;
        }

        .mobile-nav-dropdown ul li {
            margin: 0;
            border-bottom: 1px solid #eee;
        }

        .mobile-nav-dropdown ul li:last-child {
            border-bottom: none;
        }

        .mobile-nav-dropdown ul li a {
            color: #333;
            text-decoration: none;
            font-size: 1.1em;
            padding: 12px 20px;
            display: block;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-weight: 500;
        }

        .mobile-nav-dropdown ul li a:hover {
            background-color: #f0f0f0;
            color: #e67e22; /* Orange hover color */
        }

        .mobile-nav-dropdown ul li.signup-btn a {
            background-color: #e67e22; /* Orange button */
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            margin-top: 10px;
            margin-bottom: 10px;
            width: fit-content;
            margin-left: auto;
            margin-right: auto;
            display: block;
            max-width: 250px;
        }
        .mobile-nav-dropdown ul li.signup-btn a:hover {
            background-color: #d35400; /* Darker orange */
        }

        body.no-scroll {
            overflow: hidden;
        }

        /* --- Disclaimer Page Specific Styles --- */
        .disclaimer-hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://placehold.co/1920x400/2c3e50/ffffff?text=Disclaimer+Banner') no-repeat center center/cover;
            color: white;
            padding: 80px 20px;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            box-sizing: border-box;
        }

        .disclaimer-hero-section h1 {
            font-size: 2.8em;
            margin-bottom: 15px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .disclaimer-hero-section p {
            font-size: 1.1em;
            margin-bottom: 30px;
            max-width: 700px;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .disclaimer-content-container {
            max-width: 900px;
            margin: 40px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            box-sizing: border-box;
        }

        .disclaimer-content-container h1.main-heading { /* Specific style for the main disclaimer title */
            font-size: 2.5em;
            color: #2c3e50;
            margin-bottom: 20px;
            text-align: center;
            border-bottom: 2px solid #e67e22; /* Orange underline */
            padding-bottom: 15px;
            display: inline-block;
            width: fit-content;
            max-width: 100%;
            margin-left: auto;
            margin-right: auto;
        }

        .disclaimer-content-container h2 {
            font-size: 1.8em;
            color: #e67e22; /* Orange for section headings */
            margin-top: 30px;
            margin-bottom: 15px;
            border-left: 5px solid #2c3e50; /* Dark sidebar color for accent */
            padding-left: 10px;
        }

        .disclaimer-content-container p {
            font-size: 1em;
            line-height: 1.8;
            margin-bottom: 1em;
        }

        .disclaimer-content-container ul {
            list-style: disc; /* Use standard disc bullets */
            padding-left: 25px;
            margin-bottom: 1em;
        }

        .disclaimer-content-container ol {
            list-style: decimal; /* Use standard decimal numbering */
            padding-left: 25px;
            margin-bottom: 1em;
        }

        .disclaimer-content-container li {
            margin-bottom: 0.5em;
        }

        .disclaimer-content-container a {
            color: #e67e22; /* Orange for links within text */
            text-decoration: underline;
            transition: color 0.3s ease;
        }
        .disclaimer-content-container a:hover {
            color: #d35400;
        }

        .disclaimer-last-updated {
            text-align: right;
            font-size: 0.9em;
            color: #777;
            margin-top: 30px;
            border-top: 1px solid #eee;
            padding-top: 15px;
        }

        /* Error Message (consistent) */
        .error-message {
            text-align: center;
            padding: 30px;
            font-size: 1.1em;
            color: #c0392b;
            background-color: #ffebee;
            border: 1px solid #e74c3c;
            border-radius: 8px;
            margin: 30px auto;
            max-width: 600px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        .error-message i {
            margin-right: 10px;
            color: #e74c3c;
        }


        /* Responsive adjustments */
        @media (max-width: 768px) {
            .main-header {
                padding: 15px;
                position: relative;
            }
            .hamburger-menu {
                display: block;
            }
            .main-nav {
                display: none;
            }

            .disclaimer-hero-section {
                padding: 60px 15px;
            }
            .disclaimer-hero-section h1 {
                font-size: 2em;
            }
            .disclaimer-hero-section p {
                font-size: 0.9em;
            }

            .disclaimer-content-container {
                margin: 20px auto;
                padding: 20px;
                border-radius: 8px;
            }

            .disclaimer-content-container h1.main-heading {
                font-size: 1.8em;
            }

            .disclaimer-content-container h2 {
                font-size: 1.5em;
            }

            .disclaimer-content-container p,
            .disclaimer-content-container ul,
            .disclaimer-content-container ol {
                font-size: 0.95em;
            }
            .error-message {
                padding: 20px;
                font-size: 1em;
                margin: 20px auto;
            }
        }

        /* Further minor adjustments for very small screens (e.g., less than 400px) */
        @media (max-width: 400px) {
            .disclaimer-content-container {
                padding: 15px;
            }
            .disclaimer-hero-section h1 {
                font-size: 1.6em;
            }
            .disclaimer-hero-section p {
                font-size: 0.85em;
            }
            .disclaimer-content-container h1.main-heading {
                font-size: 1.5em;
            }
            .disclaimer-content-container h2 {
                font-size: 1.3em;
            }
            .disclaimer-content-container p,
            .disclaimer-content-container ul,
            .disclaimer-content-container ol {
                font-size: 0.9em;
            }
        }
    </style>
</head>
<body>
    <header class="main-header">
        <a href="index.php" class="logo">
            <img src="logo.png" alt="Bashjobz Logo" class="header-logo" onerror="this.onerror=null;this.src='https://placehold.co/150x50/cccccc/333333?text=Bashajobz';">
        </a>
        <nav class="main-nav">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="jobs.php">Jobs</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="news.php">News</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="cv_services.php">CV Revamp Services</a></li>
                <li><a href="login.php">Login</a></li>
                <li class="signup-btn"><a href="signup.php">Sign Up</a></li>
            </ul>
        </nav>
        <div class="hamburger-menu" onclick="toggleMobileMenu()">
            <i class="fas fa-bars" id="hamburgerIcon"></i>
        </div>

        <!-- Mobile Navigation Dropdown -->
        <nav class="mobile-nav-dropdown" id="mobileNavDropdown">
            <ul>
                <li><a href="index.php" onclick="toggleMobileMenu()">Home</a></li>
                <li><a href="jobs.php" onclick="toggleMobileMenu()">Jobs</a></li>
                <li><a href="blog.php" onclick="toggleMobileMenu()">Blog</a></li>
                <li><a href="news.php" onclick="toggleMobileMenu()">News</a></li>
                <li><a href="contact.php" onclick="toggleMobileMenu()">Contact</a></li>
                <li><a href="cv_services.php" onclick="toggleMobileMenu()">CV Revamp Services</a></li>
                <li><a href="login.php" onclick="toggleMobileMenu()">Login</a></li>
                <li class="signup-btn"><a href="signup.php" onclick="toggleMobileMenu()">Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <?php if ($db_connection_error): ?>
            <div class="error-message">
                <p><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($db_connection_error); ?></p>
            </div>
        <?php endif; ?>

        <section class="disclaimer-hero-section">
            <h1>Disclaimer</h1>
            <p>Important information regarding the use of Bashajobz.</p>
        </section>

        <section class="disclaimer-content-container">
            <h1 class="main-heading">Disclaimer for Bashajobz</h1>

            <p><strong>Last updated: June 25, 2025</strong></p>

            <p>If you require any more information or have any questions about our site's disclaimer, please feel free to contact us by email at info@bashajobz.co.za.</p>

            <h2>Disclaimers for Bashajobz</h2>
            <p>All the information on this website - www.bashajobz.co.za - is published in good faith and for general information purpose only. Bashajobz does not make any warranties about the completeness, reliability and accuracy of this information. Any action you take upon the information you find on this website (Bashajobz), is strictly at your own risk. Bashajobz will not be liable for any losses and/or damages in connection with the use of our website.</p>

            <p>From our website, you can visit other websites by following hyperlinks to such external sites. While we strive to provide only quality links to useful and ethical websites, we have no control over the content and nature of these sites. These links to other websites do not imply a recommendation for all the content found on these sites. Site owners and content may change without notice and may occur before we have the opportunity to remove a link which may have gone 'bad'.</p>

            <p>Please be also aware that when you leave our website, other sites may have different privacy policies and terms which are beyond our control. Please be sure to check the Privacy Policies of these sites as well as their "Terms of Service" before engaging in any business or uploading any information.</p>

            <h2>Consent</h2>
            <p>By using our website, you hereby consent to our disclaimer and agree to its terms.</p>

            <h2>Update</h2>
            <p>Should we update, amend or make any changes to this document, those changes will be prominently posted here.</p>

            <div class="disclaimer-last-updated">
                <p>Generated by Bashajobz.co.za on June 25, 2025.</p>
            </div>
        </section>
    </main>

    <?php
    // Include the reusable footer component
    include 'footer.php';
    ?>

    <script>
        function toggleMobileMenu() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerIcon = document.getElementById('hamburgerIcon');

            mobileNavDropdown.classList.toggle('open');
            if (mobileNavDropdown.classList.contains('open')) {
                hamburgerIcon.classList.remove('fa-bars');
                hamburgerIcon.classList.add('fa-times');
            } else {
                hamburgerIcon.classList.remove('fa-times');
                hamburgerIcon.classList.add('fa-bars');
            }
        }

        document.addEventListener('click', function(event) {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerMenu = document.querySelector('.hamburger-menu');

            if (mobileNavDropdown.classList.contains('open') && 
                !mobileNavDropdown.contains(event.target) && 
                !hamburgerMenu.contains(event.target)) {
                toggleMobileMenu();
            }
        });

        window.addEventListener('resize', function() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            if (window.innerWidth > 768 && mobileNavDropdown.classList.contains('open')) {
                toggleMobileMenu();
            }
        });
    </script>

</body>
</html>
