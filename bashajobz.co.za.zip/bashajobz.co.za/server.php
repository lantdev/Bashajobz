<?php
session_start();

$FirstName = "";
$LastName = "";
$Email = "";
$CountryCode = "+27"; // Default for South Africa
$PhoneNumber = "";
$errors = array();
$_SESSION['success'] = "";

// Database connection details from previous context (Bashjobz DB)
// It's highly recommended to move these credentials to a separate, secure config file
// e.g., require_once 'path/to/your/config.php';
$db_host = 'localhost';
$db_user = 'prolance_prolance';
$db_pass = '@Airbus360';
$db_name = 'prolance_bashajobz'; // Assuming this is the correct database for users table

$db = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check database connection
if ($db->connect_error) {
    error_log("Bashjobz User DB Connection Failed: " . $db->connect_error);
    array_push($errors, "Database connection failed. Please try again later.");
}

// Your reCAPTCHA secret key (ensure this is your actual secret key for Bashjobz)
$secretKey = "6LchJW4rAAAAALUIAev685QrrU4UbMzFy4OyvUjY"; // This looks like a TholaIndawo key, ensure it's correct for Bashjobz

// Check if the form is submitted
if (isset($_POST['register'])) {
    // Sanitize input
    $FirstName = trim($_POST['FirstName']);
    $LastName = trim($_POST['LastName']);
    $Email = filter_var(trim($_POST['Email']), FILTER_SANITIZE_EMAIL);
    $CountryCode = trim($_POST['CountryCode']);
    $PhoneNumber = trim($_POST['Phone']);
    $Password_1 = $_POST['Password_1'];
    $Password_2 = $_POST['Password_2'];

    // Input validation
    if (empty($FirstName)) { array_push($errors, "First Name is required"); }
    if (empty($LastName)) { array_push($errors, "Last Name is required"); }
    if (empty($Email)) { array_push($errors, "Email is required"); }
    if (!filter_var($Email, FILTER_VALIDATE_EMAIL)) { array_push($errors, "Invalid email format"); }
    if (empty($PhoneNumber)) { array_push($errors, "Phone Number is required"); }
    // Basic phone number validation: 10 digits
    if (!preg_match("/^\d{10}$/", $PhoneNumber)) { array_push($errors, "Phone number must be 10 digits"); }
    if (empty($Password_1)) { array_push($errors, "Password is required"); }
    if ($Password_1 != $Password_2) {
        array_push($errors, "The two passwords do not match");
    }
    // Password strength (add more rules if needed, e.g., min length, special chars)
    if (strlen($Password_1) < 6) {
        array_push($errors, "Password must be at least 6 characters long");
    }

    // reCAPTCHA verification
    if (isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])) {
        $recaptchaResponse = $_POST['g-recaptcha-response'];

        $url = 'https://www.google.com/recaptcha/api/siteverify';
        $data = array(
            'secret' => $secretKey,
            'response' => $recaptchaResponse,
            'remoteip' => $_SERVER['REMOTE_ADDR'] // Optional: For improved security checks
        );

        $options = array(
            'http' => array(
                'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
                'method'  => 'POST',
                'content' => http_build_query($data),
            ),
        );

        $context  = stream_context_create($options);
        $response = @file_get_contents($url, false, $context); // Use @ to suppress warnings if URL is unreachable
        $result = json_decode($response, true);

        if (!$result || !$result['success']) {
            error_log("reCAPTCHA verification failed for email: " . $Email . " - Result: " . json_encode($result));
            array_push($errors, "reCAPTCHA verification failed. Please try again.");
        }
    } else {
        array_push($errors, "Please complete the reCAPTCHA.");
    }

    // Check if user already exists (only if no other errors, and DB connection is good)
    if (count($errors) == 0 && $db) {
        $stmt_check = $db->prepare("SELECT ID FROM users WHERE Email = ? LIMIT 1");
        if ($stmt_check) {
            $stmt_check->bind_param("s", $Email);
            $stmt_check->execute();
            $stmt_check->store_result();
            if ($stmt_check->num_rows > 0) {
                array_push($errors, "Email already exists");
            }
            $stmt_check->close();
        } else {
            error_log("Error preparing user check statement: " . $db->error);
            array_push($errors, "An internal error occurred. Please try again.");
        }
    }


    // Register user if no errors
    if (count($errors) == 0 && $db) {
        // Hash the password securely (MD5 is outdated, use password_hash)
        $Password = password_hash($Password_1, PASSWORD_DEFAULT);

        $Token = bin2hex(random_bytes(32)); // Generate a secure token (32 bytes = 64 hex chars)
        $Created = date("Y-m-d H:i:s"); // Include time for more precision

        // Prepare the INSERT statement
        $stmt_insert = $db->prepare("INSERT INTO users (FirstName, LastName, Email, CountryCode, Phone, Password, Picture, Gender, DateBirth, City, Province, UploadCV, Status, Account, Verified, Token, Created, Date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        if ($stmt_insert) {
            // Default values for fields not in the form
            $defaultPicture = 'avatar.jpg';
            $defaultGender = '';
            $defaultDateBirth = '0000-00-00'; // Or NULL, depending on schema
            $defaultCity = '';
            $defaultProvince = '';
            $defaultUploadCV = ''; // Placeholder for CV path
            $defaultStatus = 'Pending';
            $defaultAccount = 'User'; // Assuming new signups are 'User' type
            $defaultVerified = 'No'; // User needs to verify email
            $defaultDate = date("Y-m-d"); // Date of registration (same as Created)

            // Bind parameters: ssssssssssssssss (16 's' for strings, one 's' for Picture)
            $stmt_insert->bind_param("ssssssssssssssssss",
                $FirstName, $LastName, $Email, $CountryCode, $PhoneNumber, $Password,
                $defaultPicture, $defaultGender, $defaultDateBirth, $defaultCity, $defaultProvince,
                $defaultUploadCV, $defaultStatus, $defaultAccount, $defaultVerified, $Token, $Created, $defaultDate
            );

            if ($stmt_insert->execute()) {
                // Send verification email
                $to = $Email;
                $subject = 'Verify Your Bashjobz Account'; // Changed to Bashjobz
                $message = '
                <html>
                <head>
                    <title>Verify Your Bashjobz Account</title>
                    <style>
                        body { font-family: Arial, sans-serif; background-color: #f4f4f4; color: #333; padding: 20px; }
                        .container { max-width: 600px; margin: 0 auto; background-color: #fff; padding: 20px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); }
                        h1 { color: #e67e22; } /* Matching Bashjobz orange */
                        p { font-size: 16px; }
                        .button { display: inline-block; padding: 10px 20px; font-size: 16px; color: white; background-color: #e67e22; text-decoration: none; border-radius: 5px; }
                        .button a { text-decoration: none; font-size: 18px; color: white; }
                        .logo { display: block; margin: 0 auto 20px; max-width: 150px; }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <img src="https://bashajobz.co.za/logo.png" alt="Bashjobz Logo" class="logo">
                        <h1>Account Verification</h1>
                        <p>Hi ' . htmlspecialchars($FirstName) . ',</p>
                        <p>Thank you for registering with Bashjobz! Please click on the link below to verify your account:</p>
                        <center> <p><a href="https://bashajobz.co.za/verify.php?email=' . urlencode($Email) . '&token=' . urlencode($Token) . '" class="button">Verify Your Account</a></p></center>
                        <p>If the button does not work, please copy and paste the following link into your browser:</p>
                        <p><a href="https://bashajobz.co.za/Dashboards/Verify/verify.php?email=' . urlencode($Email) . '&token=' . urlencode($Token) . '">https://bashajobz.co.za/verify.php?email=' . urlencode($Email) . '&token=' . urlencode($Token) . '</a></p>
                        <p>Thank you,</p>
                        <p>The Bashjobz Team</p>
                    </div>
                </body>
                </html>';

                $headers = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                $headers .= 'From: "Bashjobz Account Verification" <noreply@bashajobz.co.za>' . "\r\n";

                if (mail($to, $subject, $message, $headers)) {
                    $_SESSION['Email'] = $Email;
                    $_SESSION['success'] = "You are now registered. Please check your email to verify your account.";
                    header('location: Dashboards/Verify/dashboard.php'); // Assuming dashboard is in the root or a known path
                    exit();
                } else {
                    error_log("Failed to send verification email to " . $Email);
                    array_push($errors, "Registration successful, but failed to send verification email. Please contact support.");
                    // You might want to delete the user or mark them as unverified if email is critical
                }

            } else {
                error_log("Error executing user insert statement: " . $stmt_insert->error);
                array_push($errors, "Registration failed. Please try again.");
            }
            $stmt_insert->close();
        } else {
            error_log("Error preparing user insert statement: " . $db->error);
            array_push($errors, "An internal error occurred during registration. Please try again.");
        }
    }
}
?>