<?php
// jobs.php - Job Listings Page for www.bashajobz.co.za

// Database connection details
$db = mysqli_connect('localhost', 'prolance_prolance', '@Airbus360', 'prolance_bashajobz');

if (!$db) {
    error_log("Website DB Connection Failed: " . mysqli_connect_error());
    $db_connection_error = "We are currently experiencing technical difficulties. Please try again later.";
} else {
    $db_connection_error = null;
}

// SEO Meta Tags
$pageTitle = "Find Jobs in South Africa - Thousands of Vacancies | Bashjobz";
$pageDescription = "Browse thousands of current job vacancies across various industries and locations in South Africa on Bashjobz. Start your job search today for your next career opportunity.";
$pageKeywords = "South Africa jobs, job vacancies, find a job, career search, employment South Africa, job listings, industries, locations, job board, careers, job portal";

// --- Job Filtering and Pagination Logic ---
$search_keyword = isset($_GET['search']) ? trim($_GET['search']) : '';
// Category and Location filters are now part of the general search keyword
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$jobs_per_page = 12; // Number of jobs to display per page

$where_clauses = ["Status = 'Active'"]; // Base condition for active jobs
$params = [];
$param_types = '';

// Add filters if present - consolidated search across multiple fields
if (!empty($search_keyword)) {
    // Search across JobTitle, Company, Description, Requirements, Location, Category
    $where_clauses[] = "(JobTitle LIKE ? OR Company LIKE ? OR Description LIKE ? OR Requirements LIKE ? OR Location LIKE ? OR Category LIKE ?)";
    $params[] = '%' . $search_keyword . '%';
    $params[] = '%' . $search_keyword . '%';
    $params[] = '%' . $search_keyword . '%';
    $params[] = '%' . $search_keyword . '%'; // Requirements field
    $params[] = '%' . $search_keyword . '%'; // Location field
    $params[] = '%' . $search_keyword . '%'; // Category field
    $param_types .= 'ssssss';
}

$where_sql = count($where_clauses) > 0 ? "WHERE " . implode(" AND ", $where_clauses) : "";

$jobs = [];
$total_jobs = 0;
$total_pages = 1;

if (!$db_connection_error) {
    // 1. Get total number of jobs for pagination
    $count_query = "SELECT COUNT(ID) AS total_count FROM jobs " . $where_sql;
    
    // Prepare the count statement
    $stmt_count = mysqli_prepare($db, $count_query);
    if ($stmt_count) {
        // If there are search parameters, bind them for the count query
        if (!empty($params)) {
            // Only bind the 's' parameters for the count query as it doesn't have LIMIT/OFFSET
            $search_params_for_count = array_slice($params, 0, strlen($param_types));
            mysqli_stmt_bind_param($stmt_count, $param_types, ...$search_params_for_count);
        }
        mysqli_stmt_execute($stmt_count);
        $result_count = mysqli_stmt_get_result($stmt_count);
        $row_count = mysqli_fetch_assoc($result_count);
        $total_jobs = $row_count['total_count'];
        mysqli_stmt_close($stmt_count);
    } else {
        error_log("Error preparing count query: " . mysqli_error($db));
    }

    $total_pages = ceil($total_jobs / $jobs_per_page);
    $offset = ($current_page - 1) * $jobs_per_page;

    // Ensure current_page is within valid bounds
    if ($current_page < 1) {
        $current_page = 1;
    } elseif ($total_pages > 0 && $current_page > $total_pages) {
        $current_page = $total_pages;
        $offset = ($current_page - 1) * $jobs_per_page; // Recalculate offset for adjusted page
    } elseif ($total_pages == 0) { // If no jobs, ensure page is 1 and offset 0
        $current_page = 1;
        $offset = 0;
    }

    // 2. Fetch job data for the current page
    // Added 'Requirements' to the SELECT clause if it's a column you want to display or use
    $job_query = "SELECT ID, Company, JobTitle, Location, Created, Category, Slug, Description, Requirements FROM jobs " . $where_sql . " ORDER BY Created DESC LIMIT ? OFFSET ?";
    
    // Prepare the job data statement
    $stmt_jobs = mysqli_prepare($db, $job_query);
    if ($stmt_jobs) {
        // Build the full parameter array for job data query (search params + limit + offset)
        $full_params = array_merge($params, [$jobs_per_page, $offset]);
        $full_param_types = $param_types . 'ii'; // 'ii' for integer (jobs_per_page, offset)

        mysqli_stmt_bind_param($stmt_jobs, $full_param_types, ...$full_params);
        mysqli_stmt_execute($stmt_jobs);
        $result_jobs = mysqli_stmt_get_result($stmt_jobs);

        if ($result_jobs) {
            while ($row = mysqli_fetch_assoc($result_jobs)) {
                $jobs[] = $row;
            }
        } else {
            error_log("Error fetching jobs data: " . mysqli_error($db));
        }
        mysqli_stmt_close($stmt_jobs);
    } else {
        error_log("Error preparing job data query: " . mysqli_error($db));
    }

    mysqli_close($db); // Close database connection
}

// These are no longer needed for filter dropdowns but kept as an example if you want to display them
$common_categories = ['IT', 'Marketing', 'Finance', 'Engineering', 'Healthcare', 'Sales', 'Administration'];
$common_locations = ['Gauteng', 'Western Cape', 'KwaZulu-Natal', 'Eastern Cape', 'Limpopo', 'Mpumalanga', 'Free State', 'North West', 'Northern Cape'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($pageKeywords); ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://www.bashajobz.co.za/jobs.php">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
          <link rel="icon" href="https://bashajobz.co.za/logo.png" type="image/x-icon">
          <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="apple-touch-icon" sizes="57x57" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://www.bashajobz.co.za/logo.png">
    <style>
        /* General Body and Layout */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #f4f6f9;
            color: #333;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            overflow-x: hidden; /* Prevent horizontal scrolling */
            box-sizing: border-box;
        }

        /* Header/Navbar (Copied from index.php for consistency) */
        .main-header {
            background-color: #fff;
            padding: 15px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            width: 100%;
            z-index: 1000;
            box-sizing: border-box;
        }

        .main-header .logo {
            display: flex;
            align-items: center;
        }

        .header-logo {
            height: 50px;
            width: auto;
            max-width: 150px;
            border-radius: 4px;
            object-fit: contain;
            filter: drop-shadow(0 0 2px rgba(0,0,0,0.1));
        }

        .main-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
        }

        .main-nav ul li {
            margin-left: 20px;
        }

        .main-nav ul li a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            padding: 5px 10px;
            transition: color 0.3s ease;
        }

        .main-nav ul li a:hover {
            color: #e67e22;
        }

        .main-nav ul li.signup-btn a {
            background-color: #e67e22;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .main-nav ul li.signup-btn a:hover {
            background-color: #d35400;
            color: white;
        }
        
        .hamburger-menu {
            display: none;
            font-size: 1.8em;
            cursor: pointer;
            color: #333;
            z-index: 1001;
        }

        /* Mobile Navigation Dropdown (Copied from index.php for consistency) */
        .mobile-nav-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background-color: #fff;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            z-index: 998;
            padding: 10px 0;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            overflow-y: auto;
            max-height: calc(100vh - 70px);
            box-sizing: border-box;
            transform: translateY(-10px);
            opacity: 0;
            visibility: hidden;
            transition: transform 0.3s ease-out, opacity 0.3s ease-out, visibility 0.3s ease-out;
        }

        .mobile-nav-dropdown.open {
            display: block;
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }

        .mobile-nav-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center;
            width: 100%;
        }

        .mobile-nav-dropdown ul li {
            margin: 0;
            border-bottom: 1px solid #eee;
        }

        .mobile-nav-dropdown ul li:last-child {
            border-bottom: none;
        }

        .mobile-nav-dropdown ul li a {
            color: #333;
            text-decoration: none;
            font-size: 1.1em;
            padding: 12px 20px;
            display: block;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-weight: 500;
        }

        .mobile-nav-dropdown ul li a:hover {
            background-color: #f0f0f0;
            color: #e67e22;
        }

        .mobile-nav-dropdown ul li.signup-btn a {
            background-color: #e67e22;
            color: white;
            padding: 12px 20px;
            border-radius: 5px; /* Re-added for the button style within dropdown */
            margin-top: 10px;
            margin-bottom: 10px; /* Added for spacing at the bottom of the button */
            width: fit-content; /* Allow button to size to content */
            margin-left: auto;
            margin-right: auto;
            display: block;
            max-width: 250px;
        }
        .mobile-nav-dropdown ul li.signup-btn a:hover {
            background-color: #d35400;
        }

        body.no-scroll {
            overflow: hidden;
        }

        /* Hero Section for Jobs Page */
        .jobs-hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('42491.jpg') no-repeat center center/cover;
            color: white;
            padding: 80px 20px;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            box-sizing: border-box;
        }

        .jobs-hero-section h1 {
            font-size: 2.8em;
            margin-bottom: 15px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .jobs-hero-section p {
            font-size: 1.1em;
            margin-bottom: 30px;
            max-width: 700px;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        /* Search Form (Simplified) */
        .job-filter-section {
            background-color: #fff;
            padding: 30px 20px;
            margin: -60px auto 40px auto; /* Pulls it up over the hero, adjust margin-top to control overlap */
            max-width: 800px; /* Adjusted max-width for simpler form */
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
            box-sizing: border-box;
        }

        .job-filter-section .form-group {
            flex: 1; 
            min-width: 250px; /* Adjusted min-width for keyword input */
            display: flex;
            flex-direction: column;
            position: relative;
        }

        .job-filter-section label {
            display: none; /* Hide label for a cleaner single search bar look */
        }

        .job-filter-section input[type="text"] {
            width: 100%;
            padding: 15px 20px; /* Slightly larger padding for prominence */
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1.1em; /* Larger font size for main search */
            box-sizing: border-box;
            background-color: #f9f9f9;
        }
        
        /* Remove select-wrapper styles as selects are removed */
        .job-filter-section .select-wrapper {
            display: none; 
        }

        .job-filter-section button[type="submit"] {
            background-color: #e67e22;
            color: white;
            padding: 15px 30px; /* Larger padding for button */
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            align-self: flex-end; 
            flex-shrink: 0; 
            min-width: 150px; /* Ensure button isn't too small */
        }

        .job-filter-section button[type="submit"]:hover {
            background-color: #d35400;
            transform: translateY(-2px);
        }
        
        /* Section Styling (from index.php, adapted) */
        .section-container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            box-sizing: border-box;
        }

        .section-title {
            text-align: center;
            color: #2c3e50;
            font-size: 2em;
            margin-bottom: 30px;
            border-bottom: 2px solid #e67e22;
            padding-bottom: 10px;
            display: inline-block;
            width: fit-content;
            max-width: 100%;
            box-sizing: border-box;
        }

        /* Job Cards Grid - Now always a single column */
        .cards-grid {
            display: grid;
            grid-template-columns: 1fr; /* Force single column for "horizontal" effect */
            gap: 30px; /* Space between stacked cards */
            margin-top: 30px;
        }

        .card {
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            transition: transform 0.2s ease;
            display: flex;
            flex-direction: column; /* Content still stacks vertically within the card */
            height: auto;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-content {
            padding: 20px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            box-sizing: border-box;
        }

        .card-content h3 {
            font-size: 1.3em;
            color: #007bff;
            margin-top: 0;
            margin-bottom: 10px;
            line-height: 1.3;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .card-content p {
            font-size: 0.9em;
            color: #666;
            margin-bottom: 15px;
            flex-grow: 1;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }
        
        .card-content .job-description {
            font-size: 0.9em;
            color: #555;
            margin-bottom: 15px;
            line-height: 1.5;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
        }

        .card-meta {
            font-size: 0.85em;
            color: #888;
            margin-top: auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 5px;
        }
        .card-meta span i {
            margin-right: 5px;
        }

        .card-link {
            display: inline-block;
            background-color: #e67e22;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 0.9em;
            margin-top: 15px;
            align-self: flex-end;
            transition: background-color 0.3s ease;
            box-sizing: border-box;
            max-width: 100%;
            text-align: center;
        }
        .card-link:hover {
            background-color: #d35400;
        }

        /* Pagination Styling */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 40px;
            padding: 10px 0;
            gap: 10px;
            flex-wrap: wrap;
        }

        .pagination a, .pagination span {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 40px;
            height: 40px;
            padding: 0 10px;
            text-decoration: none;
            color: #2c3e50;
            background-color: #f0f0f0;
            border: 1px solid #ddd;
            border-radius: 8px;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-weight: 500;
        }

        .pagination a:hover {
            background-color: #e67e22;
            color: white;
        }

        .pagination .current-page {
            background-color: #e67e22;
            color: white;
            font-weight: bold;
            border-color: #e67e22;
            cursor: default;
        }

        .pagination .disabled {
            opacity: 0.6;
            cursor: not-allowed;
            background-color: #f9f9f9;
            color: #888;
        }

        /* No Jobs Found Message */
        .no-jobs-message {
            text-align: center;
            padding: 30px;
            font-size: 1.1em;
            color: #555;
            background-color: #f0f8ff;
            border-left: 5px solid #007bff;
            border-radius: 8px;
            margin-top: 30px;
        }
        .no-jobs-message i {
            margin-right: 10px;
            color: #007bff;
        }


        /* Responsive adjustments */
        @media (max-width: 768px) {
            .jobs-hero-section {
                padding: 60px 15px;
            }
            .jobs-hero-section h1 {
                font-size: 2em;
            }
            .jobs-hero-section p {
                font-size: 0.9em;
            }

            .main-nav {
                display: none;
            }
            .main-header {
                justify-content: space-between;
                padding: 15px;
                position: relative;
            }
            .hamburger-menu {
                display: block;
            }
            .mobile-nav-overlay {
                display: none;
            }

            .job-filter-section {
                margin: -40px auto 30px auto;
                padding: 20px 15px;
                flex-direction: column;
                align-items: stretch;
            }

            .job-filter-section .form-group {
                min-width: unset;
                width: 100%;
            }

            .job-filter-section button[type="submit"] {
                width: 100%;
                margin-top: 15px;
                align-self: center;
            }

            .section-container {
                margin: 20px auto;
                padding: 15px;
            }
            .section-title {
                font-size: 1.8em;
                margin-left: auto;
                margin-right: auto;
            }
            .cards-grid {
                grid-template-columns: 1fr; /* Already set to 1fr, but keep for clarity in mobile context */
                gap: 20px;
            }
            .header-logo {
                height: 40px;
            }
            .card-content {
                padding: 15px;
            }
            .card-link {
                padding: 8px 12px;
                font-size: 0.85em;
            }
            .pagination {
                gap: 8px;
            }
            .pagination a, .pagination span {
                min-width: 35px;
                height: 35px;
                font-size: 0.9em;
                padding: 0 8px;
            }
        }

        /* Further minor adjustments for very small screens (e.g., less than 400px) */
        @media (max-width: 400px) {
            .jobs-hero-section h1 {
                font-size: 1.6em;
            }
            .jobs-hero-section p {
                font-size: 0.85em;
            }
            .job-filter-section input[type="text"],
            .job-filter-section button[type="submit"] {
                padding: 10px 12px;
                font-size: 0.9em;
            }
        }
    </style>
</head>
<body>
    <header class="main-header">
        <a href="index.php" class="logo">
            <img src="logo.png" alt="Bashjobz Logo" class="header-logo" onerror="this.onerror=null;this.src='https://placehold.co/150x50/cccccc/333333?text=Bashjobz';">
        </a>
        <nav class="main-nav">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="jobs.php">Jobs</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="news.php">News</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="cv_services.php">CV Revamp Services</a></li>
                <li><a href="login.php">Login</a></li>
                <li class="signup-btn"><a href="signup.php">Sign Up</a></li>
            </ul>
        </nav>
        <div class="hamburger-menu" onclick="toggleMobileMenu()">
            <i class="fas fa-bars" id="hamburgerIcon"></i>
        </div>

        <!-- Mobile Navigation Dropdown -->
        <nav class="mobile-nav-dropdown" id="mobileNavDropdown">
            <ul>
                <li><a href="index.php" onclick="toggleMobileMenu()">Home</a></li>
                <li><a href="jobs.php" onclick="toggleMobileMenu()">Jobs</a></li>
                <li><a href="blog.php" onclick="toggleMobileMenu()">Blog</a></li>
                <li><a href="news.php" onclick="toggleMobileMenu()">News</a></li>
                <li><a href="contact.php" onclick="toggleMobileMenu()">Contact</a></li>
                <li><a href="cv_services.php" onclick="toggleMobileMenu()">CV Revamp Services</a></li>
                <li><a href="login.php" onclick="toggleMobileMenu()">Login</a></li>
                <li class="signup-btn"><a href="signup.php" onclick="toggleMobileMenu()">Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <?php if ($db_connection_error): ?>
            <div style="color: red; padding: 15px; border: 1px solid red; border-radius: 5px; margin: 20px;">
                <?php echo htmlspecialchars($db_connection_error); ?>
            </div>
        <?php endif; ?>

        <section class="jobs-hero-section">
            <h1>Find Your Next Career Opportunity</h1>
            <p>Search thousands of job listings across South Africa by keyword, category, or location.</p>
        </section>

        <section class="job-filter-section">
            <form action="jobs.php" method="GET" class="w-full flex flex-wrap justify-center gap-4">
                <div class="form-group">
                    <!-- Label is visually hidden, but good for accessibility -->
                    <label for="search-keyword" class="sr-only">Search Jobs</label> 
                    <input type="text" id="search-keyword" name="search" placeholder="Search by job title, company, description, requirements, location, or category..." value="<?php echo htmlspecialchars($search_keyword); ?>">
                </div>
                <button type="submit">Search Jobs <i class="fas fa-search"></i></button>
            </form>
        </section>

        <section class="section-container">
            <h2 class="section-title">Available Job Vacancies (<?php echo $total_jobs; ?>)</h2>
            <?php if (empty($jobs)): ?>
                <div class="no-jobs-message">
                    <p><i class="fas fa-info-circle"></i> No job vacancies found matching your criteria. Try adjusting your search keywords!</p>
                </div>
            <?php else: ?>
                <div class="cards-grid">
                    <?php foreach ($jobs as $job): ?>
                        <div class="card job-card">
                            <div class="card-content">
                                <h3><?php echo htmlspecialchars($job['JobTitle']); ?></h3>
                                <p><strong><?php echo htmlspecialchars($job['Company']); ?></strong> - <?php echo htmlspecialchars($job['Location']); ?></p>
                                <p class="job-description">
                                    <?php 
                                    // Combine description and requirements for snippet
                                    $combined_text = strip_tags($job['Description']);
                                    if (!empty($job['Requirements'])) {
                                        $combined_text .= ' ' . strip_tags($job['Requirements']);
                                    }
                                    echo htmlspecialchars(substr($combined_text, 0, 150)) . (strlen($combined_text) > 150 ? '...' : ''); 
                                    ?>
                                </p>
                                <div class="card-meta">
                                    <span><i class="fas fa-tag"></i> <?php echo htmlspecialchars($job['Category']); ?></span>
                                    <span><i class="fas fa-calendar-alt"></i> <?php echo htmlspecialchars(date('M d, Y', strtotime($job['Created']))); ?></span>
                                </div>
                            </div>
                            <a href="job_detail.php?id=<?php echo htmlspecialchars($job['ID']); ?>" class="card-link">View Job</a>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Pagination Links -->
                <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php 
                        // Build query string for pagination links
                        $pagination_query_params = $_GET;
                        unset($pagination_query_params['page']); // Remove current page from params

                        $base_query_string = http_build_query($pagination_query_params);
                        ?>

                        <?php if ($current_page > 1): ?>
                            <a href="?<?php echo $base_query_string; ?>&page=<?php echo $current_page - 1; ?>"><i class="fas fa-chevron-left"></i> Prev</a>
                        <?php else: ?>
                            <span class="disabled"><i class="fas fa-chevron-left"></i> Prev</span>
                        <?php endif; ?>

                        <?php
                        // Display a limited range of pages around the current page
                        $start_page = max(1, $current_page - 2);
                        $end_page = min($total_pages, $current_page + 2);

                        if ($start_page > 1) {
                            echo '<a href="?' . $base_query_string . '&page=1">1</a>';
                            if ($start_page > 2) {
                                echo '<span>...</span>';
                            }
                        }

                        for ($i = $start_page; $i <= $end_page; $i++): ?>
                            <?php if ($i == $current_page): ?>
                                <span class="current-page"><?php echo $i; ?></span>
                            <?php else: ?>
                                <a href="?<?php echo $base_query_string; ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>

                        <?php
                        if ($end_page < $total_pages) {
                            if ($end_page < $total_pages - 1) {
                                echo '<span>...</span>';
                            }
                            echo '<a href="?' . $base_query_string . '&page=' . $total_pages . '">' . $total_pages . '</a>';
                        }
                        ?>

                        <?php if ($current_page < $total_pages): ?>
                            <a href="?<?php echo $base_query_string; ?>&page=<?php echo $current_page + 1; ?>">Next <i class="fas fa-chevron-right"></i></a>
                        <?php else: ?>
                            <span class="disabled">Next <i class="fas fa-chevron-right"></i></span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

            <?php endif; ?>
        </section>

    </main>

    <?php
    // Include the reusable footer component
    include 'footer.php';
    ?>

    <script>
        function toggleMobileMenu() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerIcon = document.getElementById('hamburgerIcon');

            mobileNavDropdown.classList.toggle('open');
            // Toggle body scroll lock - might be desired for full-screen menus, less so for dropdowns.
            // document.body.classList.toggle('no-scroll'); 

            // Change hamburger icon based on menu state
            if (mobileNavDropdown.classList.contains('open')) {
                hamburgerIcon.classList.remove('fa-bars');
                hamburgerIcon.classList.add('fa-times'); // 'X' icon when open
            } else {
                hamburgerIcon.classList.remove('fa-times');
                hamburgerIcon.classList.add('fa-bars'); // Hamburger icon when closed
            }
        }

        // Close mobile menu if clicked outside or on resize
        document.addEventListener('click', function(event) {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerMenu = document.querySelector('.hamburger-menu');

            // Check if the clicked target is outside the dropdown and outside the hamburger icon
            if (mobileNavDropdown.classList.contains('open') && 
                !mobileNavDropdown.contains(event.target) && 
                !hamburgerMenu.contains(event.target)) {
                toggleMobileMenu();
            }
        });

        // Close menu on resize if it was open (prevents weird states)
        window.addEventListener('resize', function() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            if (window.innerWidth > 768 && mobileNavDropdown.classList.contains('open')) {
                toggleMobileMenu();
            }
        });
    </script>

</body>
</html>
