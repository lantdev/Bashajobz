<?php
// index.php - Homepage for www.bashajobz.co.za

// Database connection details
$db = mysqli_connect('localhost', 'prolance_prolance', '@Airbus360', 'prolance_bashajobz');

if (!$db) {
    error_log("Website DB Connection Failed: " . mysqli_connect_error());
    $db_connection_error = "We are currently experiencing technical difficulties. Please try again later.";
} else {
    $db_connection_error = null;
}

// --- Fetch Data for Homepage ---
$recent_jobs = [];
$recent_blog_posts = [];
$recent_news_articles = [];

if (!$db_connection_error) {
    // Fetch Recent Job Postings (e.g., 8 most recent active jobs)
    $query_jobs = "SELECT ID, Company, JobTitle, Location, Created, Category, Slug FROM jobs WHERE Status = 'Active' ORDER BY Created DESC LIMIT 8";
    $result_jobs = mysqli_query($db, $query_jobs);
    if ($result_jobs) {
        while ($row = mysqli_fetch_assoc($result_jobs)) {
            $recent_jobs[] = $row;
        }
    } else {
        error_log("Error fetching recent jobs: " . mysqli_error($db));
    }

    // Fetch Recent Blog Posts (e.g., 3 most recent published blog posts) with Account type
    // Join with admin table to get the 'Account' field for dynamic image paths
    $query_blog = "SELECT b.ID, b.Title, b.Slug, b.Picture, b.Description, b.Created, b.Username, b.FirstName, b.LastName, a.Account FROM blog b JOIN admin a ON b.UserID = a.ID WHERE b.Status = 'Published' ORDER BY b.Created DESC LIMIT 3";
    $result_blog = mysqli_query($db, $query_blog);
    if ($result_blog) {
        while ($row = mysqli_fetch_assoc($result_blog)) {
            $recent_blog_posts[] = $row;
        }
    } else {
        error_log("Error fetching recent blog posts: " . mysqli_error($db));
    }

    // Fetch Recent News Articles (e.g., 3 most recent published news articles) with Account type
    // Join with admin table to get the 'Account' field for dynamic image paths
    $query_news = "SELECT n.ID, n.Title, n.Slug, n.Picture, n.Description, n.Created, n.Username, n.FirstName, n.LastName, a.Account FROM news n JOIN admin a ON n.UserID = a.ID WHERE n.Status = 'Published' ORDER BY n.Created DESC LIMIT 3";
    $result_news = mysqli_query($db, $query_news);
    if ($result_news) {
        while ($row = mysqli_fetch_assoc($result_news)) {
            $recent_news_articles[] = $row;
        }
    } else {
        error_log("Error fetching recent news articles: " . mysqli_error($db));
    }

    mysqli_close($db); // Close database connection after all fetches
}


// SEO Meta Tags
$pageTitle = "Bashjobz - Your Premier Job Portal in South Africa";
$pageDescription = "Find thousands of job opportunities in South Africa. Explore jobs, career resources, blog posts, and news articles on Bashjobz. Connect with top employers today!";
$pageKeywords = "jobs South Africa, job portal, career opportunities, employment, job listings, job search, blog, news, Bashjobz";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($pageKeywords); ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://www.bashajobz.co.za/index.php">
      <link rel="icon" href="https://bashajobz.co.za/logo.png" type="image/x-icon">
          <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="apple-touch-icon" sizes="57x57" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://www.bashajobz.co.za/logo.png">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* General Body and Layout */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #f4f6f9;
            color: #333;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            /* Prevent horizontal scrolling on the body */
            overflow-x: hidden;
        }

        /* Header/Navbar */
        .main-header {
            background-color: #fff;
            padding: 15px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky; /* Sticky header */
            top: 0;
            width: 100%;
            z-index: 1000;
            /* Ensure header content doesn't overflow horizontally */
            box-sizing: border-box; /* Include padding in the width calculation */
        }

        .main-header .logo {
            display: flex;
            align-items: center;
        }

        .header-logo {
            height: 50px; /* Standard height */
            width: auto; /* Maintain aspect ratio */
            max-width: 150px; /* Ensure it doesn't get too wide */
            border-radius: 4px;
            object-fit: contain; /* Ensures the entire image is visible within its bounds */
            filter: drop-shadow(0 0 2px rgba(0,0,0,0.1)); /* A subtle shadow can help it stand out */
        }


        .main-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
        }

        .main-nav ul li {
            margin-left: 20px;
        }

        .main-nav ul li a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            padding: 5px 10px;
            transition: color 0.3s ease;
        }

        .main-nav ul li a:hover {
            color: #e67e22;
        }

        .main-nav ul li.signup-btn a {
            background-color: #e67e22;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .main-nav ul li.signup-btn a:hover {
            background-color: #d35400;
            color: white;
        }
        
        /* Hamburger Menu for Mobile */
        .hamburger-menu {
            display: none; /* Hidden by default on desktop */
            font-size: 1.8em;
            cursor: pointer;
            color: #333;
            z-index: 1001; /* Ensure it's above other content */
        }

        /* --- Mobile Navigation Dropdown (Re-designed) --- */
        .mobile-nav-dropdown {
            display: none; /* Hidden by default */
            position: absolute; /* Position relative to the nearest positioned ancestor (main-header) */
            top: 100%; /* Position right below the header */
            left: 0;
            width: 100%;
            background-color: #fff; /* Match header background or a slightly darker shade */
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
            z-index: 998; /* Below the header but above other content */
            padding: 10px 0;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            overflow-y: auto; /* Allow scrolling if many items */
            max-height: calc(100vh - 70px); /* Max height, leaving space for header */
            box-sizing: border-box;
            /* Animation for smooth slide down */
            transform: translateY(-10px);
            opacity: 0;
            visibility: hidden;
            transition: transform 0.3s ease-out, opacity 0.3s ease-out, visibility 0.3s ease-out;
        }

        .mobile-nav-dropdown.open {
            display: block; /* Show when open */
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }

        .mobile-nav-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center; /* Center items for a cleaner look */
            width: 100%;
        }

        .mobile-nav-dropdown ul li {
            margin: 0; /* Remove side margins */
            border-bottom: 1px solid #eee; /* Subtle separator between items */
        }

        .mobile-nav-dropdown ul li:last-child {
            border-bottom: none; /* No border on the last item */
        }

        .mobile-nav-dropdown ul li a {
            color: #333; /* Match desktop nav link color */
            text-decoration: none;
            font-size: 1.1em; /* Slightly larger than desktop for touch */
            padding: 12px 20px; /* More padding for easier tapping */
            display: block;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-weight: 500; /* Match desktop nav font-weight */
        }

        .mobile-nav-dropdown ul li a:hover {
            background-color: #f0f0f0; /* Light highlight on hover */
            color: #e67e22; /* Accent color on hover */
        }

        .mobile-nav-dropdown ul li.signup-btn a {
            background-color: #e67e22;
            color: white;
            padding: 12px 20px;
            border-radius: 0; /* No radius here as it's full width */
            margin-top: 10px; /* Space from previous item */
            border-radius: 5px; /* Add slight border radius for button style */
            width: calc(100% - 40px); /* Adjust for padding on small screens */
            margin-left: auto;
            margin-right: auto;
            display: block; /* Make it a block to center */
            max-width: 250px; /* Limit button width */
        }
        .mobile-nav-dropdown ul li.signup-btn a:hover {
            background-color: #d35400;
        }

        /* Scroll lock for body when mobile menu is open (still useful) */
        body.no-scroll {
            overflow: hidden;
        }

        /* Hero Section */
        .hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('42491.jpg') no-repeat center center/cover; /* Placeholder background image, replace with actual banner */
            color: white;
            padding: 100px 20px;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            /* Ensure padding doesn't cause overflow */
            box-sizing: border-box;
        }

        .hero-section h1 {
            font-size: 3em;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
            /* Prevent overflow of long titles on small screens */
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .hero-section p {
            font-size: 1.2em;
            margin-bottom: 30px;
            max-width: 700px;
            /* Ensure text within the paragraph wraps correctly */
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .search-bar-hero {
            display: flex;
            width: 100%; /* Changed from max-width to width to ensure it scales down */
            max-width: 600px; /* Kept max-width to prevent it from getting too wide on large screens */
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            /* Ensure padding and border are included in the width */
            box-sizing: border-box;
        }

        .search-bar-hero input[type="text"] {
            flex-grow: 1;
            border: none;
            padding: 15px 20px;
            font-size: 1em;
            outline: none;
            /* Ensure input padding doesn't cause overflow */
            box-sizing: border-box;
            min-width: 0; /* Allow input to shrink below its content size */
        }

        .search-bar-hero button {
            background-color: #e67e22;
            color: white;
            border: none;
            padding: 15px 25px;
            font-size: 1em;
            cursor: pointer;
            transition: background-color 0.3s ease;
            /* Ensure button padding doesn't cause overflow */
            box-sizing: border-box;
            /* Prevent text wrapping within button if it's too narrow */
            white-space: nowrap;
        }

        .search-bar-hero button:hover {
            background-color: #d35400;
        }

        /* Section Styling */
        .section-container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            /* Ensure padding is included in the width */
            box-sizing: border-box;
        }

        .section-title {
            text-align: center;
            color: #2c3e50;
            font-size: 2em;
            margin-bottom: 30px;
            border-bottom: 2px solid #e67e22;
            padding-bottom: 10px;
            display: inline-block; /* To make border-bottom fit content */
            width: fit-content; /* Ensure border-bottom only spans text */
            max-width: 100%; /* Prevent overflow */
            box-sizing: border-box;
        }

        /* Cards Grid */
        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); /* Adjusted min-width for better responsiveness */
            gap: 30px;
            margin-top: 30px;
        }

        .card {
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            transition: transform 0.2s ease;
            display: flex;
            flex-direction: column;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            display: block;
        }

        .card-content {
            padding: 20px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            /* Ensure padding is included in the width */
            box-sizing: border-box;
        }

        .card-content h3 {
            font-size: 1.3em;
            color: #2c3e50;
            margin-top: 0;
            margin-bottom: 10px;
            line-height: 1.3;
            /* Prevent overflow of long titles */
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .card-content p {
            font-size: 0.9em;
            color: #666;
            margin-bottom: 15px;
            flex-grow: 1; /* Allows paragraph to take available space */
            /* Ensure text within the paragraph wraps correctly */
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .card-meta {
            font-size: 0.85em;
            color: #888;
            margin-top: auto; /* Pushes meta to bottom */
            display: flex;
            justify-content: space-between;
            align-items: center;
            /* Ensure meta content doesn't overflow */
            flex-wrap: wrap; /* Allow items to wrap if space is constrained */
        }
        .card-meta span i {
            margin-right: 5px;
        }

        .card-link {
            display: inline-block;
            background-color: #e67e22;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 0.9em;
            margin-top: 15px;
            align-self: flex-end; /* Align to the right */
            transition: background-color 0.3s ease;
            /* Ensure padding is included in the width */
            box-sizing: border-box;
            max-width: 100%; /* Prevent link from exceeding card width */
        }
        .card-link:hover {
            background-color: #d35400;
        }

        /* Specific styles for Job cards */
        .job-card .card-content h3 {
            color: #007bff;
        }

        /* Specific styles for Blog cards */
        .blog-card .card-content h3 {
            color: #2ecc71;
        }

        /* Specific styles for News cards */
        .news-card .card-content h3 {
            color: #9b59b6;
        }

        /* View More Button Styling */
        .view-more-btn-container {
            text-align: center;
            margin-top: 30px; /* Space above the button */
        }

        .view-more-btn {
            display: inline-block;
            background-color: #2c3e50; /* A contrasting color */
            color: white;
            padding: 12px 25px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 1.1em;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
            border: none; /* Ensure no default button border */
            cursor: pointer;
        }

        .view-more-btn:hover {
            background-color: #34495e; /* Darker shade on hover */
            transform: translateY(-2px);
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .hero-section {
                padding: 80px 15px;
            }
            .hero-section h1 {
                font-size: 2.2em;
            }
            .hero-section p {
                font-size: 1em;
            }
            .search-bar-hero {
                flex-direction: column;
                /* Ensure the search bar remains within the viewport */
                width: calc(100% - 30px); /* Account for general page padding if present */
                margin: 0 15px; /* Add margin to prevent it from touching screen edges */
            }
            .search-bar-hero input, .search-bar-hero button {
                width: 100%;
                border-radius: 0; /* Remove border-radius to make them stack tightly */
                /* Ensure input and button padding is included in the width */
                box-sizing: border-box;
            }
            .search-bar-hero input {
                border-bottom: 1px solid #eee;
            }
            .search-bar-hero button {
                border-radius: 0 0 8px 8px; /* Rounded bottom corners */
            }

            .main-nav {
                display: none; /* Hide desktop nav */
            }
            .main-header {
                justify-content: space-between; /* Space out logo and hamburger */
                padding: 15px; /* Adjust padding for mobile header */
                position: relative; /* Crucial for positioning the dropdown */
            }
            .hamburger-menu {
                display: block; /* Show hamburger */
            }

            /* Hide the original mobile overlay styling */
            .mobile-nav-overlay {
                display: none; /* Ensure the old overlay styling is gone */
            }

            .section-container {
                margin: 20px auto;
                padding: 15px;
            }
            .section-title {
                font-size: 1.8em;
                /* Center the title on mobile if it's wider */
                margin-left: auto;
                margin-right: auto;
            }
            .cards-grid {
                grid-template-columns: 1fr; /* Single column on mobile */
                gap: 20px; /* Slightly reduce gap for mobile */
            }
            .header-logo {
                height: 40px; /* Smaller logo on mobile */
            }
            /* Adjust card content padding for smaller screens */
            .card-content {
                padding: 15px;
            }

            .view-more-btn {
                font-size: 1em;
                padding: 10px 20px;
            }
        }

        /* Further minor adjustments for very small screens (e.g., less than 400px) */
        @media (max-width: 400px) {
            .hero-section h1 {
                font-size: 1.8em;
            }
            .hero-section p {
                font-size: 0.9em;
            }
            .search-bar-hero input, .search-bar-hero button {
                padding: 12px 15px; /* Slightly smaller padding for smaller inputs */
                font-size: 0.9em;
            }
            .card-content h3 {
                font-size: 1.1em;
            }
            .card-content p {
                font-size: 0.85em;
            }
            .card-link {
                padding: 8px 12px;
                font-size: 0.85em;
            }
            .view-more-btn {
                padding: 8px 15px;
            }
        }
    </style>
</head>
<body>
    <header class="main-header">
        <a href="index.php" class="logo">
            <img src="logo.png" alt="Bashjobz Logo" class="header-logo" onerror="this.onerror=null;this.src='https://placehold.co/150x50/cccccc/333333?text=Bashjobz';">
        </a>
        <nav class="main-nav">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="jobs.php">Jobs</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="news.php">News</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="cv_services.php">CV Revamp Services</a></li>
                <li><a href="login.php">Login</a></li>
                <li class="signup-btn"><a href="signup.php">Sign Up</a></li>
            </ul>
        </nav>
        <div class="hamburger-menu" onclick="toggleMobileMenu()">
            <i class="fas fa-bars" id="hamburgerIcon"></i> </div>

        <nav class="mobile-nav-dropdown" id="mobileNavDropdown">
            <ul>
                <li><a href="index.php" onclick="toggleMobileMenu()">Home</a></li>
                <li><a href="jobs.php" onclick="toggleMobileMenu()">Jobs</a></li>
                <li><a href="blog.php" onclick="toggleMobileMenu()">Blog</a></li>
                <li><a href="news.php" onclick="toggleMobileMenu()">News</a></li>
                <li><a href="contact.php" onclick="toggleMobileMenu()">Contact</a></li>
                <li><a href="cv_services.php" onclick="toggleMobileMenu()">CV Revamp Services</a></li>
                <li><a href="login.php" onclick="toggleMobileMenu()">Login</a></li>
                <li class="signup-btn"><a href="signup.php" onclick="toggleMobileMenu()">Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <?php if ($db_connection_error): ?>
            <div style="color: red; padding: 15px; border: 1px solid red; border-radius: 5px; margin: 20px;">
                <?php echo htmlspecialchars($db_connection_error); ?>
            </div>
        <?php endif; ?>

        <section class="hero-section">
            <h1>Your Dream Job Awaits in South Africa</h1>
            <p>Explore thousands of opportunities, gain career insights, and connect with top employers across the nation.</p>
            <form action="jobs.php" method="GET" class="search-bar-hero">
                <input type="text" name="search" placeholder="Search by job title, company, or keyword...">
                <button type="submit"><i class="fas fa-search"></i> Search</button>
            </form>
        </section>

        <section class="section-container">
            <h2 class="section-title">Recent Job Postings</h2>
            <?php if (empty($recent_jobs)): ?>
                <p style="text-align: center;">No active job postings found at the moment. Please check back later!</p>
            <?php else: ?>
                <div class="cards-grid">
                    <?php foreach ($recent_jobs as $job): ?>
                        <div class="card job-card">
                            <div class="card-content">
                                <h3><?php echo htmlspecialchars($job['JobTitle']); ?></h3>
                                <p><strong><?php echo htmlspecialchars($job['Company']); ?></strong> - <?php echo htmlspecialchars($job['Location']); ?></p>
                                <div class="card-meta">
                                    <span><i class="fas fa-tag"></i> <?php echo htmlspecialchars($job['Category']); ?></span>
                                    <span><i class="fas fa-calendar-alt"></i> <?php echo htmlspecialchars(date('M d, Y', strtotime($job['Created']))); ?></span>
                                </div>
                            </div>
                            <a href="job_detail.php?id=<?php echo htmlspecialchars($job['ID']); ?>" class="card-link">View Job</a>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="view-more-btn-container">
                    <a href="jobs.php" class="view-more-btn">View More Jobs <i class="fas fa-arrow-right"></i></a>
                </div>
            <?php endif; ?>
        </section>

        <section class="section-container">
            <h2 class="section-title">Latest from Our Blog</h2>
            <?php if (empty($recent_blog_posts)): ?>
                <p style="text-align: center;">No blog posts published yet. Stay tuned!</p>
            <?php else: ?>
                <div class="cards-grid">
                    <?php foreach ($recent_blog_posts as $blog_post):
                        // Correct path for blog images based on admin's account type
                        $dynamic_blog_picture_dir = "https://admin.bashajobz.co.za/Dashboards/" . htmlspecialchars($blog_post['Account']) . "/uploads/Blogs/";
                        ?>
                        <div class="card blog-card">
                            <?php if (!empty($blog_post['Picture'])): ?>
                                <img src="<?php echo htmlspecialchars($dynamic_blog_picture_dir . $blog_post['Picture']); ?>" alt="<?php echo htmlspecialchars($blog_post['Title']); ?>" onerror="this.onerror=null;this.src='https://placehold.co/400x200?text=No+Image';">
                            <?php else: ?>
                                <img src="https://placehold.co/400x200?text=No+Image" alt="No Image Available">
                            <?php endif; ?>
                            <div class="card-content">
                                <h3><?php echo htmlspecialchars($blog_post['Title']); ?></h3>
                                <p><?php echo htmlspecialchars(substr(strip_tags($blog_post['Description']), 0, 100)) . '...'; ?></p>
                                <div class="card-meta">
                                    <span><i class="fas fa-user"></i> <?php echo htmlspecialchars($blog_post['FirstName']); ?></span>
                                    <span><i class="fas fa-calendar-alt"></i> <?php echo htmlspecialchars(date('M d, Y', strtotime($blog_post['Created']))); ?></span>
                                </div>
                            </div>
                            <a href="blog_detail.php?id=<?php echo htmlspecialchars($blog_post['ID']); ?>" class="card-link">Read More</a>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="view-more-btn-container">
                    <a href="blog.php" class="view-more-btn">View More Blogs <i class="fas fa-arrow-right"></i></a>
                </div>
            <?php endif; ?>
        </section>

        <section class="section-container">
            <h2 class="section-title">Breaking News</h2>
            <?php if (empty($recent_news_articles)): ?>
                <p style="text-align: center;">No news articles available at the moment.</p>
            <?php else: ?>
                <div class="cards-grid">
                    <?php foreach ($recent_news_articles as $news_article):
                        // Correct path for news images based on admin's account type
                        $dynamic_news_picture_dir = "https://admin.bashajobz.co.za/Dashboards/" . htmlspecialchars($news_article['Account']) . "/uploads/News/";
                        ?>
                        <div class="card news-card">
                            <?php if (!empty($news_article['Picture'])): ?>
                                <img src="<?php echo htmlspecialchars($dynamic_news_picture_dir . $news_article['Picture']); ?>" alt="<?php echo htmlspecialchars($news_article['Title']); ?>" onerror="this.onerror=null;this.src='https://placehold.co/400x200?text=No+Image';">
                            <?php else: ?>
                                <img src="https://placehold.co/400x200?text=No+Image" alt="No Image Available">
                            <?php endif; ?>
                            <div class="card-content">
                                <h3><?php echo htmlspecialchars($news_article['Title']); ?></h3>
                                <p><?php echo htmlspecialchars(substr(strip_tags($news_article['Description']), 0, 100)) . '...'; ?></p>
                                <div class="card-meta">
                                    <span><i class="fas fa-user"></i> <?php echo htmlspecialchars($news_article['FirstName']); ?></span>
                                    <span><i class="fas fa-calendar-alt"></i> <?php echo htmlspecialchars(date('M d, Y', strtotime($news_article['Created']))); ?></span>
                                </div>
                            </div>
                            <a href="news_detail.php?id=<?php echo htmlspecialchars($news_article['ID']); ?>" class="card-link">Read More</a>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="view-more-btn-container">
                    <a href="news.php" class="view-more-btn">View More News <i class="fas fa-arrow-right"></i></a>
                </div>
            <?php endif; ?>
        </section>

    </main>

    <?php
    // Include the reusable footer component
    include 'footer.php';
    ?>

    <script>
        function toggleMobileMenu() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerIcon = document.getElementById('hamburgerIcon'); // Get the icon element

            mobileNavDropdown.classList.toggle('open');
            document.body.classList.toggle('no-scroll'); // Keep scroll lock if needed

            // Change hamburger icon based on menu state
            if (mobileNavDropdown.classList.contains('open')) {
                hamburgerIcon.classList.remove('fa-bars');
                hamburgerIcon.classList.add('fa-times'); // 'X' icon when open
            } else {
                hamburgerIcon.classList.remove('fa-times');
                hamburgerIcon.classList.add('fa-bars'); // Hamburger icon when closed
            }
        }
    </script>

</body>
</html>