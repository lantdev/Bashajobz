<?php include('sign.php'); // Include the backend logic ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-8ETDR3EKS7"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-8ETDR3EKS7');
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://bashajobz.co.za/logo.png" type="image/x-icon">
    <meta name="description" content="Log in to your Bashjobz account to access job listings, manage your profile, and apply for jobs in South Africa.">
    <meta name="keywords" content="login, Bashjobz, job portal, account access, South Africa jobs, career management">
    <meta name="author" content="Bashjobz Team">
    <meta name="robots" content="index, follow">
    <meta name="language" content="English">
    <meta name="geo.region" content="ZA">
    <meta name="geo.placename" content="South Africa">
    <title>Login - Bashjobz | Access Your Job Account</title>

    <meta property="og:title" content="Login - Bashjobz | Access Your Job Account">
    <meta property="og:description" content="Easily log in to your Bashjobz account to manage your job applications and connect with employers in South Africa.">
    <meta property="og:image" content="https://bashajobz.co.za/logo.png">
    <meta property="og:url" content="https://bashajobz.co.za/login.php">
    <meta property="og:type" content="website">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Login - Bashjobz | Access Your Job Account">
    <meta name="twitter:description" content="Log in to Bashjobz to find and manage your career opportunities. Your next job is just a click away!">
    <meta name="twitter:image" content="https://bashajobz.co.za/logo.png">
    <meta name="twitter:url" content="https://bashajobz.co.za/login.php">

    <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="apple-touch-icon" sizes="57x57" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://www.bashajobz.co.za/logo.png">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        /* General Body and Layout */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #f4f6f9;
            color: #333;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            overflow-x: hidden;
            background-image: url('1491594077164.jpeg'); /* Image from your login example */
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        /* Header/Navbar (matching index.php & signup.php) */
        .main-header {
            background-color: #fff;
            padding: 15px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            width: 100%;
            z-index: 1000;
            box-sizing: border-box;
        }

        .main-header .logo {
            display: flex;
            align-items: center;
        }

        .header-logo {
            height: 50px;
            width: auto;
            max-width: 150px;
            border-radius: 4px;
            object-fit: contain;
            filter: drop-shadow(0 0 2px rgba(0,0,0,0.1));
        }

        .main-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
        }

        .main-nav ul li {
            margin-left: 20px;
        }

        .main-nav ul li a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            padding: 5px 10px;
            transition: color 0.3s ease;
        }

        .main-nav ul li a:hover {
            color: #e67e22;
        }

        .main-nav ul li.signup-btn a {
            background-color: #e67e22;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .main-nav ul li.signup-btn a:hover {
            background-color: #d35400;
            color: white;
        }

        /* Hamburger Menu for Mobile (matching index.php & signup.php) */
        .hamburger-menu {
            display: none;
            font-size: 1.8em;
            cursor: pointer;
            color: #333;
            z-index: 1001;
        }

        /* Mobile Navigation Dropdown (matching index.php & signup.php) */
        .mobile-nav-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background-color: #fff;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            z-index: 998;
            padding: 10px 0;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            overflow-y: auto;
            max-height: calc(100vh - 70px);
            box-sizing: border-box;
            transform: translateY(-10px);
            opacity: 0;
            visibility: hidden;
            transition: transform 0.3s ease-out, opacity 0.3s ease-out, visibility 0.3s ease-out;
        }

        .mobile-nav-dropdown.open {
            display: block;
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }

        .mobile-nav-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center;
            width: 100%;
        }

        .mobile-nav-dropdown ul li {
            margin: 0;
            border-bottom: 1px solid #eee;
        }

        .mobile-nav-dropdown ul li:last-child {
            border-bottom: none;
        }

        .mobile-nav-dropdown ul li a {
            color: #333;
            text-decoration: none;
            font-size: 1.1em;
            padding: 12px 20px;
            display: block;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-weight: 500;
        }

        .mobile-nav-dropdown ul li a:hover {
            background-color: #f0f0f0;
            color: #e67e22;
        }

        .mobile-nav-dropdown ul li.signup-btn a {
            background-color: #e67e22;
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            margin-top: 10px;
            width: calc(100% - 40px);
            margin-left: auto;
            margin-right: auto;
            display: block;
            max-width: 250px;
        }
        .mobile-nav-dropdown ul li.signup-btn a:hover {
            background-color: #d35400;
        }

        body.no-scroll {
            overflow: hidden;
        }

        /* Main content styling (for the form) */
        main {
            flex-grow: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            box-sizing: border-box;
        }

        .form-container { /* Renamed from .container for consistency */
            max-width: 500px;
            width: 100%;
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            padding: 30px;
            box-sizing: border-box;
        }

        .form-container h1 {
            text-align: center;
            color: #2c3e50;
            font-size: 2.2em;
            margin-bottom: 30px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 600;
        }

        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1em;
            box-sizing: border-box;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        input[type="email"]:focus,
        input[type="password"]:focus {
            border-color: #e67e22;
            outline: none;
            box-shadow: 0 0 8px rgba(230, 126, 34, 0.2);
        }

        .button {
            display: block;
            width: 100%;
            padding: 15px;
            background-color: #e67e22;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.1em;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .button:hover {
            background-color: #d35400;
            transform: translateY(-2px);
        }

        .links, .forgot-password-link { /* Added .forgot-password-link */
            text-align: center;
            margin-top: 20px;
            font-size: 0.9em;
            color: #666;
        }
        .links p:last-child {
            margin-top: 10px; /* Space out the links */
        }

        .links a, .forgot-password-link a {
            color: #e67e22;
            text-decoration: none;
            font-weight: 500;
        }

        .links a:hover, .forgot-password-link a:hover {
            text-decoration: underline;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
            padding: 12px;
            border: 1px solid #f5c6cb;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 0.9em;
            box-sizing: border-box;
        }

        .error p {
            margin: 0;
            font-weight: bold;
        }

        /* Responsive adjustments (matching index.php for header/footer breakpoints) */
        @media (max-width: 768px) {
            .main-header {
                justify-content: space-between;
                padding: 15px;
                position: relative;
            }
            .main-nav {
                display: none;
            }
            .hamburger-menu {
                display: block;
            }
            .header-logo {
                height: 40px;
            }

            .form-container {
                padding: 20px;
                margin: 20px 15px;
                width: auto;
            }
            input[type="email"],
            input[type="password"] {
                padding: 10px 12px;
                font-size: 0.9em;
            }
            .button {
                padding: 12px;
                font-size: 1em;
            }
            .links, .forgot-password-link {
                font-size: 0.8em;
            }

            /* Footer responsiveness - inherited from index.php reference */
            .footer-container {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }
            .footer-about, .footer-links, .footer-legal, .footer-contact {
                margin-bottom: 30px;
                width: 100%;
            }
            .footer-about h3::after,
            .footer-links h3::after,
            .footer-legal h3::after,
            .footer-contact h3::after {
                left: 50%;
                transform: translateX(-50%);
            }
            .footer-contact p {
                justify-content: center;
            }
        }

        @media (max-width: 480px) {
            .main-header {
                padding: 10px;
            }
            .header-logo {
                height: 35px;
            }
            .form-container h1 {
                font-size: 1.8em;
                margin-bottom: 20px;
            }
            .button {
                font-size: 0.95em;
            }
            .social-icons a {
                font-size: 1.3em;
                margin-right: 10px;
            }
            .footer-links a {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

    <header class="main-header">
        <a href="index.php" class="logo">
            <img src="logo.png" alt="Bashjobz Logo" class="header-logo" onerror="this.onerror=null;this.src='https://placehold.co/150x50/cccccc/333333?text=Bashjobz';">
        </a>
        <nav class="main-nav">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="jobs.php">Jobs</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="news.php">News</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="cv_services.php">CV Revamp Services</a></li>
                <li><a href="login.php" class="active">Login</a></li> <li class="signup-btn"><a href="signup.php">Sign Up</a></li>
            </ul>
        </nav>
        <div class="hamburger-menu" onclick="toggleMobileMenu()">
            <i class="fas fa-bars" id="hamburgerIcon"></i>
        </div>

        <nav class="mobile-nav-dropdown" id="mobileNavDropdown">
            <ul>
                <li><a href="index.php" onclick="toggleMobileMenu()">Home</a></li>
                <li><a href="jobs.php" onclick="toggleMobileMenu()">Jobs</a></li>
                <li><a href="blog.php" onclick="toggleMobileMenu()">Blog</a></li>
                <li><a href="news.php" onclick="toggleMobileMenu()">News</a></li>
                <li><a href="contact.php" onclick="toggleMobileMenu()">Contact</a></li>
                <li><a href="cv_services.php" onclick="toggleMobileMenu()">CV Revamp Services</a></li>
                <li><a href="login.php" onclick="toggleMobileMenu()">Login</a></li>
                <li class="signup-btn"><a href="signup.php" onclick="toggleMobileMenu()">Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <div class="form-container">
            <?php if (count($errors) > 0): ?>
                <div class="error">
                    <?php foreach ($errors as $error): ?>
                        <p><?= htmlspecialchars($error) ?></p>
                    <?php endforeach ?>
                </div>
            <?php endif ?>

            <h1>Login to Your Account</h1>

            <form action="login.php" method="post">
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" placeholder="Your Email" name="Email" value="<?= htmlspecialchars($_POST['Email'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" placeholder="Enter Your Password" name="Password" required>
                </div>

                <center>
                    <div class="g-recaptcha" data-sitekey="6LchJW4rAAAAACoTTARqqmJ-Uvzv30kXNxBcSUzI"></div><br>
                </center>

                <div class="form-group">
                    <button type="submit" class="button" name="login">Login</button>
                </div>
            </form>

            <script src="https://www.google.com/recaptcha/api.js" async defer></script>

            <div class="forgot-password-link">
                <p><a href="enter_email.php">Forgot Password?</a></p>
            </div>
            <div class="links">
                <p>Don't have an account? <a href="signup.php">Create one here</a></p>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        // JavaScript for mobile menu (matching index.php & signup.php)
        function toggleMobileMenu() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerIcon = document.getElementById('hamburgerIcon');

            mobileNavDropdown.classList.toggle('open');
            document.body.classList.toggle('no-scroll');

            if (mobileNavDropdown.classList.contains('open')) {
                hamburgerIcon.classList.remove('fa-bars');
                hamburgerIcon.classList.add('fa-times');
            } else {
                hamburgerIcon.classList.remove('fa-times');
                hamburgerIcon.classList.add('fa-bars');
            }
        }
    </script>
</body>
</html>