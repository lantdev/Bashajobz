<?php
// job_detail.php - Single Job Listing Page for www.bashajobz.co.za

// Database connection details
$db = mysqli_connect('localhost', 'prolance_prolance', '@Airbus360', 'prolance_bashajobz');

// Initialize variables for job data and error
$job_details = null;
$db_connection_error = null;
$job_not_found = false;

if (!$db) {
    error_log("Website DB Connection Failed: " . mysqli_connect_error());
    $db_connection_error = "We are currently experiencing technical difficulties. Please try again later.";
} else {
    // Get job ID from URL
    $job_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

    // Validate job ID
    if ($job_id > 0) {
        // Fetch specific job details, including ClosingDate and Link
        $query_job_detail = "SELECT ID, Company, JobTitle, Location, Created, Category, Slug, Description, Requirements, ClosingDate, Link FROM jobs WHERE ID = ? AND Status = 'Active' LIMIT 1";
        
        $stmt = mysqli_prepare($db, $query_job_detail);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "i", $job_id); // 'i' for integer
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if ($result && mysqli_num_rows($result) > 0) {
                $job_details = mysqli_fetch_assoc($result);
            } else {
                $job_not_found = true; // Job not found or not active
            }
            mysqli_stmt_close($stmt);
        } else {
            error_log("Error preparing job detail query: " . mysqli_error($db));
            $db_connection_error = "Failed to retrieve job details. Please try again.";
        }
    } else {
        $job_not_found = true; // Invalid job ID
    }

    mysqli_close($db); // Close database connection
}

// SEO Meta Tags (Dynamic based on job details)
$pageTitle = "Job Not Found | Bashajobz";
$pageDescription = "The job you are looking for could not be found or has been removed.";
$pageKeywords = "job not found, Bashajobz";

// Schema.org JobPosting structured data (Dynamic)
$json_ld_schema = '';

if ($job_details) {
    $pageTitle = htmlspecialchars($job_details['JobTitle']) . " at " . htmlspecialchars($job_details['Company']) . " in " . htmlspecialchars($job_details['Location']) . " | Bashajobz";
    $pageDescription = htmlspecialchars(substr(strip_tags($job_details['Description']), 0, 160)) . '...';
    $pageKeywords = htmlspecialchars($job_details['JobTitle']) . ", " . htmlspecialchars($job_details['Company']) . ", " . htmlspecialchars($job_details['Location']) . ", " . htmlspecialchars($job_details['Category']) . ", jobs South Africa";

    // Determine validThrough date for Schema.org
    $valid_through_date = '';
    if (!empty($job_details['ClosingDate'])) {
        $valid_through_date = date('Y-m-d', strtotime($job_details['ClosingDate']));
    } else {
        // Fallback: If no closing date, set a default validity (e.g., 60 days from creation)
        $valid_through_date = date('Y-m-d', strtotime($job_details['Created'] . ' + 60 days')); 
    }

    // Determine application URL for Schema.org
    $application_url = !empty($job_details['Link']) ? $job_details['Link'] : "https://www.bashajobz.co.za/job_detail.php?id=" . $job_details['ID'];


    // Prepare JobPosting Schema.org JSON-LD
    $json_ld_schema = '<script type="application/ld+json">' . json_encode([
        "@context" => "https://schema.org",
        "@type" => "JobPosting",
        "title" => $job_details['JobTitle'],
        "description" => $job_details['Description'], // Full description for schema
        "datePosted" => date('Y-m-d', strtotime($job_details['Created'])),
        "validThrough" => $valid_through_date, 
        "employmentType" => "FULL_TIME", // Example, adjust if you have other types (e.g., PART_TIME, CONTRACT)
        "hiringOrganization" => [
            "@type" => "Organization",
            "name" => $job_details['Company'],
            "sameAs" => "https://www.bashajobz.co.za/" // Replace with actual company website if available
        ],
        "jobLocation" => [
            "@type" => "Place",
            "address" => [
                "@type" => "PostalAddress",
                "addressLocality" => $job_details['Location'],
                "addressCountry" => "ZA" // South Africa
            ]
        ],
        // "baseSalary" => [ // Optional, include if salary data is available and structured
        //     "@type" => "MonetaryAmount",
        //     "currency" => "ZAR",
        //     "value" => [
        //         "@type" => "QuantitativeValue",
        //         "value" => "Competitive", // Or actual number if available
        //         "unitText" => "MONTH"
        //     ]
        // ],
        "industry" => $job_details['Category'],
        "url" => $application_url // Link directly to the application URL for schema
    ], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . '</script>';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($pageKeywords); ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://www.bashajobz.co.za/job_detail.php?id=<?php echo htmlspecialchars($job_id); ?>">
    <?php echo $json_ld_schema; // Output schema markup ?>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
          <link rel="icon" href="https://bashajobz.co.za/logo.png" type="image/x-icon">
          <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="apple-touch-icon" sizes="57x57" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://www.bashajobz.co.za/logo.png">
    <style>
        /* General Body and Layout (consistent with index.php) */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #f4f6f9;
            color: #333;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            overflow-x: hidden;
            box-sizing: border-box;
        }

        /* Header/Navbar (Copied for consistency) */
        .main-header {
            background-color: #fff;
            padding: 15px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            width: 100%;
            z-index: 1000;
            box-sizing: border-box;
        }

        .main-header .logo {
            display: flex;
            align-items: center;
        }

        .header-logo {
            height: 50px;
            width: auto;
            max-width: 150px;
            border-radius: 4px;
            object-fit: contain;
            filter: drop-shadow(0 0 2px rgba(0,0,0,0.1));
        }

        .main-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
        }

        .main-nav ul li {
            margin-left: 20px;
        }

        .main-nav ul li a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            padding: 5px 10px;
            transition: color 0.3s ease;
        }

        .main-nav ul li a:hover {
            color: #e67e22;
        }

        .main-nav ul li.signup-btn a {
            background-color: #e67e22;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .main-nav ul li.signup-btn a:hover {
            background-color: #d35400;
            color: white;
        }
        
        .hamburger-menu {
            display: none;
            font-size: 1.8em;
            cursor: pointer;
            color: #333;
            z-index: 1001;
        }

        .mobile-nav-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background-color: #fff;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            z-index: 998;
            padding: 10px 0;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            overflow-y: auto;
            max-height: calc(100vh - 70px);
            box-sizing: border-box;
            transform: translateY(-10px);
            opacity: 0;
            visibility: hidden;
            transition: transform 0.3s ease-out, opacity 0.3s ease-out, visibility 0.3s ease-out;
        }

        .mobile-nav-dropdown.open {
            display: block;
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }

        .mobile-nav-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center;
            width: 100%;
        }

        .mobile-nav-dropdown ul li {
            margin: 0;
            border-bottom: 1px solid #eee;
        }

        .mobile-nav-dropdown ul li:last-child {
            border-bottom: none;
        }

        .mobile-nav-dropdown ul li a {
            color: #333;
            text-decoration: none;
            font-size: 1.1em;
            padding: 12px 20px;
            display: block;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-weight: 500;
        }

        .mobile-nav-dropdown ul li a:hover {
            background-color: #f0f0f0;
            color: #e67e22;
        }

        .mobile-nav-dropdown ul li.signup-btn a {
            background-color: #e67e22;
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            margin-top: 10px;
            margin-bottom: 10px;
            width: fit-content;
            margin-left: auto;
            margin-right: auto;
            display: block;
            max-width: 250px;
        }
        .mobile-nav-dropdown ul li.signup-btn a:hover {
            background-color: #d35400;
        }

        body.no-scroll {
            overflow: hidden;
        }

        /* --- Job Detail Page Specific Styles --- */
        .job-detail-container {
            max-width: 900px;
            margin: 40px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            box-sizing: border-box;
        }

        .job-header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #e67e22;
            padding-bottom: 20px;
        }

        .job-header h1 {
            font-size: 2.5em;
            color: #2c3e50;
            margin-bottom: 10px;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .job-header .company-info {
            font-size: 1.2em;
            color: #555;
            margin-bottom: 10px;
        }
        .job-header .company-info i {
            margin-right: 8px;
            color: #007bff;
        }

        .job-meta-info {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 15px;
            font-size: 0.95em;
            color: #777;
        }
        .job-meta-info span {
            display: flex;
            align-items: center;
        }
        .job-meta-info span i {
            margin-right: 5px;
            color: #e67e22;
        }

        .job-content-area {
            margin-top: 30px;
            line-height: 1.8;
            font-size: 1.05em;
            color: #444;
        }
        /* Styles for rich text content outputted by CKEditor */
        .job-full-description p,
        .job-full-description ul,
        .job-full-description ol,
        .job-requirements-content p,
        .job-requirements-content ul,
        .job-requirements-content ol {
            margin-bottom: 1em; /* Ensures spacing between paragraphs/lists */
        }
        .job-full-description ul,
        .job-full-description ol,
        .job-requirements-content ul,
        .job-requirements-content ol {
            padding-left: 25px; /* Indent lists */
        }
        .job-full-description li,
        .job-requirements-content li {
            margin-bottom: 0.5em; /* Spacing between list items */
        }


        .job-content-area h2 {
            font-size: 1.8em;
            color: #2c3e50;
            margin-top: 30px;
            margin-bottom: 15px;
            border-left: 5px solid #007bff;
            padding-left: 10px;
        }

        .action-buttons {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        .action-buttons .btn {
            display: inline-block;
            padding: 15px 30px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 1.1em;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .action-buttons .btn-primary {
            background-color: orange; /* Green for Apply */
            color: white;
        }
        .action-buttons .btn-primary:hover {
            background-color: #27ae60;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }

        .action-buttons .btn-secondary {
            background-color: #007bff; /* Blue for Back to Jobs */
            color: white;
        }
        .action-buttons .btn-secondary:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }

        /* Error/Not Found Message */
        .error-message {
            text-align: center;
            padding: 50px;
            font-size: 1.2em;
            color: #c0392b; /* Reddish color for errors */
            background-color: #ffebee; /* Light red background */
            border: 1px solid #e74c3c;
            border-radius: 8px;
            margin: 50px auto;
            max-width: 600px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        .error-message i {
            margin-right: 10px;
            color: #e74c3c;
        }


        /* Responsive adjustments */
        @media (max-width: 768px) {
            .main-header {
                padding: 15px;
                position: relative; /* Crucial for dropdown positioning */
            }
            .hamburger-menu {
                display: block;
            }
            .main-nav {
                display: none;
            }

            .job-detail-container {
                margin: 20px auto;
                padding: 20px;
                border-radius: 8px;
            }

            .job-header h1 {
                font-size: 1.8em;
            }

            .job-header .company-info {
                font-size: 1em;
            }

            .job-meta-info {
                flex-direction: column; /* Stack meta info vertically */
                align-items: center;
                gap: 10px;
                font-size: 0.9em;
            }

            .job-content-area h2 {
                font-size: 1.5em;
            }

            .job-content-area {
                font-size: 1em;
            }

            .action-buttons {
                flex-direction: column; /* Stack buttons vertically */
                gap: 15px;
            }

            .action-buttons .btn {
                width: calc(100% - 20px); /* Full width with padding factored in */
                max-width: 300px; /* Limit width even if larger screen has more space */
                padding: 12px 20px;
                font-size: 1em;
                margin-left: auto;
                margin-right: auto;
            }
            
            .error-message {
                padding: 30px 20px;
                font-size: 1em;
                margin: 30px auto;
            }
        }

        /* Further minor adjustments for very small screens (e.g., less than 400px) */
        @media (max-width: 400px) {
            .job-detail-container {
                padding: 15px;
            }
            .job-header h1 {
                font-size: 1.5em;
            }
            .job-content-area h2 {
                font-size: 1.3em;
            }
            .job-content-area {
                font-size: 0.95em;
            }
            .action-buttons .btn {
                padding: 10px 15px;
                font-size: 0.9em;
            }
        }
    </style>
</head>
<body>
    <header class="main-header">
        <a href="index.php" class="logo">
            <img src="logo.png" alt="Bashjobz Logo" class="header-logo" onerror="this.onerror=null;this.src='https://placehold.co/150x50/cccccc/333333?text=Bashjobz';">
        </a>
        <nav class="main-nav">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="jobs.php">Jobs</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="news.php">News</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="cv_services.php">CV Revamp Services</a></li>
                <li><a href="login.php">Login</a></li>
                <li class="signup-btn"><a href="signup.php">Sign Up</a></li>
            </ul>
        </nav>
        <div class="hamburger-menu" onclick="toggleMobileMenu()">
            <i class="fas fa-bars" id="hamburgerIcon"></i>
        </div>

        <!-- Mobile Navigation Dropdown -->
        <nav class="mobile-nav-dropdown" id="mobileNavDropdown">
            <ul>
                <li><a href="index.php" onclick="toggleMobileMenu()">Home</a></li>
                <li><a href="jobs.php" onclick="toggleMobileMenu()">Jobs</a></li>
                <li><a href="blog.php" onclick="toggleMobileMenu()">Blog</a></li>
                <li><a href="news.php" onclick="toggleMobileMenu()">News</a></li>
                <li><a href="contact.php" onclick="toggleMobileMenu()">Contact</a></li>
                <li><a href="cv_services.php" onclick="toggleMobileMenu()">CV Revamp Services</a></li>
                <li><a href="login.php" onclick="toggleMobileMenu()">Login</a></li>
                <li class="signup-btn"><a href="signup.php" onclick="toggleMobileMenu()">Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <?php if ($db_connection_error): ?>
            <div class="error-message">
                <p><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($db_connection_error); ?></p>
                <a href="jobs.php" class="btn btn-secondary" style="margin-top: 20px;">Back to Job Listings</a>
            </div>
        <?php elseif ($job_not_found): ?>
            <div class="error-message">
                <p><i class="fas fa-exclamation-circle"></i> Sorry, the job you are looking for could not be found or is no longer active.</p>
                <a href="jobs.php" class="btn btn-secondary" style="margin-top: 20px;">Back to Job Listings</a>
            </div>
        <?php else: ?>
            <section class="job-detail-container">
                <div class="job-header">
                    <h1><?php echo htmlspecialchars($job_details['JobTitle']); ?></h1>
                    <p class="company-info">
                        <i class="fas fa-building"></i> <?php echo htmlspecialchars($job_details['Company']); ?> 
                        <i class="fas fa-map-marker-alt" style="margin-left: 15px;"></i> <?php echo htmlspecialchars($job_details['Location']); ?>
                    </p>
                    <div class="job-meta-info">
                        <span><i class="fas fa-tag"></i> Category: <?php echo htmlspecialchars($job_details['Category']); ?></span>
                        <span><i class="fas fa-calendar-alt"></i> Posted: <?php echo htmlspecialchars(date('M d, Y', strtotime($job_details['Created']))); ?></span>
                        <?php if (!empty($job_details['ClosingDate'])): ?>
                            <span><i class="fas fa-hourglass-end"></i> Closes: <?php echo htmlspecialchars(date('M d, Y', strtotime($job_details['ClosingDate']))); ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="job-content-area">
                    <h2>Job Description</h2>
                    <div class="job-full-description">
                        <?php echo $job_details['Description']; // Render HTML directly ?>
                    </div>
                    
                    <?php if (!empty($job_details['Requirements'])): ?>
                        <h2>Requirements</h2>
                        <div class="job-requirements-content">
                            <?php echo $job_details['Requirements']; // Render HTML directly ?>
                        </div>
                    <?php endif; ?>

                    <!-- Call to Action Section -->
                    <div class="action-buttons">
                        <?php 
                        $apply_link = !empty($job_details['Link']) ? htmlspecialchars($job_details['Link']) : "apply.php?job_id=" . htmlspecialchars($job_details['ID']);
                        $link_target = !empty($job_details['Link']) ? '_blank' : '_self'; // Open external links in new tab
                        ?>
                        <a href="<?php echo $apply_link; ?>" class="btn btn-primary" target="<?php echo $link_target; ?>">Apply Now <i class="fas fa-paper-plane"></i></a>
                        <a href="jobs.php" class="btn btn-secondary">Back to Job Listings</a>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    </main>

    <?php
    // Include the reusable footer component
    include 'footer.php';
    ?>

    <script>
        function toggleMobileMenu() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerIcon = document.getElementById('hamburgerIcon');

            mobileNavDropdown.classList.toggle('open');
            if (mobileNavDropdown.classList.contains('open')) {
                hamburgerIcon.classList.remove('fa-bars');
                hamburgerIcon.classList.add('fa-times');
            } else {
                hamburgerIcon.classList.remove('fa-times');
                hamburgerIcon.classList.add('fa-bars');
            }
        }

        document.addEventListener('click', function(event) {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerMenu = document.querySelector('.hamburger-menu');

            if (mobileNavDropdown.classList.contains('open') && 
                !mobileNavDropdown.contains(event.target) && 
                !hamburgerMenu.contains(event.target)) {
                toggleMobileMenu();
            }
        });

        window.addEventListener('resize', function() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            if (window.innerWidth > 768 && mobileNavDropdown.classList.contains('open')) {
                toggleMobileMenu();
            }
        });
    </script>

</body>
</html>
