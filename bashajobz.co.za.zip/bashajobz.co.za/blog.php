<?php
// blog.php - Blog Listings Page for www.bashajobz.co.za

// Database connection details
$db = mysqli_connect('localhost', 'prolance_prolance', '@Airbus360', 'prolance_bashajobz');

if (!$db) {
    error_log("Website DB Connection Failed: " . mysqli_connect_error());
    $db_connection_error = "We are currently experiencing technical difficulties. Please try again later.";
} else {
    $db_connection_error = null;
}

// SEO Meta Tags
$pageTitle = "Bashjobz Blog - Career Advice, Industry News & Tips | South Africa";
$pageDescription = "Explore the Bashjobz blog for expert career advice, industry insights, job search tips, and the latest news to help you advance your professional journey in South Africa.";
$pageKeywords = "Bashjobz blog, career advice, job tips, industry insights, professional development, South Africa careers, employment news, job search strategies";

// --- Blog Filtering and Pagination Logic ---
$search_keyword = isset($_GET['search']) ? trim($_GET['search']) : '';
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$posts_per_page = 9; // Number of blog posts to display per page

$where_clauses = ["b.Status = 'Published'"]; // Base condition for published blog posts
$params = [];
$param_types = '';

// Add search keyword filter across Title and Description
if (!empty($search_keyword)) {
    $where_clauses[] = "(b.Title LIKE ? OR b.Description LIKE ?)";
    $params[] = '%' . $search_keyword . '%';
    $params[] = '%' . $search_keyword . '%';
    $param_types .= 'ss';
}

$where_sql = count($where_clauses) > 0 ? "WHERE " . implode(" AND ", $where_clauses) : "";

$blog_posts = [];
$total_blog_posts = 0;
$total_pages = 1;

if (!$db_connection_error) {
    // 1. Get total number of blog posts for pagination
    $count_query = "SELECT COUNT(b.ID) AS total_count FROM blog b JOIN admin a ON b.UserID = a.ID " . $where_sql;
    
    // Prepare the count statement
    $stmt_count = mysqli_prepare($db, $count_query);
    if ($stmt_count) {
        if (!empty($params)) {
            // Only bind the 's' parameters for the count query
            $search_params_for_count = array_slice($params, 0, strlen($param_types));
            mysqli_stmt_bind_param($stmt_count, $param_types, ...$search_params_for_count);
        }
        mysqli_stmt_execute($stmt_count);
        $result_count = mysqli_stmt_get_result($stmt_count);
        $row_count = mysqli_fetch_assoc($result_count);
        $total_blog_posts = $row_count['total_count'];
        mysqli_stmt_close($stmt_count);
    } else {
        error_log("Error preparing blog count query: " . mysqli_error($db));
    }

    $total_pages = ceil($total_blog_posts / $posts_per_page);
    $offset = ($current_page - 1) * $posts_per_page;

    // Ensure current_page is within valid bounds
    if ($current_page < 1) {
        $current_page = 1;
    } elseif ($total_pages > 0 && $current_page > $total_pages) {
        $current_page = $total_pages;
        $offset = ($current_page - 1) * $posts_per_page; // Recalculate offset for adjusted page
    } elseif ($total_pages == 0) { // If no blog posts, ensure page is 1 and offset 0
        $current_page = 1;
        $offset = 0;
    }

    // 2. Fetch blog data for the current page
    $blog_query = "SELECT b.ID, b.Title, b.Slug, b.Picture, b.Description, b.Created, b.Username, b.FirstName, b.LastName, a.Account 
                   FROM blog b 
                   JOIN admin a ON b.UserID = a.ID 
                   " . $where_sql . " ORDER BY b.Created DESC LIMIT ? OFFSET ?";
    
    // Prepare the blog data statement
    $stmt_blog = mysqli_prepare($db, $blog_query);
    if ($stmt_blog) {
        // Build the full parameter array for blog data query (search params + limit + offset)
        $full_params = array_merge($params, [$posts_per_page, $offset]);
        $full_param_types = $param_types . 'ii'; // 'ii' for integer (posts_per_page, offset)

        mysqli_stmt_bind_param($stmt_blog, $full_param_types, ...$full_params);
        mysqli_stmt_execute($stmt_blog);
        $result_blog = mysqli_stmt_get_result($stmt_blog);

        if ($result_blog) {
            while ($row = mysqli_fetch_assoc($result_blog)) {
                $blog_posts[] = $row;
            }
        } else {
            error_log("Error fetching blog posts data: " . mysqli_error($db));
        }
        mysqli_stmt_close($stmt_blog);
    } else {
        error_log("Error preparing blog data query: " . mysqli_error($db));
    }

    mysqli_close($db); // Close database connection
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($pageKeywords); ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://www.bashajobz.co.za/blog.php">
          <link rel="icon" href="https://bashajobz.co.za/logo.png" type="image/x-icon">
          <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="apple-touch-icon" sizes="57x57" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://www.bashajobz.co.za/logo.png">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* General Body and Layout (consistent with other pages) */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #f4f6f9;
            color: #333;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            overflow-x: hidden; /* Prevent horizontal scrolling */
            box-sizing: border-box;
        }

        /* Header/Navbar (Copied for consistency) */
        .main-header {
            background-color: #fff;
            padding: 15px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            width: 100%;
            z-index: 1000;
            box-sizing: border-box;
        }

        .main-header .logo {
            display: flex;
            align-items: center;
        }

        .header-logo {
            height: 50px;
            width: auto;
            max-width: 150px;
            border-radius: 4px;
            object-fit: contain;
            filter: drop-shadow(0 0 2px rgba(0,0,0,0.1));
        }

        .main-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
        }

        .main-nav ul li {
            margin-left: 20px;
        }

        .main-nav ul li a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            padding: 5px 10px;
            transition: color 0.3s ease;
        }

        .main-nav ul li a:hover {
            color: #e67e22; /* Orange hover color */
        }

        .main-nav ul li.signup-btn a {
            background-color: #e67e22; /* Orange button */
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .main-nav ul li.signup-btn a:hover {
            background-color: #d35400; /* Darker orange */
            color: white;
        }
        
        .hamburger-menu {
            display: none;
            font-size: 1.8em;
            cursor: pointer;
            color: #333;
            z-index: 1001;
        }

        /* Mobile Navigation Dropdown (Copied for consistency) */
        .mobile-nav-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background-color: #fff;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            z-index: 998;
            padding: 10px 0;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            overflow-y: auto;
            max-height: calc(100vh - 70px);
            box-sizing: border-box;
            transform: translateY(-10px);
            opacity: 0;
            visibility: hidden;
            transition: transform 0.3s ease-out, opacity 0.3s ease-out, visibility 0.3s ease-out;
        }

        .mobile-nav-dropdown.open {
            display: block;
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }

        .mobile-nav-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center;
            width: 100%;
        }

        .mobile-nav-dropdown ul li {
            margin: 0;
            border-bottom: 1px solid #eee;
        }

        .mobile-nav-dropdown ul li:last-child {
            border-bottom: none;
        }

        .mobile-nav-dropdown ul li a {
            color: #333;
            text-decoration: none;
            font-size: 1.1em;
            padding: 12px 20px;
            display: block;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-weight: 500;
        }

        .mobile-nav-dropdown ul li a:hover {
            background-color: #f0f0f0;
            color: #e67e22; /* Orange hover color */
        }

        .mobile-nav-dropdown ul li.signup-btn a {
            background-color: #e67e22; /* Orange button */
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            margin-top: 10px;
            margin-bottom: 10px;
            width: fit-content;
            margin-left: auto;
            margin-right: auto;
            display: block;
            max-width: 250px;
        }
        .mobile-nav-dropdown ul li.signup-btn a:hover {
            background-color: #d35400; /* Darker orange */
        }

        body.no-scroll {
            overflow: hidden;
        }

        /* --- Blog Page Specific Styles --- */
        .blog-hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('vdw3fdnjrjqyxxscep5n.jpg') no-repeat center center/cover;
            color: white;
            padding: 80px 20px;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            box-sizing: border-box;
        }

        .blog-hero-section h1 {
            font-size: 2.8em;
            margin-bottom: 15px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .blog-hero-section p {
            font-size: 1.1em;
            margin-bottom: 30px;
            max-width: 700px;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        /* Search Form */
        .blog-search-section {
            background-color: #fff;
            padding: 30px 20px;
            margin: -60px auto 40px auto; /* Pulls it up over the hero */
            max-width: 800px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
            box-sizing: border-box;
        }

        .blog-search-section .form-group {
            flex: 1; 
            min-width: 250px;
            display: flex;
            flex-direction: column;
        }

        .blog-search-section input[type="text"] {
            width: 100%;
            padding: 15px 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1.1em;
            box-sizing: border-box;
            background-color: #f9f9f9;
        }

        .blog-search-section button[type="submit"] {
            background-color: #e67e22; /* Orange button */
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            align-self: flex-end; 
            flex-shrink: 0; 
            min-width: 150px;
        }

        .blog-search-section button[type="submit"]:hover {
            background-color: #d35400; /* Darker orange */
            transform: translateY(-2px);
        }
        
        /* Section Container (consistent) */
        .section-container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            box-sizing: border-box;
        }

        .section-title {
            text-align: center;
            color: #2c3e50;
            font-size: 2em;
            margin-bottom: 30px;
            border-bottom: 2px solid #e67e22; /* Orange underline */
            padding-bottom: 10px;
            display: inline-block;
            width: fit-content;
            max-width: 100%;
            box-sizing: border-box;
        }

        /* Blog Cards Grid */
        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); /* 3 columns on desktop, adapts */
            gap: 30px;
            margin-top: 30px;
        }

        .card {
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            transition: transform 0.2s ease;
            display: flex;
            flex-direction: column;
            height: auto;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            display: block;
        }

        .card-content {
            padding: 20px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            box-sizing: border-box;
        }

        .card-content h3 {
            font-size: 1.3em;
            color: #2ecc71; /* Green for blog titles from index.php */
            margin-top: 0;
            margin-bottom: 10px;
            line-height: 1.3;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .card-content .blog-snippet {
            font-size: 0.9em;
            color: #555;
            margin-bottom: 15px;
            line-height: 1.5;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 4; /* Limit to 4 lines for blog snippets */
            -webkit-box-orient: vertical;
        }

        .card-meta {
            font-size: 0.85em;
            color: #888;
            margin-top: auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 5px;
        }
        .card-meta span i {
            margin-right: 5px;
        }

        .card-link {
            display: inline-block;
            background-color: #e67e22; /* Orange link button */
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 0.9em;
            margin-top: 15px;
            align-self: flex-end;
            transition: background-color 0.3s ease;
            box-sizing: border-box;
            max-width: 100%;
            text-align: center;
        }
        .card-link:hover {
            background-color: #d35400; /* Darker orange */
        }

        /* Pagination Styling (consistent) */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 40px;
            padding: 10px 0;
            gap: 10px;
            flex-wrap: wrap;
        }

        .pagination a, .pagination span {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 40px;
            height: 40px;
            padding: 0 10px;
            text-decoration: none;
            color: #2c3e50;
            background-color: #f0f0f0;
            border: 1px solid #ddd;
            border-radius: 8px;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-weight: 500;
        }

        .pagination a:hover {
            background-color: #e67e22; /* Orange hover */
            color: white;
        }

        .pagination .current-page {
            background-color: #e67e22; /* Orange current page */
            color: white;
            font-weight: bold;
            border-color: #e67e22;
            cursor: default;
        }

        .pagination .disabled {
            opacity: 0.6;
            cursor: not-allowed;
            background-color: #f9f9f9;
            color: #888;
        }

        /* No Posts Found Message */
        .no-posts-message {
            text-align: center;
            padding: 30px;
            font-size: 1.1em;
            color: #555;
            background-color: #fffbe6; /* Light yellow background */
            border-left: 5px solid #e67e22; /* Orange border */
            border-radius: 8px;
            margin-top: 30px;
        }
        .no-posts-message i {
            margin-right: 10px;
            color: #e67e22; /* Orange icon */
        }


        /* Responsive adjustments */
        @media (max-width: 768px) {
            .blog-hero-section {
                padding: 60px 15px;
            }
            .blog-hero-section h1 {
                font-size: 2em;
            }
            .blog-hero-section p {
                font-size: 0.9em;
            }

            .main-nav {
                display: none;
            }
            .main-header {
                justify-content: space-between;
                padding: 15px;
                position: relative;
            }
            .hamburger-menu {
                display: block;
            }
            /* Hide the original mobile overlay styling */
            .mobile-nav-overlay {
                display: none;
            }

            .blog-search-section {
                margin: -40px auto 30px auto;
                padding: 20px 15px;
                flex-direction: column;
                align-items: stretch;
            }

            .blog-search-section .form-group {
                min-width: unset;
                width: 100%;
            }

            .blog-search-section button[type="submit"] {
                width: 100%;
                margin-top: 15px;
                align-self: center;
            }

            .section-container {
                margin: 20px auto;
                padding: 15px;
            }
            .section-title {
                font-size: 1.8em;
                margin-left: auto;
                margin-right: auto;
            }
            .cards-grid {
                grid-template-columns: 1fr; /* Single column on mobile */
                gap: 20px;
            }
            .header-logo {
                height: 40px;
            }
            .card-content {
                padding: 15px;
            }
            .card-link {
                padding: 8px 12px;
                font-size: 0.85em;
            }
            .pagination {
                gap: 8px;
            }
            .pagination a, .pagination span {
                min-width: 35px;
                height: 35px;
                font-size: 0.9em;
                padding: 0 8px;
            }
        }

        /* Further minor adjustments for very small screens (e.g., less than 400px) */
        @media (max-width: 400px) {
            .blog-hero-section h1 {
                font-size: 1.6em;
            }
            .blog-hero-section p {
                font-size: 0.85em;
            }
            .blog-search-section input[type="text"],
            .blog-search-section button[type="submit"] {
                padding: 10px 12px;
                font-size: 0.9em;
            }
        }
    </style>
</head>
<body>
    <header class="main-header">
        <a href="index.php" class="logo">
            <img src="logo.png" alt="Bashjobz Logo" class="header-logo" onerror="this.onerror=null;this.src='https://placehold.co/150x50/cccccc/333333?text=Bashjobz';">
        </a>
        <nav class="main-nav">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="jobs.php">Jobs</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="news.php">News</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="cv_services.php">CV Revamp Services</a></li>
                <li><a href="login.php">Login</a></li>
                <li class="signup-btn"><a href="signup.php">Sign Up</a></li>
            </ul>
        </nav>
        <div class="hamburger-menu" onclick="toggleMobileMenu()">
            <i class="fas fa-bars" id="hamburgerIcon"></i>
        </div>

        <!-- Mobile Navigation Dropdown -->
        <nav class="mobile-nav-dropdown" id="mobileNavDropdown">
            <ul>
                <li><a href="index.php" onclick="toggleMobileMenu()">Home</a></li>
                <li><a href="jobs.php" onclick="toggleMobileMenu()">Jobs</a></li>
                <li><a href="blog.php" onclick="toggleMobileMenu()">Blog</a></li>
                <li><a href="news.php" onclick="toggleMobileMenu()">News</a></li>
                <li><a href="contact.php" onclick="toggleMobileMenu()">Contact</a></li>
                <li><a href="cv_services.php" onclick="toggleMobileMenu()">CV Revamp Services</a></li>
                <li><a href="login.php" onclick="toggleMobileMenu()">Login</a></li>
                <li class="signup-btn"><a href="signup.php" onclick="toggleMobileMenu()">Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <?php if ($db_connection_error): ?>
            <div style="color: red; padding: 15px; border: 1px solid red; border-radius: 5px; margin: 20px;">
                <?php echo htmlspecialchars($db_connection_error); ?>
            </div>
        <?php endif; ?>

        <section class="blog-hero-section">
            <h1>Our Latest Blog Posts & Articles</h1>
            <p>Stay informed with expert insights, career advice, and industry trends to boost your professional journey.</p>
        </section>

        <section class="blog-search-section">
            <form action="blog.php" method="GET" class="w-full flex flex-wrap justify-center gap-4">
                <div class="form-group">
                    <label for="search-keyword" class="sr-only">Search Blog Posts</label> 
                    <input type="text" id="search-keyword" name="search" placeholder="Search by title or content keyword..." value="<?php echo htmlspecialchars($search_keyword); ?>">
                </div>
                <button type="submit">Search Blog <i class="fas fa-search"></i></button>
            </form>
        </section>

        <section class="section-container">
            <h2 class="section-title">All Blog Posts (<?php echo $total_blog_posts; ?>)</h2>
            <?php if (empty($blog_posts)): ?>
                <div class="no-posts-message">
                    <p><i class="fas fa-info-circle"></i> No blog posts found matching your criteria. Try a different keyword or check back later!</p>
                </div>
            <?php else: ?>
                <div class="cards-grid">
                    <?php foreach ($blog_posts as $post): 
                        // Correct path for blog images based on admin's account type
                        $dynamic_blog_picture_dir = "https://admin.bashajobz.co.za/Dashboards/" . htmlspecialchars($post['Account']) . "/uploads/Blogs/";
                    ?>
                        <div class="card blog-card">
                            <?php if (!empty($post['Picture'])): ?>
                                <img src="<?php echo htmlspecialchars($dynamic_blog_picture_dir . $post['Picture']); ?>" alt="<?php echo htmlspecialchars($post['Title']); ?>" onerror="this.onerror=null;this.src='https://placehold.co/400x200?text=No+Image';">
                            <?php else: ?>
                                <img src="https://placehold.co/400x200?text=No+Image" alt="No Image Available">
                            <?php endif; ?>
                            <div class="card-content">
                                <h3><?php echo htmlspecialchars($post['Title']); ?></h3>
                                <p class="blog-snippet"><?php echo htmlspecialchars(substr(strip_tags($post['Description']), 0, 180)) . (strlen(strip_tags($post['Description'])) > 180 ? '...' : ''); ?></p>
                                <div class="card-meta">
                                    <span><i class="fas fa-user"></i> By <?php echo htmlspecialchars($post['FirstName'] . ' ' . $post['LastName']); ?></span>
                                    <span><i class="fas fa-calendar-alt"></i> <?php echo htmlspecialchars(date('M d, Y', strtotime($post['Created']))); ?></span>
                                </div>
                            </div>
                            <a href="blog_detail.php?id=<?php echo htmlspecialchars($post['ID']); ?>" class="card-link">Read More</a>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Pagination Links -->
                <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php 
                        // Build query string for pagination links
                        $pagination_query_params = $_GET;
                        unset($pagination_query_params['page']); // Remove current page from params

                        $base_query_string = http_build_query($pagination_query_params);
                        ?>

                        <?php if ($current_page > 1): ?>
                            <a href="?<?php echo $base_query_string; ?>&page=<?php echo $current_page - 1; ?>"><i class="fas fa-chevron-left"></i> Prev</a>
                        <?php else: ?>
                            <span class="disabled"><i class="fas fa-chevron-left"></i> Prev</span>
                        <?php endif; ?>

                        <?php
                        $start_page = max(1, $current_page - 2);
                        $end_page = min($total_pages, $current_page + 2);

                        if ($start_page > 1) {
                            echo '<a href="?' . $base_query_string . '&page=1">1</a>';
                            if ($start_page > 2) {
                                echo '<span>...</span>';
                            }
                        }

                        for ($i = $start_page; $i <= $end_page; $i++): ?>
                            <?php if ($i == $current_page): ?>
                                <span class="current-page"><?php echo $i; ?></span>
                            <?php else: ?>
                                <a href="?<?php echo $base_query_string; ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>

                        <?php
                        if ($end_page < $total_pages) {
                            if ($end_page < $total_pages - 1) {
                                echo '<span>...</span>';
                            }
                            echo '<a href="?' . $base_query_string . '&page=' . $total_pages . '">' . $total_pages . '</a>';
                        }
                        ?>

                        <?php if ($current_page < $total_pages): ?>
                            <a href="?<?php echo $base_query_string; ?>&page=<?php echo $current_page + 1; ?>">Next <i class="fas fa-chevron-right"></i></a>
                        <?php else: ?>
                            <span class="disabled">Next <i class="fas fa-chevron-right"></i></span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

            <?php endif; ?>
        </section>

    </main>

    <?php
    // Include the reusable footer component
    include 'footer.php';
    ?>

    <script>
        function toggleMobileMenu() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerIcon = document.getElementById('hamburgerIcon');

            mobileNavDropdown.classList.toggle('open');
            if (mobileNavDropdown.classList.contains('open')) {
                hamburgerIcon.classList.remove('fa-bars');
                hamburgerIcon.classList.add('fa-times');
            } else {
                hamburgerIcon.classList.remove('fa-times');
                hamburgerIcon.classList.add('fa-bars');
            }
        }

        document.addEventListener('click', function(event) {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerMenu = document.querySelector('.hamburger-menu');

            if (mobileNavDropdown.classList.contains('open') && 
                !mobileNavDropdown.contains(event.target) && 
                !hamburgerMenu.contains(event.target)) {
                toggleMobileMenu();
            }
        });

        window.addEventListener('resize', function() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            if (window.innerWidth > 768 && mobileNavDropdown.classList.contains('open')) {
                toggleMobileMenu();
            }
        });
    </script>

</body>
</html>
