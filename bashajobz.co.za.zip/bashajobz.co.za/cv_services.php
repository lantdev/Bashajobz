<?php
// cv_services.php - CV Services Page for www.bashajobz.co.za

// No direct database connection needed for this static content,
// but including it for consistency with other pages that might
// require it or share session logic.
$db = mysqli_connect('localhost', 'prolance_prolance', '@Airbus360', 'prolance_bashajobz');
if (!$db) {
    error_log("Website DB Connection Failed: " . mysqli_connect_error());
    // Display a general message to the user if DB connection fails
    $db_connection_error = "We are currently experiencing technical difficulties. Please try again later.";
} else {
    $db_connection_error = null;
    mysqli_close($db); // Close immediately if not used for this page
}

// SEO Meta Tags
$pageTitle = "Professional CV & Cover Letter Services | Bashajobz";
$pageDescription = "Boost your job application with Bashajobz's professional CV revamp and custom cover letter writing services. Stand out to employers in South Africa.";
$pageKeywords = "CV revamp South Africa, professional CV writing, cover letter service, resume writing, job application help, career services, Bashajobz CV";

// Define CV packages
$cv_packages = [
    [
        'name' => 'CV Revamp',
        'price' => 'R60',
        'features' => [
            'Professional CV review',
            'Grammar & spelling check',
            'Formatting & layout improvement',
            'Keyword optimization for ATS',
            'Tailored for target roles'
        ],
        'whatsapp_text' => 'Hi, I\'m interested in the CV Revamp service (R60).',
    ],
    [
        'name' => 'Cover Letter',
        'price' => 'R60',
        'features' => [
            'Customized cover letter writing',
            'Highlights key skills & experience',
            'Addresses specific job requirements',
            'Engaging and persuasive content',
            'Professional tone and structure'
        ],
        'whatsapp_text' => 'Hi, I\'m interested in the Cover Letter service (R60).',
    ],
    [
        'name' => 'CV & Cover Letter Combo',
        'price' => 'R100',
        'features' => [
            'All features of CV Revamp',
            'All features of Cover Letter service',
            'Integrated strategy for consistent branding',
            'Priority service',
            'Best value package'
        ],
        'whatsapp_text' => 'Hi, I\'m interested in the CV & Cover Letter Combo service (R100).',
    ],
];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($pageKeywords); ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://www.bashajobz.co.za/cv_services.php">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
          <link rel="icon" href="https://bashajobz.co.za/logo.png" type="image/x-icon">
          <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="apple-touch-icon" sizes="57x57" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://www.bashajobz.co.za/logo.png">
    <style>
        /* General Body and Layout (consistent with other pages) */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #f4f6f9;
            color: #333;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            overflow-x: hidden; /* Prevent horizontal scrolling */
            box-sizing: border-box;
        }

        /* Header/Navbar (Copied for consistency) */
        .main-header {
            background-color: #fff;
            padding: 15px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            width: 100%;
            z-index: 1000;
            box-sizing: border-box;
        }

        .main-header .logo {
            display: flex;
            align-items: center;
        }

        .header-logo {
            height: 50px;
            width: auto;
            max-width: 150px;
            border-radius: 4px;
            object-fit: contain;
            filter: drop-shadow(0 0 2px rgba(0,0,0,0.1));
        }

        .main-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
        }

        .main-nav ul li {
            margin-left: 20px;
        }

        .main-nav ul li a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            padding: 5px 10px;
            transition: color 0.3s ease;
        }

        .main-nav ul li a:hover {
            color: #e67e22; /* Orange hover color */
        }

        .main-nav ul li.signup-btn a {
            background-color: #e67e22; /* Orange button */
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .main-nav ul li.signup-btn a:hover {
            background-color: #d35400; /* Darker orange */
            color: white;
        }
        
        .hamburger-menu {
            display: none;
            font-size: 1.8em;
            cursor: pointer;
            color: #333;
            z-index: 1001;
        }

        .mobile-nav-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background-color: #fff;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            z-index: 998;
            padding: 10px 0;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            overflow-y: auto;
            max-height: calc(100vh - 70px);
            box-sizing: border-box;
            transform: translateY(-10px);
            opacity: 0;
            visibility: hidden;
            transition: transform 0.3s ease-out, opacity 0.3s ease-out, visibility 0.3s ease-out;
        }

        .mobile-nav-dropdown.open {
            display: block;
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }

        .mobile-nav-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center;
            width: 100%;
        }

        .mobile-nav-dropdown ul li {
            margin: 0;
            border-bottom: 1px solid #eee;
        }

        .mobile-nav-dropdown ul li:last-child {
            border-bottom: none;
        }

        .mobile-nav-dropdown ul li a {
            color: #333;
            text-decoration: none;
            font-size: 1.1em;
            padding: 12px 20px;
            display: block;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-weight: 500;
        }

        .mobile-nav-dropdown ul li a:hover {
            background-color: #f0f0f0;
            color: #e67e22; /* Orange hover color */
        }

        .mobile-nav-dropdown ul li.signup-btn a {
            background-color: #e67e22; /* Orange button */
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            margin-top: 10px;
            margin-bottom: 10px;
            width: fit-content;
            margin-left: auto;
            margin-right: auto;
            display: block;
            max-width: 250px;
        }
        .mobile-nav-dropdown ul li.signup-btn a:hover {
            background-color: #d35400; /* Darker orange */
        }

        body.no-scroll {
            overflow: hidden;
        }

        /* --- CV Services Page Specific Styles --- */
        .cv-hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://placehold.co/1920x400/2c3e50/ffffff?text=CV+Services+Banner') no-repeat center center/cover;
            color: white;
            padding: 80px 20px;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            box-sizing: border-box;
        }

        .cv-hero-section h1 {
            font-size: 2.8em;
            margin-bottom: 15px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .cv-hero-section p {
            font-size: 1.1em;
            margin-bottom: 30px;
            max-width: 700px;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        /* Section Container (consistent) */
        .section-container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            box-sizing: border-box;
        }

        .section-title {
            text-align: center;
            color: #2c3e50;
            font-size: 2em;
            margin-bottom: 30px;
            border-bottom: 2px solid #e67e22; /* Orange underline */
            padding-bottom: 10px;
            display: inline-block;
            width: fit-content;
            max-width: 100%;
            box-sizing: border-box;
        }

        /* Pricing Cards Grid */
        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); /* Adjusted min-width for packages */
            gap: 30px;
            margin-top: 30px;
        }

        .card {
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            transition: transform 0.2s ease;
            display: flex;
            flex-direction: column;
            align-items: center; /* Center content horizontally */
            text-align: center; /* Center text within card */
            padding: 25px;
            box-sizing: border-box;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .card h3 {
            font-size: 1.8em;
            color: #2c3e50;
            margin-bottom: 10px;
        }

        .card .price {
            font-size: 2.5em;
            font-weight: bold;
            color: #e67e22; /* Orange price */
            margin-bottom: 20px;
        }

        .card ul {
            list-style: none;
            padding: 0;
            margin: 0 0 25px 0;
            width: 100%;
        }

        .card ul li {
            font-size: 1em;
            color: #555;
            padding: 8px 0;
            border-bottom: 1px dashed #eee; /* Subtle separator */
            display: flex;
            align-items: center;
            justify-content: center; /* Center list items */
        }

        .card ul li:last-child {
            border-bottom: none;
        }

        .card ul li i {
            margin-right: 10px;
            color: #2ecc71; /* Green checkmark */
        }

        .whatsapp-btn {
            display: inline-block;
            background-color: #25D366; /* WhatsApp green */
            color: white;
            padding: 15px 30px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 1.1em;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .whatsapp-btn:hover {
            background-color: #1DA851; /* Darker WhatsApp green */
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        .whatsapp-btn i {
            margin-right: 10px;
        }

        /* Error Message (consistent) */
        .error-message {
            text-align: center;
            padding: 30px;
            font-size: 1.1em;
            color: #c0392b;
            background-color: #ffebee;
            border: 1px solid #e74c3c;
            border-radius: 8px;
            margin: 30px auto;
            max-width: 600px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        .error-message i {
            margin-right: 10px;
            color: #e74c3c;
        }


        /* Responsive adjustments */
        @media (max-width: 768px) {
            .main-header {
                padding: 15px;
                position: relative;
            }
            .hamburger-menu {
                display: block;
            }
            .main-nav {
                display: none;
            }

            .cv-hero-section {
                padding: 60px 15px;
            }
            .cv-hero-section h1 {
                font-size: 2em;
            }
            .cv-hero-section p {
                font-size: 0.9em;
            }

            .section-container {
                margin: 20px auto;
                padding: 15px;
            }
            .section-title {
                font-size: 1.8em;
                margin-left: auto;
                margin-right: auto;
            }
            .cards-grid {
                grid-template-columns: 1fr; /* Single column on mobile */
                gap: 20px;
            }
            .card {
                padding: 20px;
            }
            .card h3 {
                font-size: 1.5em;
            }
            .card .price {
                font-size: 2em;
            }
            .card ul li {
                font-size: 0.9em;
            }
            .whatsapp-btn {
                padding: 12px 25px;
                font-size: 1em;
            }
            .error-message {
                padding: 20px;
                font-size: 1em;
                margin: 20px auto;
            }
        }

        /* Further minor adjustments for very small screens (e.g., less than 400px) */
        @media (max-width: 400px) {
            .cv-hero-section h1 {
                font-size: 1.6em;
            }
            .cv-hero-section p {
                font-size: 0.85em;
            }
            .card h3 {
                font-size: 1.3em;
            }
            .card .price {
                font-size: 1.8em;
            }
            .card ul li {
                font-size: 0.85em;
            }
            .whatsapp-btn {
                padding: 10px 20px;
                font-size: 0.9em;
            }
        }
    </style>
</head>
<body>
    <header class="main-header">
        <a href="index.php" class="logo">
            <img src="logo.png" alt="Bashjobz Logo" class="header-logo" onerror="this.onerror=null;this.src='https://placehold.co/150x50/cccccc/333333?text=Bashajobz';">
        </a>
        <nav class="main-nav">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="jobs.php">Jobs</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="news.php">News</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="cv_services.php">CV Revamp Services</a></li>
                <li><a href="login.php">Login</a></li>
                <li class="signup-btn"><a href="signup.php">Sign Up</a></li>
            </ul>
        </nav>
        <div class="hamburger-menu" onclick="toggleMobileMenu()">
            <i class="fas fa-bars" id="hamburgerIcon"></i>
        </div>

        <!-- Mobile Navigation Dropdown -->
        <nav class="mobile-nav-dropdown" id="mobileNavDropdown">
            <ul>
                <li><a href="index.php" onclick="toggleMobileMenu()">Home</a></li>
                <li><a href="jobs.php" onclick="toggleMobileMenu()">Jobs</a></li>
                <li><a href="blog.php" onclick="toggleMobileMenu()">Blog</a></li>
                <li><a href="news.php" onclick="toggleMobileMenu()">News</a></li>
                <li><a href="contact.php" onclick="toggleMobileMenu()">Contact</a></li>
                <li><a href="cv_services.php" onclick="toggleMobileMenu()">CV Revamp Services</a></li>
                <li><a href="login.php" onclick="toggleMobileMenu()">Login</a></li>
                <li class="signup-btn"><a href="signup.php" onclick="toggleMobileMenu()">Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <?php if ($db_connection_error): ?>
            <div class="error-message">
                <p><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($db_connection_error); ?></p>
            </div>
        <?php endif; ?>

        <section class="cv-hero-section">
            <h1>Elevate Your Career with Professional CV Services</h1>
            <p>Get a standout CV and a compelling Cover Letter that gets you noticed by top employers.</p>
        </section>

        <section class="section-container">
            <h2 class="section-title">Our Affordable Packages</h2>
            
            <div class="cards-grid">
                <?php foreach ($cv_packages as $package): ?>
                    <div class="card cv-package-card">
                        <h3><?php echo htmlspecialchars($package['name']); ?></h3>
                        <div class="price"><?php echo htmlspecialchars($package['price']); ?></div>
                        <ul>
                            <?php foreach ($package['features'] as $feature): ?>
                                <li><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($feature); ?></li>
                            <?php endforeach; ?>
                        </ul>
                        <?php 
                            $whatsapp_number = "27656808961"; // Your WhatsApp number
                            $encoded_text = urlencode($package['whatsapp_text']);
                            $whatsapp_link = "https://wa.me/" . $whatsapp_number . "?text=" . $encoded_text;
                        ?>
                        <a href="<?php echo htmlspecialchars($whatsapp_link); ?>" class="whatsapp-btn" target="_blank" rel="noopener noreferrer">
                            <i class="fab fa-whatsapp"></i> Order Now
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

    </main>

    <?php
    // Include the reusable footer component
    include 'footer.php';
    ?>

    <script>
        function toggleMobileMenu() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerIcon = document.getElementById('hamburgerIcon');

            mobileNavDropdown.classList.toggle('open');
            if (mobileNavDropdown.classList.contains('open')) {
                hamburgerIcon.classList.remove('fa-bars');
                hamburgerIcon.classList.add('fa-times');
            } else {
                hamburgerIcon.classList.remove('fa-times');
                hamburgerIcon.classList.add('fa-bars');
            }
        }

        document.addEventListener('click', function(event) {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerMenu = document.querySelector('.hamburger-menu');

            if (mobileNavDropdown.classList.contains('open') && 
                !mobileNavDropdown.contains(event.target) && 
                !hamburgerMenu.contains(event.target)) {
                toggleMobileMenu();
            }
        });

        window.addEventListener('resize', function() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            if (window.innerWidth > 768 && mobileNavDropdown.classList.contains('open')) {
                toggleMobileMenu();
            }
        });
    </script>

</body>
</html>
