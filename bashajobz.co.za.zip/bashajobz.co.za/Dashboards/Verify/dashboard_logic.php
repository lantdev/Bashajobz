<?php
session_start();

$user_email = '';
$user_token = '';
$success_message = '';
$error_message = '';
$user_first_name = ''; // Initialize to prevent undefined variable notice

// Check if the user is authenticated (Email in session)
if (!isset($_SESSION['Email'])) {
    $_SESSION['msg'] = "You must log in to access this page.";
    header('location: https://bashajobz.co.za/login.php'); // Redirect to login if not logged in
    exit();
}

// Store email from session for display/use
$user_email = htmlspecialchars($_SESSION['Email']);

// Database connection details
$db_host = 'localhost';
$db_user = 'prolance_prolance';
$db_pass = '@Airbus360';
$db_name = 'prolance_bashajobz'; // Corrected to Bashjobz database

$db = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check database connection
if ($db->connect_error) {
    error_log("Bashjobz Verify Dashboard DB Connection Failed: " . $db->connect_error);
    $error_message = "Database connection failed. Please try again later.";
    // Redirect to login if DB is down or connection fails, to prevent further issues
    session_destroy();
    unset($_SESSION['Email']);
    header('location: ../../login.php');
    exit();
} else {
    // Fetch user's token and FirstName from the database using prepared statement
    $stmt_fetch_user = $db->prepare("SELECT Token, FirstName FROM users WHERE Email = ? LIMIT 1");
    if ($stmt_fetch_user) {
        $stmt_fetch_user->bind_param("s", $_SESSION['Email']);
        $stmt_fetch_user->execute();
        $result_fetch_user = $stmt_fetch_user->get_result();
        $user_data = $result_fetch_user->fetch_assoc();
        $stmt_fetch_user->close();

        if ($user_data) {
            $user_token = $user_data['Token'];
            $user_first_name = htmlspecialchars($user_data['FirstName']);
        } else {
            // User somehow not found in DB after session, force re-login
            error_log("User not found in DB for session email: " . $_SESSION['Email'] . " during dashboard load.");
            $error_message = "Your account data could not be retrieved. Please try logging in again.";
            session_destroy();
            unset($_SESSION['Email']);
            header('location: ../../login.php');
            exit();
        }
    } else {
        error_log("Error preparing user fetch statement for verify dashboard: " . $db->error);
        $error_message = "An internal database error occurred. Please try again.";
    }
}

// Handle Logout
if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['Email']);
    $_SESSION['success'] = "You have been successfully logged out.";
    header("location: ../../login.php");
    exit();
}

// Handle Resend Verification Email
// Only proceed if resend button was pressed AND there are no existing critical errors
if (isset($_POST['resend_verification']) && empty($error_message)) {

    if (empty($user_email) || empty($user_token)) {
        $error_message = "Missing user information to resend verification email. Please log out and try again.";
        error_log("Resend attempt failed: Missing user_email or user_token for session email: " . $_SESSION['Email']);
    } else {
        // Prepare email details
        $to = $user_email;
        $subject = 'Verify Your Bashjobz Account';
        $message = '
        <html>
        <head>
            <title>Verify Your Bashjobz Account</title>
            <style>
                body { font-family: Arial, sans-serif; background-color: #f4f4f4; color: #333; padding: 20px; }
                .container { max-width: 600px; margin: 0 auto; background-color: #fff; padding: 20px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); }
                h1 { color: #e67e22; } /* Matching Bashjobz orange */
                p { font-size: 16px; }
                .button { display: inline-block; padding: 10px 20px; font-size: 16px; color: white; background-color: #e67e22; text-decoration: none; border-radius: 5px; }
                .button a { text-decoration: none; font-size: 18px; color: white; }
                .logo { display: block; margin: 0 auto 20px; max-width: 150px; }
            </style>
        </head>
        <body>
            <div class="container">
                <img src="https://bashajobz.co.za/logo.png" alt="Bashjobz Logo" class="logo">
                <h1>Account Verification</h1>
                <p>Hi ' . $user_first_name . ',</p>
                <p>Thank you for registering with Bashjobz! Please click on the link below to verify your account:</p>
                <center> <p><a href="https://bashajobz.co.za/verify.php?email=' . urlencode($user_email) . '&token=' . urlencode($user_token) . '" class="button">Verify Your Account</a></p></center>
                <p>If the button does not work, please copy and paste the following link into your browser:</p>
                <p><a href="https://bashajobz.co.za/verify.php?email=' . urlencode($user_email) . '&token=' . urlencode($user_token) . '">https://bashajobz.co.za/Dashboard/Verify/verify.php?email=' . urlencode($user_email) . '&token=' . urlencode($user_token) . '</a></p>
                <p>Thank you,</p>
                <p>The Bashjobz Team</p>
            </div>
        </body>
        </html>';

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= 'From: "Bashjobz Account Verification" <noreply@bashajobz.co.za>' . "\r\n";

        // Attempt to send email and log success/failure
        if (mail($to, $subject, $message, $headers)) {
            $success_message = "A new verification email has been sent to your inbox. Please check it (and your spam/junk folder).";
            error_log("Verification email successfully resent to: " . $user_email);
        } else {
            error_log("Failed to resend verification email to " . $user_email . ". PHP mail() function returned FALSE.");
            $error_message = "Failed to resend verification email. Please try again later. If the problem persists, contact support.";
        }
    }
}

// Display messages from previous redirects (e.g., from login or signup)
if (isset($_SESSION['success'])) {
    $success_message = $_SESSION['success'];
    unset($_SESSION['success']); // Clear it after display
}
if (isset($_SESSION['error'])) { // Catch for other error messages
    $error_message = $_SESSION['error'];
    unset($_SESSION['error']); // Clear it after display
}
if (isset($_SESSION['msg'])) { // For "You must log in first"
    $error_message = $_SESSION['msg'];
    unset($_SESSION['msg']);
}

// Close database connection if it was successfully opened
if ($db && !$db->connect_error) {
    $db->close();
}
?>