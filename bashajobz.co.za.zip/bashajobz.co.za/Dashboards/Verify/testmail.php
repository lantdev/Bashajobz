<?php
$to = "tlotlomathuloe2@gmail.com"; // Use your actual email
$subject = "Test Email from Bashjobz Server";
$message = "This is a test email sent from your Bashjobz PHP script.";
$headers = "From: noreply@bashajobz.co.za\r\n"; // Use a real sender email on your domain
$headers .= "Reply-To: noreply@bashajobz.co.za\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

if (mail($to, $subject, $message, $headers)) {
    echo "Test email sent successfully!";
} else {
    echo "Test email failed to send. Check server logs.";
}
?>