<?php
session_start();

// Database connection details
// It's highly recommended to use a central config file for DB credentials
$db_host = 'localhost';
$db_user = 'prolance_prolance';
$db_pass = '@Airbus360';
$db_name = 'prolance_bashajobz'; // Corrected to Bashjobz database

$db = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check database connection
if ($db->connect_error) {
    error_log("Bashjobz Verify Page DB Connection Failed: " . $db->connect_error);
    $_SESSION['error'] = "A server error occurred. Please try again later.";
    header('location: login.php'); // Redirect to login page
    exit();
}

// Check if email and token parameters are present in the URL
if (isset($_GET['email']) && isset($_GET['token'])) {
    $email = $_GET['email'];
    $token = $_GET['token'];

    // Input validation: Basic check for empty parameters
    if (empty($email) || empty($token)) {
        $_SESSION['error'] = "Verification link is incomplete.";
        header('location: login.php');
        exit();
    }
    
    // Use prepared statement to select the user
    $stmt_select = $db->prepare("SELECT ID FROM users WHERE Email = ? AND Token = ? LIMIT 1");
    if ($stmt_select) {
        $stmt_select->bind_param("ss", $email, $token);
        $stmt_select->execute();
        $result_select = $stmt_select->get_result();
        $user = $result_select->fetch_assoc();
        $stmt_select->close();

        if ($user) {
            // User found with matching email and token
            // Update user status to 'Verified' and 'Status' to 'Active' or 'New'
            // NOTE: 'New' is often used if there's a profile setup step. If users are immediately active, use 'Active'.
            // Based on your login_server.php logic, 'New' means they need to set up their profile.
            $update_status = 'New';
            $update_verified = 'Yes'; // Assuming 'Yes' is the verified state
            $null_token = NULL; // Clear the token after successful verification to prevent reuse

            $stmt_update = $db->prepare("UPDATE users SET Verified = ?, Status = ?, Token = ? WHERE ID = ?");
            if ($stmt_update) {
                $stmt_update->bind_param("sssi", $update_verified, $update_status, $null_token, $user['ID']);
                
                if ($stmt_update->execute()) {
                    $_SESSION['success'] = "Your Bashjobz account has been successfully verified! Please log in.";
                    header('location: login.php'); // Redirect to Bashjobz login page
                    exit();
                } else {
                    error_log("Error updating user verification status for email: " . $email . " - " . $stmt_update->error);
                    $_SESSION['error'] = "Account verification failed. Please contact support.";
                    header('location: login.php');
                    exit();
                }
                $stmt_update->close();
            } else {
                error_log("Error preparing user update statement for email: " . $email . " - " . $db->error);
                $_SESSION['error'] = "An internal error occurred during verification. Please try again.";
                header('location: login.php');
                exit();
            }
        } else {
            // No user found with that email and token combination
            $_SESSION['error'] = "The verification link is invalid or has expired.";
            header('location: login.php'); // Redirect to login page
            exit();
        }
    } else {
        error_log("Error preparing user select statement for verification: " . $db->error);
        $_SESSION['error'] = "An internal error occurred. Please try again.";
        header('location: login.php');
        exit();
    }
} else {
    // Parameters are missing from the URL
    $_SESSION['error'] = "Verification link is incomplete or malformed.";
    header('location: login.php'); // Redirect to login page
    exit();
}

// Close database connection
if ($db && !$db->connect_error) {
    $db->close();
}
?>