<?php include('dashboard_logic.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../../logo.png" type="image/x-icon">
    <meta name="description" content="Your Bashjobz account is pending verification. Please check your email to activate your account.">
    <meta name="keywords" content="account verification, email verification, Bashjobz, activate account">
    <meta name="author" content="Bashjobz Team">
    <meta name="robots" content="noindex, nofollow"> <meta name="language" content="English">
    <meta name="geo.region" content="ZA">
    <meta name="geo.placename" content="South Africa">
    <title>Verify Account - Bashjobz</title>

    <meta property="og:title" content="Account Verification - Bashjobz">
    <meta property="og:description" content="Your Bashjobz account requires email verification. Check your inbox to complete registration.">
    <meta property="og:image" content="https://bashajobz.co.za/logo.png">
    <meta property="og:url" content="https://bashajobz.co.za/Dashboards/Verify/dashboard.php">
    <meta property="og:type" content="website">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Account Verification - Bashjobz">
    <meta name="twitter:description" content="Verify your Bashjobz account to unlock full access.">
    <meta name="twitter:image" content="https://bashajobz.co.za/logo.png">
    <meta name="twitter:url" content="https://bashajobz.co.za/Dashboards/Verify/dashboard.php">

    <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="apple-touch-icon" sizes="57x57" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://www.bashajobz.co.za/logo.png">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        /* General Body and Layout */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #f4f6f9;
            color: #333;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            overflow-x: hidden;
            background-image: url('../../bigstock-sandton-skyline-87187883.jpg'); /* Adjust path if needed */
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        /* Minimal Top Navigation Bar (based on your example) */
        .minimal-topnav {
            overflow: hidden;
            background-color: white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            box-sizing: border-box;
            z-index: 1000;
        }

        .minimal-topnav .logo-link img {
            height: 50px; /* Consistent logo size */
            width: auto;
            border-radius: 4px; /* Consistent with site logo */
            object-fit: contain;
        }

        .minimal-topnav .logout-button {
            background-color: #e67e22; /* Bashjobz orange */
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 500;
            transition: background-color 0.3s ease, transform 0.2s ease;
            white-space: nowrap; /* Prevent button text wrapping */
            border: none;
            cursor: pointer;
            display: flex; /* For icon and text alignment */
            align-items: center;
            gap: 5px; /* Space between icon and text */
        }

        .minimal-topnav .logout-button:hover {
            background-color: #d35400;
            transform: translateY(-2px);
        }
        
        .minimal-topnav .logout-button i {
            font-size: 1.1em;
        }


        /* Main content area for the dashboard message */
        main {
            flex-grow: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            box-sizing: border-box;
        }

        .verification-message-container {
            max-width: 600px;
            width: 100%;
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            text-align: center;
            box-sizing: border-box;
            color: #333;
        }

        .verification-message-container h1 {
            color: #2c3e50; /* Dark heading */
            font-size: 2.5em;
            margin-bottom: 20px;
        }

        .verification-message-container p {
            font-size: 1.1em;
            margin-bottom: 15px;
        }

        .verification-message-container .icon-large {
            color: #e67e22; /* Bashjobz orange */
            font-size: 4em;
            margin-bottom: 25px;
        }

        .action-button {
            display: inline-block;
            background-color: #e67e22;
            color: white;
            padding: 12px 25px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 1em;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
            margin-top: 20px;
            cursor: pointer; /* Added cursor pointer for button behavior */
            border: none; /* Ensure no default button border */
        }

        .action-button:hover {
            background-color: #d35400;
            transform: translateY(-2px);
        }

        .info-box {
            background-color: #f0f8ff; /* Light blue */
            border-left: 5px solid #2196F3; /* Blue left border */
            padding: 15px;
            margin-top: 25px;
            text-align: left;
            font-size: 0.95em;
            color: #333;
            border-radius: 5px;
        }
        .info-box p {
            margin: 0;
        }

        /* Message Box Styling */
        .message-box {
            background-color: #f0f0f0;
            border-radius: 8px;
            padding: 15px 20px;
            margin-bottom: 25px;
            text-align: center;
            font-size: 1.1em;
            font-weight: 500;
            color: #333;
            box-shadow: 0 1px 5px rgba(0,0,0,0.05);
            border-left: 5px solid #e67e22; /* Default Bashjobz accent */
        }

        .message-box.success {
            background-color: #d4edda;
            color: #155724;
            border-color: #28a745;
        }

        .message-box.error {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #dc3545;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .minimal-topnav {
                padding: 10px 15px;
            }
            .minimal-topnav .logo-link img {
                height: 40px;
            }
            .minimal-topnav .logout-button {
                padding: 6px 12px;
                font-size: 0.9em;
            }

            main { padding: 20px 15px; }
            .verification-message-container {
                padding: 25px;
                margin: 20px 15px;
                max-width: 90%;
            }
            .verification-message-container h1 { font-size: 2em; }
            .verification-message-container p { font-size: 1em; }
            .verification-message-container .icon-large { font-size: 3em; margin-bottom: 20px; }
            .action-button { padding: 10px 20px; font-size: 0.9em; }
            .info-box { font-size: 0.9em; padding: 12px; }
        }

        @media (max-width: 480px) {
            .minimal-topnav .logo-link img {
                height: 35px;
            }
            .minimal-topnav .logout-button {
                padding: 5px 10px;
                font-size: 0.8em;
                gap: 3px;
            }
            .verification-message-container h1 { font-size: 1.8em; }
            .verification-message-container p { font-size: 0.95em; }
            .verification-message-container .icon-large { font-size: 2.5em; }
            .action-button { font-size: 0.85em; }
        }
    </style>
</head>
<body>

    <header class="minimal-topnav">
        <a href="dashboard.php" class="logo-link">
            <img src="../../logo.png" alt="Bashjobz Logo" onerror="this.onerror=null;this.src='https://placehold.co/150x50/cccccc/333333?text=Bashjobz';">
        </a>
        <a href="dashboard.php?logout" class="logout-button">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </header>

    <main>
        <div class="verification-message-container">
            <i class="fas fa-envelope-open-text icon-large"></i>
            <h1>Account Verification Required</h1>

            <?php if (!empty($success_message)): ?>
                <div class="message-box success">
                    <p><?= htmlspecialchars($success_message) ?></p>
                </div>
            <?php endif; ?>

            <?php if (!empty($error_message)): ?>
                <div class="message-box error">
                    <p><?= htmlspecialchars($error_message) ?></p>
                </div>
            <?php endif; ?>

            <p>Welcome, <span style="font-weight: bold;"><?= $user_first_name ?? $user_email ?></span>!</p>
            <p>To fully activate your account and gain access to all features, please verify your email address.</p>
            <p>We've sent a verification link to your inbox at <strong><?= $user_email ?></strong>. Please check your email (and spam/junk folder) and click the link to complete your registration.</p>

            <form method="post" action="">
                <button type="submit" name="resend_verification" class="action-button">Resend Verification Email</button>
            </form>

            <div class="info-box">
                <p><strong>Didn't receive the email?</strong></p>
                <p>
                    1. Check your spam or junk folder.<br>
                    2. Ensure you entered the correct email address.<br>
                    3. If you still can't find it after a few minutes, click "Resend Verification Email" above.
                </p>
            </div>

            <p style="margin-top: 25px;">
                <a href="../../login.php" class="action-button" style="background-color: #2c3e50;">Go to Login Page</a> </p>
        </div>
    </main>

    <script>
        // No mobile menu toggle needed for this simplified header
        // If you decide to add a hamburger menu for this minimal header later,
        // you'd re-introduce the JavaScript function and the hamburger icon HTML.
    </script>
</body>
</html>