<?php
// contact.php - Contact Us Page for www.bashajobz.co.za

// Database connection details
$db = mysqli_connect('localhost', 'prolance_prolance', '@Airbus360', 'prolance_bashajobz');

// Initialize variables for form data and messages
$db_connection_error = null;
$errors = [];
$success_message = '';

$firstName = '';
$lastName = '';
$email = ''; // New: Initialize email variable
$phoneNumber = '';
$whatsApp = '';
$subject = '';
$message = '';

if (!$db) {
    error_log("Website DB Connection Failed: " . mysqli_connect_error());
    $db_connection_error = "We are currently experiencing technical difficulties. Please try again later.";
}

// Function to generate a unique ticket number
function generateTicketNumber() {
    return 'TICKET-' . strtoupper(uniqid()); // Generates unique ID like TICKET-65D4F2C1
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && !$db_connection_error) {
    // Sanitize and escape user inputs
    $firstName = mysqli_real_escape_string($db, $_POST['firstName']);
    $lastName = mysqli_real_escape_string($db, $_POST['lastName']);
    $email = mysqli_real_escape_string($db, $_POST['email']); // New: Sanitize email
    $phoneNumber = mysqli_real_escape_string($db, $_POST['phoneNumber']);
    $whatsApp = mysqli_real_escape_string($db, $_POST['whatsApp'] ?? ''); // WhatsApp is optional
    $subject = mysqli_real_escape_string($db, $_POST['subject']);
    $message = mysqli_real_escape_string($db, $_POST['message']);

    // Form validation
    if (empty($firstName)) { array_push($errors, "First Name is required."); }
    if (empty($lastName)) { array_push($errors, "Last Name is required."); }
    if (empty($email)) { array_push($errors, "Email is required."); } // New: Validate email presence
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { array_push($errors, "Invalid Email format."); } // New: Validate email format
    if (empty($phoneNumber)) { array_push($errors, "Phone Number is required."); }
    if (empty($subject)) { array_push($errors, "Subject is required."); }
    if (empty($message)) { array_push($errors, "Message is required."); }

    // Basic phone number validation (can be enhanced with regex for specific formats)
    if (!empty($phoneNumber) && !preg_match("/^[0-9\s\-\(\)\+]+$/", $phoneNumber)) {
        array_push($errors, "Invalid Phone Number format.");
    }
    if (!empty($whatsApp) && !preg_match("/^[0-9\s\-\(\)\+]+$/", $whatsApp)) {
        array_push($errors, "Invalid WhatsApp Number format.");
    }

    // If no errors, save contact message to database and send email
    if (count($errors) == 0) {
        $ticketNumber = generateTicketNumber();
        $status = 'Open'; // Default status for new tickets
        $created = date('Y-m-d H:i:s'); // Timestamp for 'Created'
        $date_field = date('Y-m-d'); // Date for 'Date' field (assuming a date-only column)

        // SQL INSERT query - updated to include 'Email'
        $query = "INSERT INTO `contacts` (FirstName, LastName, Email, PhoneNumber, WhatsApp, Subject, Message, TicketNumber, Status, Created, Date)
                  VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"; // 11 placeholders now

        // Prepare and bind parameters for security
        $stmt = mysqli_prepare($db, $query);
        if ($stmt === false) {
            array_push($errors, "Database error preparing statement: " . mysqli_error($db));
            error_log("Database error preparing contact form statement: " . mysqli_error($db));
        } else {
            // Updated bind_param type string and variables for 'Email'
            mysqli_stmt_bind_param($stmt, "sssssssssss", 
                $firstName, $lastName, $email, $phoneNumber, $whatsApp, $subject, $message, $ticketNumber, $status, $created, $date_field
            );

            if (mysqli_stmt_execute($stmt)) {
                $success_message = "Your message has been sent successfully! Your Ticket Number is: <strong>" . htmlspecialchars($ticketNumber) . "</strong>. We will get back to you soon.";

                // --- Send Email Notification ---
                $to = 'info@bashajobz.co.za'; // The recipient email address
                $email_subject = "New Contact Inquiry: " . $subject . " (Ticket: " . $ticketNumber . ")";
                
                $email_body = "Hello Bashajobz Team,\n\n";
                $email_body .= "A new contact inquiry has been submitted via your website:\n\n";
                $email_body .= "Ticket Number: " . $ticketNumber . "\n";
                $email_body .= "Subject: " . $subject . "\n";
                $email_body .= "Sender Name: " . $firstName . " " . $lastName . "\n";
                $email_body .= "Sender Email: " . $email . "\n"; // New: Include sender's email
                $email_body .= "Phone Number: " . $phoneNumber . "\n";
                if (!empty($whatsApp)) {
                    $email_body .= "WhatsApp: " . $whatsApp . "\n";
                }
                $email_body .= "Message:\n" . $message . "\n\n";
                $email_body .= "Submitted On: " . $created . "\n\n";
                $email_body .= "Please log into the admin dashboard to manage this ticket.\n";

                $headers = "From: no-reply@bashajobz.co.za\r\n"; // Replace with your actual sender email
                $headers .= "Reply-To: " . $email . "\r\n"; // Updated: Use sender's email for reply-to
                $headers .= "X-Mailer: PHP/" . phpversion();

                if (mail($to, $email_subject, $email_body, $headers)) {
                    error_log("Contact form email sent successfully for Ticket: " . $ticketNumber);
                } else {
                    error_log("ERROR: Contact form email failed to send for Ticket: " . $ticketNumber);
                }

                // Clear form fields after successful submission
                $firstName = $lastName = $email = $phoneNumber = $whatsApp = $subject = $message = '';
            } else {
                array_push($errors, "Error saving your message: " . mysqli_stmt_error($stmt));
                error_log("Database error executing contact form statement: " . mysqli_stmt_error($stmt));
            }
            mysqli_stmt_close($stmt);
        }
    }
}

// Close database connection
if ($db) {
    mysqli_close($db);
}

// SEO Meta Tags
$pageTitle = "Contact Us - Bashajobz";
$pageDescription = "Get in touch with Bashajobz for any inquiries, support, feedback, or assistance with job applications and career services.";
$pageKeywords = "contact Bashajobz, Bashajobz support, job portal contact, career services contact, South Africa jobs help, Bashajobz email";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($pageKeywords); ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://www.bashajobz.co.za/contact.php">
          <link rel="icon" href="https://bashajobz.co.za/logo.png" type="image/x-icon">
          <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="apple-touch-icon" sizes="57x57" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://www.bashajobz.co.za/logo.png">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* General Body and Layout (consistent with other pages) */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #f4f6f9;
            color: #333;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            overflow-x: hidden; /* Prevent horizontal scrolling */
            box-sizing: border-box;
        }

        /* Header/Navbar (Copied for consistency) */
        .main-header {
            background-color: #fff;
            padding: 15px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            width: 100%;
            z-index: 1000;
            box-sizing: border-box;
        }

        .main-header .logo {
            display: flex;
            align-items: center;
        }

        .header-logo {
            height: 50px;
            width: auto;
            max-width: 150px;
            border-radius: 4px;
            object-fit: contain;
            filter: drop-shadow(0 0 2px rgba(0,0,0,0.1));
        }

        .main-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
        }

        .main-nav ul li {
            margin-left: 20px;
        }

        .main-nav ul li a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            padding: 5px 10px;
            transition: color 0.3s ease;
        }

        .main-nav ul li a:hover {
            color: #e67e22; /* Orange hover color */
        }

        .main-nav ul li.signup-btn a {
            background-color: #e67e22; /* Orange button */
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .main-nav ul li.signup-btn a:hover {
            background-color: #d35400; /* Darker orange */
            color: white;
        }
        
        .hamburger-menu {
            display: none;
            font-size: 1.8em;
            cursor: pointer;
            color: #333;
            z-index: 1001;
        }

        .mobile-nav-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background-color: #fff;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            z-index: 998;
            padding: 10px 0;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            overflow-y: auto;
            max-height: calc(100vh - 70px);
            box-sizing: border-box;
            transform: translateY(-10px);
            opacity: 0;
            visibility: hidden;
            transition: transform 0.3s ease-out, opacity 0.3s ease-out, visibility 0.3s ease-out;
        }

        .mobile-nav-dropdown.open {
            display: block;
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }

        .mobile-nav-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center;
            width: 100%;
        }

        .mobile-nav-dropdown ul li {
            margin: 0;
            border-bottom: 1px solid #eee;
        }

        .mobile-nav-dropdown ul li:last-child {
            border-bottom: none;
        }

        .mobile-nav-dropdown ul li a {
            color: #333;
            text-decoration: none;
            font-size: 1.1em;
            padding: 12px 20px;
            display: block;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-weight: 500;
        }

        .mobile-nav-dropdown ul li a:hover {
            background-color: #f0f0f0;
            color: #e67e22; /* Orange hover color */
        }

        .mobile-nav-dropdown ul li.signup-btn a {
            background-color: #e67e22; /* Orange button */
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            margin-top: 10px;
            margin-bottom: 10px;
            width: fit-content;
            margin-left: auto;
            margin-right: auto;
            display: block;
            max-width: 250px;
        }
        .mobile-nav-dropdown ul li.signup-btn a:hover {
            background-color: #d35400; /* Darker orange */
        }

        body.no-scroll {
            overflow: hidden;
        }

        /* --- Contact Page Specific Styles --- */
        .contact-hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://placehold.co/1920x400/2c3e50/ffffff?text=Contact+Us') no-repeat center center/cover;
            color: white;
            padding: 80px 20px;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            box-sizing: border-box;
        }

        .contact-hero-section h1 {
            font-size: 2.8em;
            margin-bottom: 15px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .contact-hero-section p {
            font-size: 1.1em;
            margin-bottom: 30px;
            max-width: 700px;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .contact-form-container {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            box-sizing: border-box;
        }

        .contact-form-container h2 {
            text-align: center;
            color: #2c3e50;
            font-size: 2em;
            margin-bottom: 30px;
            border-bottom: 2px solid #e67e22; /* Orange underline */
            padding-bottom: 10px;
            display: inline-block;
            width: fit-content;
            max-width: 100%;
            margin-left: auto;
            margin-right: auto;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }

        .form-group input[type="text"],
        .form-group input[type="email"], /* Added email type */
        .form-group input[type="tel"],
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1em;
            box-sizing: border-box;
            background-color: #f9f9f9;
        }

        .form-group textarea {
            min-height: 120px;
            resize: vertical;
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: #e67e22;
            box-shadow: 0 0 5px rgba(230, 126, 34, 0.3);
        }

        .contact-submit-btn {
            background-color: #e67e22; /* Orange button */
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            width: 100%;
            box-sizing: border-box;
        }

        .contact-submit-btn:hover {
            background-color: #d35400; /* Darker orange */
            transform: translateY(-2px);
        }

        /* Message Alerts */
        .alert-message {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 8px;
            font-size: 1em;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert-message i {
            font-size: 1.2em;
        }
        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }
        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .main-header {
                padding: 15px;
                position: relative;
            }
            .hamburger-menu {
                display: block;
            }
            .main-nav {
                display: none;
            }

            .contact-hero-section {
                padding: 60px 15px;
            }
            .contact-hero-section h1 {
                font-size: 2em;
            }
            .contact-hero-section p {
                font-size: 0.9em;
            }

            .contact-form-container {
                margin: 20px auto;
                padding: 20px;
                border-radius: 8px;
            }

            .contact-form-container h2 {
                font-size: 1.8em;
            }

            .form-group input,
            .form-group textarea,
            .form-group select,
            .contact-submit-btn {
                padding: 10px 12px;
                font-size: 0.95em;
            }
        }

        /* Further minor adjustments for very small screens (e.g., less than 400px) */
        @media (max-width: 400px) {
            .contact-form-container {
                padding: 15px;
            }
            .contact-hero-section h1 {
                font-size: 1.6em;
            }
            .contact-hero-section p {
                font-size: 0.85em;
            }
        }
    </style>
</head>
<body>
    <header class="main-header">
        <a href="index.php" class="logo">
            <img src="logo.png" alt="Bashjobz Logo" class="header-logo" onerror="this.onerror=null;this.src='https://placehold.co/150x50/cccccc/333333?text=Bashajobz';">
        </a>
        <nav class="main-nav">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="jobs.php">Jobs</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="news.php">News</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="cv_services.php">CV Revamp Services</a></li>
                <li><a href="login.php">Login</a></li>
                <li class="signup-btn"><a href="signup.php">Sign Up</a></li>
            </ul>
        </nav>
        <div class="hamburger-menu" onclick="toggleMobileMenu()">
            <i class="fas fa-bars" id="hamburgerIcon"></i>
        </div>

        <!-- Mobile Navigation Dropdown -->
        <nav class="mobile-nav-dropdown" id="mobileNavDropdown">
            <ul>
                <li><a href="index.php" onclick="toggleMobileMenu()">Home</a></li>
                <li><a href="jobs.php" onclick="toggleMobileMenu()">Jobs</a></li>
                <li><a href="blog.php" onclick="toggleMobileMenu()">Blog</a></li>
                <li><a href="news.php" onclick="toggleMobileMenu()">News</a></li>
                <li><a href="contact.php" onclick="toggleMobileMenu()">Contact</a></li>
                <li><a href="cv_services.php" onclick="toggleMobileMenu()">CV Revamp Services</a></li>
                <li><a href="login.php" onclick="toggleMobileMenu()">Login</a></li>
                <li class="signup-btn"><a href="signup.php" onclick="toggleMobileMenu()">Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="contact-hero-section">
            <h1>Get In Touch With Bashajobz</h1>
            <p>We're here to help! Send us a message and we'll respond as soon as possible.</p>
        </section>

        <section class="contact-form-container">
            <h2>Send Us A Message</h2>

            <?php if ($db_connection_error): ?>
                <div class="alert-message alert-danger">
                    <p><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($db_connection_error); ?></p>
                </div>
            <?php endif; ?>

            <?php if (count($errors) > 0) : ?>
                <div class="alert-message alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php foreach ($errors as $error) : ?>
                        <p><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach ?>
                </div>
            <?php endif ?>

            <?php if (!empty($success_message)) : ?>
                <div class="alert-message alert-success">
                    <i class="fas fa-check-circle"></i>
                    <p><?php echo $success_message; ?></p>
                </div>
            <?php endif ?>

            <form action="contact.php" method="post">
                <div class="form-group">
                    <label for="firstName">First Name</label>
                    <input type="text" id="firstName" name="firstName" value="<?php echo htmlspecialchars($firstName); ?>" required>
                </div>
                <div class="form-group">
                    <label for="lastName">Last Name</label>
                    <input type="text" id="lastName" name="lastName" value="<?php echo htmlspecialchars($lastName); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email Address</label> <!-- New Email Field -->
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                </div>
                <div class="form-group">
                    <label for="phoneNumber">Phone Number</label>
                    <input type="tel" id="phoneNumber" name="phoneNumber" value="<?php echo htmlspecialchars($phoneNumber); ?>" required>
                </div>
                <div class="form-group">
                    <label for="whatsApp">WhatsApp Number (Optional)</label>
                    <input type="tel" id="whatsApp" name="whatsApp" value="<?php echo htmlspecialchars($whatsApp); ?>">
                </div>
                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" id="subject" name="subject" value="<?php echo htmlspecialchars($subject); ?>" required>
                </div>
                <div class="form-group">
                    <label for="message">Your Message</label>
                    <textarea id="message" name="message" required><?php echo htmlspecialchars($message); ?></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="contact-submit-btn">Send Message <i class="fas fa-paper-plane"></i></button>
                </div>
            </form>
        </section>
    </main>

    <?php
    // Include the reusable footer component
    include 'footer.php';
    ?>

    <script>
        function toggleMobileMenu() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerIcon = document.getElementById('hamburgerIcon');

            mobileNavDropdown.classList.toggle('open');
            if (mobileNavDropdown.classList.contains('open')) {
                hamburgerIcon.classList.remove('fa-bars');
                hamburgerIcon.classList.add('fa-times');
            } else {
                hamburgerIcon.classList.remove('fa-times');
                hamburgerIcon.classList.add('fa-bars');
            }
        }

        document.addEventListener('click', function(event) {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerMenu = document.querySelector('.hamburger-menu');

            if (mobileNavDropdown.classList.contains('open') && 
                !mobileNavDropdown.contains(event.target) && 
                !hamburgerMenu.contains(event.target)) {
                toggleMobileMenu();
            }
        });

        window.addEventListener('resize', function() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            if (window.innerWidth > 768 && mobileNavDropdown.classList.contains('open')) {
                toggleMobileMenu();
            }
        });
    </script>

</body>
</html>
