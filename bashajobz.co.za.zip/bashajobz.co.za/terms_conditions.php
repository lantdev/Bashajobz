<?php
// terms_conditions.php - Terms & Conditions Page for www.bashajobz.co.za

// No direct database connection needed for this static content,
// but including it for consistency with other pages that might
// require it or share session logic (e.g., for header/footer).
$db = mysqli_connect('localhost', 'prolance_prolance', '@Airbus360', 'prolance_bashajobz');
if (!$db) {
    error_log("Website DB Connection Failed: " . mysqli_connect_error());
    // Display a general message to the user if DB connection fails
    $db_connection_error = "We are currently experiencing technical difficulties. Please try again later.";
} else {
    $db_connection_error = null;
    mysqli_close($db); // Close immediately if not used for this page
}

// SEO Meta Tags
$pageTitle = "Terms & Conditions | Bashajobz";
$pageDescription = "Read the Terms & Conditions for using Bashajobz job portal. Understand your rights and obligations when using our website and services.";
$pageKeywords = "terms and conditions, Bashajobz terms, website usage rules, user agreement, legal terms, site policies";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($pageKeywords); ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://www.bashajobz.co.za/terms_conditions.php">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
          <link rel="icon" href="https://bashajobz.co.za/logo.png" type="image/x-icon">
          <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="apple-touch-icon" sizes="57x57" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://www.bashajobz.co.za/logo.png">
    <style>
        /* General Body and Layout (consistent with other pages) */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #f4f6f9;
            color: #333;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            overflow-x: hidden; /* Prevent horizontal scrolling */
            box-sizing: border-box;
        }

        /* Header/Navbar (Copied for consistency) */
        .main-header {
            background-color: #fff;
            padding: 15px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            width: 100%;
            z-index: 1000;
            box-sizing: border-box;
        }

        .main-header .logo {
            display: flex;
            align-items: center;
        }

        .header-logo {
            height: 50px;
            width: auto;
            max-width: 150px;
            border-radius: 4px;
            object-fit: contain;
            filter: drop-shadow(0 0 2px rgba(0,0,0,0.1));
        }

        .main-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
        }

        .main-nav ul li {
            margin-left: 20px;
        }

        .main-nav ul li a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            padding: 5px 10px;
            transition: color 0.3s ease;
        }

        .main-nav ul li a:hover {
            color: #e67e22; /* Orange hover color */
        }

        .main-nav ul li.signup-btn a {
            background-color: #e67e22; /* Orange button */
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .main-nav ul li.signup-btn a:hover {
            background-color: #d35400; /* Darker orange */
            color: white;
        }
        
        .hamburger-menu {
            display: none;
            font-size: 1.8em;
            cursor: pointer;
            color: #333;
            z-index: 1001;
        }

        .mobile-nav-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background-color: #fff;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            z-index: 998;
            padding: 10px 0;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            overflow-y: auto;
            max-height: calc(100vh - 70px);
            box-sizing: border-box;
            transform: translateY(-10px);
            opacity: 0;
            visibility: hidden;
            transition: transform 0.3s ease-out, opacity 0.3s ease-out, visibility 0.3s ease-out;
        }

        .mobile-nav-dropdown.open {
            display: block;
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }

        .mobile-nav-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center;
            width: 100%;
        }

        .mobile-nav-dropdown ul li {
            margin: 0;
            border-bottom: 1px solid #eee;
        }

        .mobile-nav-dropdown ul li:last-child {
            border-bottom: none;
        }

        .mobile-nav-dropdown ul li a {
            color: #333;
            text-decoration: none;
            font-size: 1.1em;
            padding: 12px 20px;
            display: block;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-weight: 500;
        }

        .mobile-nav-dropdown ul li a:hover {
            background-color: #f0f0f0;
            color: #e67e22; /* Orange hover color */
        }

        .mobile-nav-dropdown ul li.signup-btn a {
            background-color: #e67e22; /* Orange button */
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            margin-top: 10px;
            margin-bottom: 10px;
            width: fit-content;
            margin-left: auto;
            margin-right: auto;
            display: block;
            max-width: 250px;
        }
        .mobile-nav-dropdown ul li.signup-btn a:hover {
            background-color: #d35400; /* Darker orange */
        }

        body.no-scroll {
            overflow: hidden;
        }

        /* --- Terms & Conditions Page Specific Styles --- */
        .terms-hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://placehold.co/1920x400/2c3e50/ffffff?text=Terms+Conditions+Banner') no-repeat center center/cover;
            color: white;
            padding: 80px 20px;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            box-sizing: border-box;
        }

        .terms-hero-section h1 {
            font-size: 2.8em;
            margin-bottom: 15px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .terms-hero-section p {
            font-size: 1.1em;
            margin-bottom: 30px;
            max-width: 700px;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .terms-content-container {
            max-width: 900px;
            margin: 40px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            box-sizing: border-box;
        }

        .terms-content-container h1.main-heading { /* Specific style for the main terms title */
            font-size: 2.5em;
            color: #2c3e50;
            margin-bottom: 20px;
            text-align: center;
            border-bottom: 2px solid #e67e22; /* Orange underline */
            padding-bottom: 15px;
            display: inline-block;
            width: fit-content;
            max-width: 100%;
            margin-left: auto;
            margin-right: auto;
        }

        .terms-content-container h2 {
            font-size: 1.8em;
            color: #e67e22; /* Orange for section headings */
            margin-top: 30px;
            margin-bottom: 15px;
            border-left: 5px solid #2c3e50; /* Dark sidebar color for accent */
            padding-left: 10px;
        }

        .terms-content-container p {
            font-size: 1em;
            line-height: 1.8;
            margin-bottom: 1em;
        }

        .terms-content-container ul {
            list-style: disc; /* Use standard disc bullets */
            padding-left: 25px;
            margin-bottom: 1em;
        }

        .terms-content-container ol {
            list-style: decimal; /* Use standard decimal numbering */
            padding-left: 25px;
            margin-bottom: 1em;
        }

        .terms-content-container li {
            margin-bottom: 0.5em;
        }

        .terms-content-container a {
            color: #e67e22; /* Orange for links within policy text */
            text-decoration: underline;
            transition: color 0.3s ease;
        }
        .terms-content-container a:hover {
            color: #d35400;
        }

        .terms-last-updated {
            text-align: right;
            font-size: 0.9em;
            color: #777;
            margin-top: 30px;
            border-top: 1px solid #eee;
            padding-top: 15px;
        }

        /* Error Message (consistent) */
        .error-message {
            text-align: center;
            padding: 30px;
            font-size: 1.1em;
            color: #c0392b;
            background-color: #ffebee;
            border: 1px solid #e74c3c;
            border-radius: 8px;
            margin: 30px auto;
            max-width: 600px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        .error-message i {
            margin-right: 10px;
            color: #e74c3c;
        }


        /* Responsive adjustments */
        @media (max-width: 768px) {
            .main-header {
                padding: 15px;
                position: relative;
            }
            .hamburger-menu {
                display: block;
            }
            .main-nav {
                display: none;
            }

            .terms-hero-section {
                padding: 60px 15px;
            }
            .terms-hero-section h1 {
                font-size: 2em;
            }
            .terms-hero-section p {
                font-size: 0.9em;
            }

            .terms-content-container {
                margin: 20px auto;
                padding: 20px;
                border-radius: 8px;
            }

            .terms-content-container h1.main-heading {
                font-size: 1.8em;
            }

            .terms-content-container h2 {
                font-size: 1.5em;
            }

            .terms-content-container p,
            .terms-content-container ul,
            .terms-content-container ol {
                font-size: 0.95em;
            }
            .error-message {
                padding: 20px;
                font-size: 1em;
                margin: 20px auto;
            }
        }

        /* Further minor adjustments for very small screens (e.g., less than 400px) */
        @media (max-width: 400px) {
            .terms-content-container {
                padding: 15px;
            }
            .terms-hero-section h1 {
                font-size: 1.6em;
            }
            .terms-hero-section p {
                font-size: 0.85em;
            }
            .terms-content-container h1.main-heading {
                font-size: 1.5em;
            }
            .terms-content-container h2 {
                font-size: 1.3em;
            }
            .terms-content-container p,
            .terms-content-container ul,
            .terms-content-container ol {
                font-size: 0.9em;
            }
        }
    </style>
</head>
<body>
    <header class="main-header">
        <a href="index.php" class="logo">
            <img src="logo.png" alt="Bashjobz Logo" class="header-logo" onerror="this.onerror=null;this.src='https://placehold.co/150x50/cccccc/333333?text=Bashajobz';">
        </a>
        <nav class="main-nav">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="jobs.php">Jobs</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="news.php">News</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="cv_services.php">CV Revamp Services</a></li>
                <li><a href="login.php">Login</a></li>
                <li class="signup-btn"><a href="signup.php">Sign Up</a></li>
            </ul>
        </nav>
        <div class="hamburger-menu" onclick="toggleMobileMenu()">
            <i class="fas fa-bars" id="hamburgerIcon"></i>
        </div>

        <!-- Mobile Navigation Dropdown -->
        <nav class="mobile-nav-dropdown" id="mobileNavDropdown">
            <ul>
                <li><a href="index.php" onclick="toggleMobileMenu()">Home</a></li>
                <li><a href="jobs.php" onclick="toggleMobileMenu()">Jobs</a></li>
                <li><a href="blog.php" onclick="toggleMobileMenu()">Blog</a></li>
                <li><a href="news.php" onclick="toggleMobileMenu()">News</a></li>
                <li><a href="contact.php" onclick="toggleMobileMenu()">Contact</a></li>
                <li><a href="cv_services.php" onclick="toggleMobileMenu()">CV Revamp Services</a></li>
                <li><a href="login.php" onclick="toggleMobileMenu()">Login</a></li>
                <li class="signup-btn"><a href="signup.php" onclick="toggleMobileMenu()">Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <?php if ($db_connection_error): ?>
            <div class="error-message">
                <p><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($db_connection_error); ?></p>
            </div>
        <?php endif; ?>

        <section class="terms-hero-section">
            <h1>Terms & Conditions</h1>
            <p>Please read these terms carefully before using our services.</p>
        </section>

        <section class="terms-content-container">
            <h1 class="main-heading">Terms and Conditions for Bashajobz</h1>

            <p><strong>Last updated: June 25, 2025</strong></p>

            <p>Welcome to Bashajobz! These terms and conditions outline the rules and regulations for the use of Bashajobz's Website, located at www.bashajobz.co.za.</p>

            <p>By accessing this website we assume you accept these terms and conditions. Do not continue to use Bashajobz if you do not agree to take all of the terms and conditions stated on this page.</p>

            <h2>1. Intellectual Property Rights</h2>
            <p>Other than the content you own, under these Terms, Bashajobz and/or its licensors own all the intellectual property rights and materials contained in this Website. You are granted a limited license only for purposes of viewing the material contained on this Website.</p>

            <h2>2. Restrictions</h2>
            <p>You are specifically restricted from all of the following:</p>
            <ul>
                <li>publishing any Website material in any other media;</li>
                <li>selling, sublicensing and/or otherwise commercializing any Website material;</li>
                <li>publicly performing and/or showing any Website material;</li>
                <li>using this Website in any way that is or may be damaging to this Website;</li>
                <li>using this Website in any way that impacts user access to this Website;</li>
                <li>using this Website contrary to applicable laws and regulations, or in any way may cause harm to the Website, or to any person or business entity;</li>
                <li>engaging in any data mining, data harvesting, data extracting or any other similar activity in relation to this Website;</li>
                <li>using this Website to engage in any advertising or marketing.</li>
            </ul>
            <p>Certain areas of this Website are restricted from being access by you and Bashajobz may further restrict access by you to any areas of this Website, at any time, in absolute discretion. Any user ID and password you may have for this Website are confidential and you must maintain confidentiality as well.</p>

            <h2>3. Your Content</h2>
            <p>In these Website Standard Terms and Conditions, "Your Content" shall mean any audio, video text, images or other material you choose to display on this Website. By displaying Your Content, you grant Bashajobz a non-exclusive, worldwide irrevocable, sub licensable license to use, reproduce, adapt, publish, translate and distribute it in any and all media.</p>
            <p>Your Content must be your own and must not be invading any third-party’s rights. Bashajobz reserves the right to remove any of Your Content from this Website at any time without notice.</p>

            <h2>4. No Warranties</h2>
            <p>This Website is provided "as is," with all faults, and Bashajobz express no representations or warranties, of any kind related to this Website or the materials contained on this Website. Also, nothing contained on this Website shall be interpreted as advising you.</p>

            <h2>5. Limitation of Liability</h2>
            <p>In no event shall Bashajobz, nor any of its officers, directors and employees, shall be held liable for anything arising out of or in any way connected with your use of this Website whether such liability is under contract. Bashajobz, including its officers, directors and employees shall not be held liable for any indirect, consequential or special liability arising out of or in any way related to your use of this Website.</p>

            <h2>6. Indemnification</h2>
            <p>You hereby indemnify to the fullest extent Bashajobz from and against any and/or all liabilities, costs, demands, causes of action, damages and expenses arising in any way related to your breach of any of the provisions of these Terms.</p>

            <h2>7. Severability</h2>
            <p>If any provision of these Terms is found to be invalid under any applicable law, such provisions shall be deleted without affecting the remaining provisions herein.</p>

            <h2>8. Variation of Terms</h2>
            <p>Bashajobz is permitted to revise these Terms at any time as it sees fit, and by using this Website you are expected to review these Terms on a regular basis.</p>

            <h2>9. Assignment</h2>
            <p>The Bashajobz is allowed to assign, transfer, and subcontract its rights and/or obligations under these Terms without any notification. However, you are not allowed to assign, transfer, or subcontract any of your rights and/or obligations under these Terms.</p>

            <h2>10. Entire Agreement</h2>
            <p>These Terms constitute the entire agreement between Bashajobz and you in relation to your use of this Website, and supersede all prior agreements and understandings.</p>

            <h2>11. Governing Law & Jurisdiction</h2>
            <p>These Terms will be governed by and interpreted in accordance with the laws of the Republic of South Africa, and you submit to the non-exclusive jurisdiction of the state and federal courts located in South Africa for the resolution of any disputes.</p>

            <div class="terms-last-updated">
                <p>Generated by Bashajobz.co.za on June 25, 2025.</p>
            </div>
        </section>
    </main>

    <?php
    // Include the reusable footer component
    include 'footer.php';
    ?>

    <script>
        function toggleMobileMenu() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerIcon = document.getElementById('hamburgerIcon');

            mobileNavDropdown.classList.toggle('open');
            if (mobileNavDropdown.classList.contains('open')) {
                hamburgerIcon.classList.remove('fa-bars');
                hamburgerIcon.classList.add('fa-times');
            } else {
                hamburgerIcon.classList.remove('fa-times');
                hamburgerIcon.classList.add('fa-bars');
            }
        }

        document.addEventListener('click', function(event) {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerMenu = document.querySelector('.hamburger-menu');

            if (mobileNavDropdown.classList.contains('open') && 
                !mobileNavDropdown.contains(event.target) && 
                !hamburgerMenu.contains(event.target)) {
                toggleMobileMenu();
            }
        });

        window.addEventListener('resize', function() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            if (window.innerWidth > 768 && mobileNavDropdown.classList.contains('open')) {
                toggleMobileMenu();
            }
        });
    </script>

</body>
</html>
