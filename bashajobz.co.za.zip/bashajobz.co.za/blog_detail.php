<?php
// blog_detail.php - Single Blog Post Page for www.bashajobz.co.za

// Database connection details
$db = mysqli_connect('localhost', 'prolance_prolance', '@Airbus360', 'prolance_bashajobz');

// Initialize variables for blog data and error
$blog_details = null;
$db_connection_error = null;
$blog_not_found = false;

if (!$db) {
    error_log("Website DB Connection Failed: " . mysqli_connect_error());
    $db_connection_error = "We are currently experiencing technical difficulties. Please try again later.";
} else {
    // Get blog ID from URL
    $blog_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

    // Validate blog ID
    if ($blog_id > 0) {
        // Fetch specific blog details
        $query_blog_detail = "SELECT b.ID, b.Title, b.Slug, b.Picture, b.Description, b.Created, b.Username, b.FirstName, b.LastName, a.Account 
                              FROM blog b 
                              JOIN admin a ON b.UserID = a.ID 
                              WHERE b.ID = ? AND b.Status = 'Published' LIMIT 1";
        
        $stmt = mysqli_prepare($db, $query_blog_detail);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "i", $blog_id); // 'i' for integer
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if ($result && mysqli_num_rows($result) > 0) {
                $blog_details = mysqli_fetch_assoc($result);

                // Optional: Increment view count
                // This is a basic view counter, for more robust solutions, consider rate limiting
                // or a separate logging mechanism to avoid inflating views on refresh.
                $update_views_query = "UPDATE blog SET Views = Views + 1 WHERE ID = ?";
                $stmt_views = mysqli_prepare($db, $update_views_query);
                if ($stmt_views) {
                    mysqli_stmt_bind_param($stmt_views, "i", $blog_id);
                    mysqli_stmt_execute($stmt_views);
                    mysqli_stmt_close($stmt_views);
                } else {
                    error_log("Error updating blog views: " . mysqli_error($db));
                }

            } else {
                $blog_not_found = true; // Blog not found or not published
            }
            mysqli_stmt_close($stmt);
        } else {
            error_log("Error preparing blog detail query: " . mysqli_error($db));
            $db_connection_error = "Failed to retrieve blog details. Please try again.";
        }
    } else {
        $blog_not_found = true; // Invalid blog ID
    }

    mysqli_close($db); // Close database connection
}

// SEO Meta Tags (Dynamic based on blog details)
$pageTitle = "Blog Post Not Found | Bashajobz Blog";
$pageDescription = "The blog post you are looking for could not be found or has been removed.";
$pageKeywords = "blog not found, Bashajobz blog";

// Schema.org BlogPosting structured data (Dynamic)
$json_ld_schema = '';

if ($blog_details) {
    $pageTitle = htmlspecialchars($blog_details['Title']) . " | Bashajobz Blog";
    $pageDescription = htmlspecialchars(substr(strip_tags($blog_details['Description']), 0, 160)) . '...';
    $pageKeywords = htmlspecialchars($blog_details['Title']) . ", " . htmlspecialchars($blog_details['FirstName'] . ' ' . $blog_details['LastName']) . ", " . htmlspecialchars($blog_details['Slug']) . ", Bashajobz blog";

    // Determine blog image URL for Schema.org
    $blog_image_url = '';
    if (!empty($blog_details['Picture'])) {
        $dynamic_blog_picture_dir = "https://admin.bashajobz.co.za/Dashboards/" . htmlspecialchars($blog_details['Account']) . "/uploads/Blogs/";
        $blog_image_url = $dynamic_blog_picture_dir . htmlspecialchars($blog_details['Picture']);
    } else {
        $blog_image_url = 'https://placehold.co/400x200?text=No+Image'; // Fallback
    }

    // Prepare BlogPosting Schema.org JSON-LD
    $json_ld_schema = '<script type="application/ld+json">' . json_encode([
        "@context" => "https://schema.org",
        "@type" => "BlogPosting",
        "mainEntityOfPage" => [
            "@type" => "WebPage",
            "@id" => "https://www.bashajobz.co.za/blog_detail.php?id=" . $blog_details['ID']
        ],
        "headline" => $blog_details['Title'],
        "image" => [
            "@type" => "ImageObject",
            "url" => $blog_image_url,
            // "width" => 1200, // Optional: Specify image dimensions if known
            // "height" => 630
        ],
        "datePublished" => date('Y-m-d\TH:i:sP', strtotime($blog_details['Created'])), // ISO 8601 format
        "dateModified" => date('Y-m-d\TH:i:sP', strtotime($blog_details['Created'])), // Assuming no modification date, use creation
        "author" => [
            "@type" => "Person",
            "name" => $blog_details['FirstName'] . ' ' . $blog_details['LastName']
        ],
        "publisher" => [
            "@type" => "Organization",
            "name" => "Bashajobz",
            "logo" => [
                "@type" => "ImageObject",
                "url" => "https://admin.bashajobz.co.za/logo.png", // Your website logo
                "width" => 150,
                "height" => 50
            ]
        ],
        "description" => htmlspecialchars(substr(strip_tags($blog_details['Description']), 0, 250)), // A longer snippet for schema description
        "articleBody" => $blog_details['Description'] // Full HTML content for articleBody
    ], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . '</script>';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($pageKeywords); ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://www.bashajobz.co.za/blog_detail.php?id=<?php echo htmlspecialchars($blog_id); ?>">
    <?php echo $json_ld_schema; // Output schema markup ?>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
          <link rel="icon" href="https://bashajobz.co.za/logo.png" type="image/x-icon">
          <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="apple-touch-icon" sizes="57x57" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://www.bashajobz.co.za/logo.png">
    <style>
        /* General Body and Layout (consistent with other pages) */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #f4f6f9;
            color: #333;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            overflow-x: hidden; /* Prevent horizontal scrolling */
            box-sizing: border-box;
        }

        /* Header/Navbar (Copied for consistency) */
        .main-header {
            background-color: #fff;
            padding: 15px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            width: 100%;
            z-index: 1000;
            box-sizing: border-box;
        }

        .main-header .logo {
            display: flex;
            align-items: center;
        }

        .header-logo {
            height: 50px;
            width: auto;
            max-width: 150px;
            border-radius: 4px;
            object-fit: contain;
            filter: drop-shadow(0 0 2px rgba(0,0,0,0.1));
        }

        .main-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
        }

        .main-nav ul li {
            margin-left: 20px;
        }

        .main-nav ul li a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            padding: 5px 10px;
            transition: color 0.3s ease;
        }

        .main-nav ul li a:hover {
            color: #e67e22; /* Orange hover color */
        }

        .main-nav ul li.signup-btn a {
            background-color: #e67e22; /* Orange button */
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .main-nav ul li.signup-btn a:hover {
            background-color: #d35400; /* Darker orange */
            color: white;
        }
        
        .hamburger-menu {
            display: none;
            font-size: 1.8em;
            cursor: pointer;
            color: #333;
            z-index: 1001;
        }

        .mobile-nav-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background-color: #fff;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            z-index: 998;
            padding: 10px 0;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            overflow-y: auto;
            max-height: calc(100vh - 70px);
            box-sizing: border-box;
            transform: translateY(-10px);
            opacity: 0;
            visibility: hidden;
            transition: transform 0.3s ease-out, opacity 0.3s ease-out, visibility 0.3s ease-out;
        }

        .mobile-nav-dropdown.open {
            display: block;
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }

        .mobile-nav-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center;
            width: 100%;
        }

        .mobile-nav-dropdown ul li {
            margin: 0;
            border-bottom: 1px solid #eee;
        }

        .mobile-nav-dropdown ul li:last-child {
            border-bottom: none;
        }

        .mobile-nav-dropdown ul li a {
            color: #333;
            text-decoration: none;
            font-size: 1.1em;
            padding: 12px 20px;
            display: block;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-weight: 500;
        }

        .mobile-nav-dropdown ul li a:hover {
            background-color: #f0f0f0;
            color: #e67e22; /* Orange hover color */
        }

        .mobile-nav-dropdown ul li.signup-btn a {
            background-color: #e67e22; /* Orange button */
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            margin-top: 10px;
            margin-bottom: 10px;
            width: fit-content;
            margin-left: auto;
            margin-right: auto;
            display: block;
            max-width: 250px;
        }
        .mobile-nav-dropdown ul li.signup-btn a:hover {
            background-color: #d35400; /* Darker orange */
        }

        body.no-scroll {
            overflow: hidden;
        }

        /* --- Blog Detail Page Specific Styles --- */
        .blog-detail-container {
            max-width: 900px;
            margin: 40px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            box-sizing: border-box;
        }

        .blog-header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #e67e22; /* Orange underline */
            padding-bottom: 20px;
        }

        .blog-header h1 {
            font-size: 2.5em;
            color: #2c3e50;
            margin-bottom: 10px;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .blog-header .author-info {
            font-size: 1.1em;
            color: #555;
            margin-bottom: 10px;
        }
        .blog-header .author-info i {
            margin-right: 8px;
            color: #e67e22; /* Orange icon */
        }

        .blog-meta-info {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 15px;
            font-size: 0.95em;
            color: #777;
        }
        .blog-meta-info span {
            display: flex;
            align-items: center;
        }
        .blog-meta-info span i {
            margin-right: 5px;
            color: #e67e22; /* Orange icon */
        }

        .blog-picture {
            width: 100%;
            max-height: 400px; /* Limit max height */
            object-fit: cover;
            border-radius: 8px;
            margin-top: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .blog-content-area {
            margin-top: 30px;
            line-height: 1.8;
            font-size: 1.05em;
            color: #444;
        }
        /* Styles for rich text content outputted by CKEditor */
        .blog-full-description p,
        .blog-full-description ul,
        .blog-full-description ol,
        .blog-full-description h1, /* Ensure h1-h6 inside content are styled */
        .blog-full-description h2,
        .blog-full-description h3,
        .blog-full-description h4,
        .blog-full-description h5,
        .blog-full-description h6 {
            margin-bottom: 1em; /* Ensures spacing between elements */
        }
        .blog-full-description ul,
        .blog-full-description ol {
            padding-left: 25px; /* Indent lists */
        }
        .blog-full-description li {
            margin-bottom: 0.5em; /* Spacing between list items */
        }
        .blog-full-description strong {
            color: #2c3e50; /* Darker color for strong text */
        }
        .blog-full-description a {
            color: #e67e22; /* Orange for links within content */
            text-decoration: underline;
        }
        .blog-full-description a:hover {
            color: #d35400;
        }


        .action-buttons {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        .action-buttons .btn-secondary {
            background-color: #e67e22; /* Orange for Back to Blog */
            color: white;
            display: inline-block;
            padding: 15px 30px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 1.1em;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .action-buttons .btn-secondary:hover {
            background-color: #d35400; /* Darker orange */
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }

        /* Error/Not Found Message */
        .error-message {
            text-align: center;
            padding: 50px;
            font-size: 1.2em;
            color: #c0392b; /* Reddish color for errors */
            background-color: #ffebee; /* Light red background */
            border: 1px solid #e74c3c;
            border-radius: 8px;
            margin: 50px auto;
            max-width: 600px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        .error-message i {
            margin-right: 10px;
            color: #e74c3c;
        }


        /* Responsive adjustments */
        @media (max-width: 768px) {
            .main-header {
                padding: 15px;
                position: relative;
            }
            .hamburger-menu {
                display: block;
            }
            .main-nav {
                display: none;
            }

            .blog-detail-container {
                margin: 20px auto;
                padding: 20px;
                border-radius: 8px;
            }

            .blog-header h1 {
                font-size: 1.8em;
            }

            .blog-header .author-info {
                font-size: 1em;
            }

            .blog-meta-info {
                flex-direction: column;
                align-items: center;
                gap: 10px;
                font-size: 0.9em;
            }

            .blog-picture {
                max-height: 250px; /* Smaller image on mobile */
            }

            .blog-content-area {
                font-size: 1em;
            }

            .action-buttons {
                flex-direction: column;
                gap: 15px;
            }

            .action-buttons .btn-secondary {
                width: calc(100% - 20px);
                max-width: 300px;
                padding: 12px 20px;
                font-size: 1em;
                margin-left: auto;
                margin-right: auto;
            }
            
            .error-message {
                padding: 30px 20px;
                font-size: 1em;
                margin: 30px auto;
            }
        }

        /* Further minor adjustments for very small screens (e.g., less than 400px) */
        @media (max-width: 400px) {
            .blog-detail-container {
                padding: 15px;
            }
            .blog-header h1 {
                font-size: 1.5em;
            }
            .blog-content-area {
                font-size: 0.95em;
            }
            .action-buttons .btn-secondary {
                padding: 10px 15px;
                font-size: 0.9em;
            }
        }
    </style>
</head>
<body>
    <header class="main-header">
        <a href="index.php" class="logo">
            <img src="logo.png" alt="Bashjobz Logo" class="header-logo" onerror="this.onerror=null;this.src='https://placehold.co/150x50/cccccc/333333?text=Bashjobz';">
        </a>
        <nav class="main-nav">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="jobs.php">Jobs</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="news.php">News</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="cv_services.php">CV Revamp Services</a></li>
                <li><a href="login.php">Login</a></li>
                <li class="signup-btn"><a href="signup.php">Sign Up</a></li>
            </ul>
        </nav>
        <div class="hamburger-menu" onclick="toggleMobileMenu()">
            <i class="fas fa-bars" id="hamburgerIcon"></i>
        </div>

        <!-- Mobile Navigation Dropdown -->
        <nav class="mobile-nav-dropdown" id="mobileNavDropdown">
            <ul>
                <li><a href="index.php" onclick="toggleMobileMenu()">Home</a></li>
                <li><a href="jobs.php" onclick="toggleMobileMenu()">Jobs</a></li>
                <li><a href="blog.php" onclick="toggleMobileMenu()">Blog</a></li>
                <li><a href="news.php" onclick="toggleMobileMenu()">News</a></li>
                <li><a href="contact.php" onclick="toggleMobileMenu()">Contact</a></li>
                <li><a href="cv_services.php" onclick="toggleMobileMenu()">CV Revamp Services</a></li>
                <li><a href="login.php" onclick="toggleMobileMenu()">Login</a></li>
                <li class="signup-btn"><a href="signup.php" onclick="toggleMobileMenu()">Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <?php if ($db_connection_error): ?>
            <div class="error-message">
                <p><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($db_connection_error); ?></p>
                <a href="blog.php" class="btn btn-secondary" style="margin-top: 20px;">Back to Blog</a>
            </div>
        <?php elseif ($blog_not_found): ?>
            <div class="error-message">
                <p><i class="fas fa-exclamation-circle"></i> Sorry, the blog post you are looking for could not be found or is no longer available.</p>
                <a href="blog.php" class="btn btn-secondary" style="margin-top: 20px;">Back to Blog</a>
            </div>
        <?php else: ?>
            <section class="blog-detail-container">
                <div class="blog-header">
                    <h1><?php echo htmlspecialchars($blog_details['Title']); ?></h1>
                    <p class="author-info">
                        <i class="fas fa-user"></i> Published By Bashajobz Team
                    </p>
                    <div class="blog-meta-info">
                        <span><i class="fas fa-calendar-alt"></i> Published: <?php echo htmlspecialchars(date('M d, Y', strtotime($blog_details['Created']))); ?></span>
                        <!-- Add views count here if you decide to retrieve and display it -->
                        <!-- <span><i class="fas fa-eye"></i> Views: <?php // echo htmlspecialchars($blog_details['Views']); ?></span> -->
                    </div>
                </div>

                <?php 
                    $dynamic_blog_picture_dir = "https://admin.bashajobz.co.za/Dashboards/" . htmlspecialchars($blog_details['Account']) . "/uploads/Blogs/";
                    $blog_image_src = !empty($blog_details['Picture']) ? htmlspecialchars($dynamic_blog_picture_dir . $blog_details['Picture']) : 'https://placehold.co/900x400?text=Blog+Image';
                ?>
                <img src="<?php echo $blog_image_src; ?>" alt="<?php echo htmlspecialchars($blog_details['Title']); ?>" class="blog-picture" onerror="this.onerror=null;this.src='https://placehold.co/900x400?text=No+Image';">


                <div class="blog-content-area">
                    <div class="blog-full-description">
                        <?php echo $blog_details['Description']; // Render HTML directly ?>
                    </div>
                </div>

                <!-- Action button: Back to Blog -->
                <div class="action-buttons">
                    <a href="blog.php" class="btn-secondary">Back to All Blog Posts</a>
                </div>
            </section>
        <?php endif; ?>
    </main>

    <?php
    // Include the reusable footer component
    include 'footer.php';
    ?>

    <script>
        function toggleMobileMenu() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerIcon = document.getElementById('hamburgerIcon');

            mobileNavDropdown.classList.toggle('open');
            if (mobileNavDropdown.classList.contains('open')) {
                hamburgerIcon.classList.remove('fa-bars');
                hamburgerIcon.classList.add('fa-times');
            } else {
                hamburgerIcon.classList.remove('fa-times');
                hamburgerIcon.classList.add('fa-bars');
            }
        }

        document.addEventListener('click', function(event) {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerMenu = document.querySelector('.hamburger-menu');

            if (mobileNavDropdown.classList.contains('open') && 
                !mobileNavDropdown.contains(event.target) && 
                !hamburgerMenu.contains(event.target)) {
                toggleMobileMenu();
            }
        });

        window.addEventListener('resize', function() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            if (window.innerWidth > 768 && mobileNavDropdown.classList.contains('open')) {
                toggleMobileMenu();
            }
        });
    </script>

</body>
</html>
