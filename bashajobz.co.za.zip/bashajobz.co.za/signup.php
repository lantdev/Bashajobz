<?php include('server.php'); // This must be at the very top of your file ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-8ETDR3EKS7"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-8ETDR3EKS7');
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://bashajobz.co.za/logo.png" type="image/x-icon">
    <meta name="description" content="Sign up for Bashjobz to find thousands of job opportunities across South Africa. Create your free account today and kickstart your career!">
    <meta name="keywords" content="sign up, register, job search, South Africa jobs, career, employment, Bashjobz">
    <meta name="author" content="Bashjobz Team">
    <meta name="robots" content="index, follow">
    <meta name="language" content="English">
    <meta name="geo.region" content="ZA">
    <meta name="geo.placename" content="South Africa">
    <title>Sign Up - Bashjobz | Your Gateway to Career Opportunities in South Africa</title>

    <meta property="og:title" content="Sign Up - Bashjobz | Your Gateway to Career Opportunities in South Africa">
    <meta property="og:description" content="Create your Bashjobz account today and gain access to a variety of job opportunities in South Africa. Start your journey to find the perfect job!">
    <meta property="og:image" content="https://bashajobz.co.za/logo.png">
    <meta property="og:url" content="https://bashajobz.co.za/signup.php">
    <meta property="og:type" content="website">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Sign Up - Bashjobz | Your Gateway to Career Opportunities in South Africa">
    <meta name="twitter:description" content="Join Bashjobz and simplify your job search in South Africa. Sign up now to start finding your ideal career!">
    <meta name="twitter:image" content="https://bashajobz.co.za/logo.png">
    <meta name="twitter:url" content="https://bashajobz.co.za/signup.php">

    <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="apple-touch-icon" sizes="57x57" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://www.bashajobz.co.za/logo.png">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        /* General Body and Layout */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #f4f6f9; /* Lighter background for consistency */
            color: #333;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            overflow-x: hidden;
            /* Applying the image background from signup original, but now for consistency */
            background-image: url('bigstock-sandton-skyline-87187883.jpg');
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        /* Header/Navbar (matching index.php) */
        .main-header {
            background-color: #fff;
            padding: 15px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            width: 100%;
            z-index: 1000;
            box-sizing: border-box;
        }

        .main-header .logo {
            display: flex;
            align-items: center;
        }

        .header-logo {
            height: 50px;
            width: auto;
            max-width: 150px;
            border-radius: 4px;
            object-fit: contain;
            filter: drop-shadow(0 0 2px rgba(0,0,0,0.1));
        }

        .main-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
        }

        .main-nav ul li {
            margin-left: 20px;
        }

        .main-nav ul li a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            padding: 5px 10px;
            transition: color 0.3s ease;
        }

        .main-nav ul li a:hover {
            color: #e67e22;
        }

        .main-nav ul li.signup-btn a {
            background-color: #e67e22;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .main-nav ul li.signup-btn a:hover {
            background-color: #d35400;
            color: white;
        }

        /* Hamburger Menu for Mobile (matching index.php) */
        .hamburger-menu {
            display: none; /* Hidden by default on desktop */
            font-size: 1.8em;
            cursor: pointer;
            color: #333;
            z-index: 1001;
        }

        /* Mobile Navigation Dropdown (matching index.php) */
        .mobile-nav-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background-color: #fff;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            z-index: 998;
            padding: 10px 0;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            overflow-y: auto;
            max-height: calc(100vh - 70px);
            box-sizing: border-box;
            transform: translateY(-10px);
            opacity: 0;
            visibility: hidden;
            transition: transform 0.3s ease-out, opacity 0.3s ease-out, visibility 0.3s ease-out;
        }

        .mobile-nav-dropdown.open {
            display: block;
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }

        .mobile-nav-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center;
            width: 100%;
        }

        .mobile-nav-dropdown ul li {
            margin: 0;
            border-bottom: 1px solid #eee;
        }

        .mobile-nav-dropdown ul li:last-child {
            border-bottom: none;
        }

        .mobile-nav-dropdown ul li a {
            color: #333;
            text-decoration: none;
            font-size: 1.1em;
            padding: 12px 20px;
            display: block;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-weight: 500;
        }

        .mobile-nav-dropdown ul li a:hover {
            background-color: #f0f0f0;
            color: #e67e22;
        }

        .mobile-nav-dropdown ul li.signup-btn a {
            background-color: #e67e22;
            color: white;
            padding: 12px 20px;
            border-radius: 5px; /* Changed from 0 to 5px for consistency with desktop button */
            margin-top: 10px;
            width: calc(100% - 40px);
            margin-left: auto;
            margin-right: auto;
            display: block;
            max-width: 250px;
        }
        .mobile-nav-dropdown ul li.signup-btn a:hover {
            background-color: #d35400;
        }

        body.no-scroll {
            overflow: hidden;
        }

        /* Main content styling (for the form) */
        main {
            flex-grow: 1; /* Allows main content to take available space */
            display: flex;
            justify-content: center;
            align-items: center; /* Center vertically in the remaining space */
            padding: 20px; /* Add some padding around the container */
            box-sizing: border-box;
        }

        .form-container { /* Renamed from .container to avoid conflict and be more specific */
            max-width: 500px;
            width: 100%; /* Ensures it scales down */
            background-color: rgba(255, 255, 255, 0.95); /* Slightly transparent white */
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1); /* Slightly stronger shadow for depth */
            padding: 30px; /* Increased padding */
            box-sizing: border-box;
        }

        .form-container h1 {
            text-align: center;
            color: #2c3e50; /* Darker heading for form, similar to index section titles */
            font-size: 2.2em;
            margin-bottom: 30px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 600; /* Slightly bolder labels */
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        select {
            width: 100%; /* Take full width of parent */
            padding: 12px 15px; /* More balanced padding */
            margin-bottom: 20px;
            border: 1px solid #ccc; /* Softer border */
            border-radius: 5px;
            font-size: 1em;
            box-sizing: border-box;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus,
        select:focus {
            border-color: #e67e22; /* Bashjobz orange on focus */
            outline: none;
            box-shadow: 0 0 8px rgba(230, 126, 34, 0.2); /* Subtle glow on focus */
        }

        .button {
            display: block;
            width: 100%;
            padding: 15px;
            background-color: #e67e22; /* Bashjobz orange */
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.1em;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .button:hover {
            background-color: #d35400; /* Darker orange on hover */
            transform: translateY(-2px); /* Slight lift effect */
        }

        .links, .terms {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9em;
            color: #666;
        }

        .links a, .terms a {
            color: #e67e22;
            text-decoration: none;
            font-weight: 500;
        }

        .links a:hover, .terms a:hover {
            text-decoration: underline;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
            padding: 12px;
            border: 1px solid #f5c6cb;
            border-radius: 5px;
            margin-bottom: 20px; /* More space below errors */
            font-size: 0.9em;
            box-sizing: border-box;
        }

        .error p {
            margin: 0; /* Remove default paragraph margins */
            font-weight: bold;
        }

        /* Responsive adjustments (matching index.php for header/footer breakpoints) */
        @media (max-width: 768px) {
            .main-header {
                justify-content: space-between;
                padding: 15px;
                position: relative;
            }
            .main-nav {
                display: none; /* Hide desktop nav */
            }
            .hamburger-menu {
                display: block; /* Show hamburger */
            }
            .header-logo {
                height: 40px; /* Smaller logo on mobile */
            }
            
            /* Form container adjustments for mobile */
            .form-container {
                padding: 20px;
                margin: 20px 15px; /* Add horizontal margin */
                width: auto; /* Allow content to dictate width */
            }
            input[type="text"],
            input[type="email"],
            input[type="password"],
            select {
                padding: 10px 12px;
                font-size: 0.9em;
            }
            .button {
                padding: 12px;
                font-size: 1em;
            }
            .links, .terms {
                font-size: 0.8em;
            }

            /* Footer responsiveness - inherited from index.php reference */
            .footer-container {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }
            .footer-about, .footer-links, .footer-legal, .footer-contact {
                margin-bottom: 30px;
                width: 100%;
            }
            .footer-about h3::after,
            .footer-links h3::after,
            .footer-legal h3::after,
            .footer-contact h3::after {
                left: 50%;
                transform: translateX(-50%);
            }
            .footer-contact p {
                justify-content: center;
            }
        }

        @media (max-width: 480px) {
            .main-header {
                padding: 10px;
            }
            .header-logo {
                height: 35px;
            }
            .form-container h1 {
                font-size: 1.8em;
                margin-bottom: 20px;
            }
            .button {
                font-size: 0.95em;
            }
            .social-icons a {
                font-size: 1.3em;
                margin-right: 10px;
            }
            .footer-links a {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

    <header class="main-header">
        <a href="index.php" class="logo">
            <img src="logo.png" alt="Bashjobz Logo" class="header-logo" onerror="this.onerror=null;this.src='https://placehold.co/150x50/cccccc/333333?text=Bashjobz';">
        </a>
        <nav class="main-nav">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="jobs.php">Jobs</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="news.php">News</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="cv_services.php">CV Revamp Services</a></li>
                <li><a href="login.php">Login</a></li>
                <li class="signup-btn"><a href="signup.php">Sign Up</a></li>
            </ul>
        </nav>
        <div class="hamburger-menu" onclick="toggleMobileMenu()">
            <i class="fas fa-bars" id="hamburgerIcon"></i>
        </div>

        <nav class="mobile-nav-dropdown" id="mobileNavDropdown">
            <ul>
                <li><a href="index.php" onclick="toggleMobileMenu()">Home</a></li>
                <li><a href="jobs.php" onclick="toggleMobileMenu()">Jobs</a></li>
                <li><a href="blog.php" onclick="toggleMobileMenu()">Blog</a></li>
                <li><a href="news.php" onclick="toggleMobileMenu()">News</a></li>
                <li><a href="contact.php" onclick="toggleMobileMenu()">Contact</a></li>
                <li><a href="cv_services.php" onclick="toggleMobileMenu()">CV Revamp Services</a></li>
                <li><a href="login.php" onclick="toggleMobileMenu()">Login</a></li>
                <li class="signup-btn"><a href="signup.php" onclick="toggleMobileMenu()">Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <div class="form-container">
            <?php if (count($errors) > 0): ?>
                <div class="error">
                    <?php foreach ($errors as $error): ?>
                        <p><?= htmlspecialchars($error) ?></p>
                    <?php endforeach ?>
                </div>
            <?php endif ?>

            <h1>Create Your Bashjobz Account</h1>
            <form action="signup.php" method="POST">
                <label for="firstname">First Name:</label>
                <input type="text" placeholder="Your First Name" id="firstname" name="FirstName" value="<?= htmlspecialchars($FirstName) ?>" required>

                <label for="lastname">Last Name:</label>
                <input type="text" id="lastname" placeholder="Your Last Name" name="LastName" value="<?= htmlspecialchars($LastName) ?>" required>

                <label for="email">Email:</label>
                <input type="email" placeholder="Your Email Address" id="email" name="Email" value="<?= htmlspecialchars($Email) ?>" required>

                <label for="countrycode">Country Code:</label>
                <input type="text" id="countrycode" name="CountryCode" value="+27" readonly>

                <label for="phone">Phone Number (10 digits):</label>
                <input type="text" id="phone" placeholder="e.g., 0712345678" name="Phone" pattern="\d{10}" title="Phone number must be 10 digits (e.g., 0712345678)" value="<?= htmlspecialchars($PhoneNumber) ?>" required>

                <label for="password_1">Password:</label>
                <input type="password" placeholder="Create a Password (min 6 characters)" name="Password_1" id="password_1" required>

                <label for="password_2">Confirm Password:</label>
                <input type="password" placeholder="Confirm Your Password" name="Password_2" id="password_2" required>

                <center>
                    <div class="g-recaptcha" data-sitekey="6LchJW4rAAAAACoTTARqqmJ-Uvzv30kXNxBcSUzI"></div><br>
                </center>

                <button type="submit" class="button" name="register">Register Account</button>
            </form>

            <script src="https://www.google.com/recaptcha/api.js" async defer></script>

            <div class="terms">
                <p>By signing up, you agree to our <a href="terms_conditions.php">Terms and Conditions</a> and <a href="privacy_policy.php">Privacy Policy</a>.</p>
            </div>

            <div class="links">
                <p>Already have an account? <a href="login.php">Login here</a></p>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        function toggleMobileMenu() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerIcon = document.getElementById('hamburgerIcon');

            mobileNavDropdown.classList.toggle('open');
            document.body.classList.toggle('no-scroll');

            if (mobileNavDropdown.classList.contains('open')) {
                hamburgerIcon.classList.remove('fa-bars');
                hamburgerIcon.classList.add('fa-times');
            } else {
                hamburgerIcon.classList.remove('fa-times');
                hamburgerIcon.classList.add('fa-bars');
            }
        }
    </script>
</body>
</html>