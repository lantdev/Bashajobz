<?php
// news_detail.php - Single News Article Page for www.bashajobz.co.za

// Database connection details
$db = mysqli_connect('localhost', 'prolance_prolance', '@Airbus360', 'prolance_bashajobz');

// Initialize variables for news data and error
$news_details = null;
$db_connection_error = null;
$news_not_found = false;

if (!$db) {
    error_log("Website DB Connection Failed: " . mysqli_connect_error());
    $db_connection_error = "We are currently experiencing technical difficulties. Please try again later.";
} else {
    // Get news ID from URL
    $news_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

    // Validate news ID
    if ($news_id > 0) {
        // Fetch specific news details, including Original_URL
        $query_news_detail = "SELECT n.ID, n.Title, n.Slug, n.Picture, n.Description, n.Created, n.Username, n.FirstName, n.LastName, a.Account, n.Original_URL 
                              FROM news n 
                              JOIN admin a ON n.UserID = a.ID 
                              WHERE n.ID = ? AND n.Status = 'Published' LIMIT 1";
        
        $stmt = mysqli_prepare($db, $query_news_detail);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "i", $news_id); // 'i' for integer
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if ($result && mysqli_num_rows($result) > 0) {
                $news_details = mysqli_fetch_assoc($result);

                // Optional: Increment view count for news articles
                $update_views_query = "UPDATE news SET Views = Views + 1 WHERE ID = ?";
                $stmt_views = mysqli_prepare($db, $update_views_query);
                if ($stmt_views) {
                    mysqli_stmt_bind_param($stmt_views, "i", $news_id);
                    mysqli_stmt_execute($stmt_views);
                    mysqli_stmt_close($stmt_views);
                } else {
                    error_log("Error updating news views: " . mysqli_error($db));
                }

            } else {
                $news_not_found = true; // News article not found or not published
            }
            mysqli_stmt_close($stmt);
        } else {
            error_log("Error preparing news detail query: " . mysqli_error($db));
            $db_connection_error = "Failed to retrieve news details. Please try again.";
        }
    } else {
        $news_not_found = true; // Invalid news ID
    }

    mysqli_close($db); // Close database connection
}

// SEO Meta Tags (Dynamic based on news details)
$pageTitle = "News Article Not Found | Bashajobz News";
$pageDescription = "The news article you are looking for could not be found or has been removed.";
$pageKeywords = "news not found, Bashajobz news";

// Schema.org NewsArticle structured data (Dynamic)
$json_ld_schema = '';

if ($news_details) {
    $pageTitle = htmlspecialchars($news_details['Title']) . " | Bashajobz News";
    $pageDescription = htmlspecialchars(substr(strip_tags($news_details['Description']), 0, 160)) . '...';
    $pageKeywords = htmlspecialchars($news_details['Title']) . ", " . htmlspecialchars($news_details['FirstName'] . ' ' . $news_details['LastName']) . ", " . htmlspecialchars($news_details['Slug']) . ", Bashajobz news, job market trends";

    // Determine news image URL for Schema.org
    $news_image_url = '';
    if (!empty($news_details['Picture'])) {
        $dynamic_news_picture_dir = "https://admin.bashajobz.co.za/Dashboards/" . htmlspecialchars($news_details['Account']) . "/uploads/News/";
        $news_image_url = $dynamic_news_picture_dir . htmlspecialchars($news_details['Picture']);
    } else {
        $news_image_url = 'https://placehold.co/800x400?text=News+Image'; // Fallback
    }

    // Prepare NewsArticle Schema.org JSON-LD
    $json_ld_schema = '<script type="application/ld+json">' . json_encode([
        "@context" => "https://schema.org",
        "@type" => "NewsArticle",
        "mainEntityOfPage" => [
            "@type" => "WebPage",
            "@id" => "https://www.bashajobz.co.za/news_detail.php?id=" . $news_details['ID']
        ],
        "headline" => $news_details['Title'],
        "image" => [
            "@type" => "ImageObject",
            "url" => $news_image_url,
            // "width" => 1200, // Optional: Specify image dimensions if known
            // "height" => 630
        ],
        "datePublished" => date('Y-m-d\TH:i:sP', strtotime($news_details['Created'])), // ISO 8601 format
        "dateModified" => date('Y-m-d\TH:i:sP', strtotime($news_details['Created'])), // Assuming no modification date, use creation
        "author" => [
            "@type" => "Person",
            "name" => $news_details['FirstName'] . ' ' . $news_details['LastName']
        ],
        "publisher" => [
            "@type" => "Organization",
            "name" => "Bashajobz",
            "logo" => [
                "@type" => "ImageObject",
                "url" => "https://admin.bashajobz.co.za/logo.png", // Your website logo
                "width" => 150,
                "height" => 50
            ]
        ],
        "description" => htmlspecialchars(substr(strip_tags($news_details['Description']), 0, 250)), // A longer snippet for schema description
        "articleBody" => $news_details['Description'] // Full HTML content for articleBody
    ], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . '</script>';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($pageKeywords); ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://www.bashajobz.co.za/news_detail.php?id=<?php echo htmlspecialchars($news_id); ?>">
    <?php echo $json_ld_schema; // Output schema markup ?>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
          <link rel="icon" href="https://bashajobz.co.za/logo.png" type="image/x-icon">
          <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="apple-touch-icon" sizes="57x57" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://www.bashajobz.co.za/logo.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://www.bashajobz.co.za/logo.png">
    <style>
        /* General Body and Layout (consistent with other pages) */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #f4f6f9;
            color: #333;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            overflow-x: hidden; /* Prevent horizontal scrolling */
            box-sizing: border-box;
        }

        /* Header/Navbar (Copied for consistency) */
        .main-header {
            background-color: #fff;
            padding: 15px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            width: 100%;
            z-index: 1000;
            box-sizing: border-box;
        }

        .main-header .logo {
            display: flex;
            align-items: center;
        }

        .header-logo {
            height: 50px;
            width: auto;
            max-width: 150px;
            border-radius: 4px;
            object-fit: contain;
            filter: drop-shadow(0 0 2px rgba(0,0,0,0.1));
        }

        .main-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
        }

        .main-nav ul li {
            margin-left: 20px;
        }

        .main-nav ul li a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            padding: 5px 10px;
            transition: color 0.3s ease;
        }

        .main-nav ul li a:hover {
            color: #e67e22; /* Orange hover color */
        }

        .main-nav ul li.signup-btn a {
            background-color: #e67e22; /* Orange button */
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .main-nav ul li.signup-btn a:hover {
            background-color: #d35400; /* Darker orange */
            color: white;
        }
        
        .hamburger-menu {
            display: none;
            font-size: 1.8em;
            cursor: pointer;
            color: #333;
            z-index: 1001;
        }

        .mobile-nav-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background-color: #fff;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            z-index: 998;
            padding: 10px 0;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            overflow-y: auto;
            max-height: calc(100vh - 70px);
            box-sizing: border-box;
            transform: translateY(-10px);
            opacity: 0;
            visibility: hidden;
            transition: transform 0.3s ease-out, opacity 0.3s ease-out, visibility 0.3s ease-out;
        }

        .mobile-nav-dropdown.open {
            display: block;
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }

        .mobile-nav-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center;
            width: 100%;
        }

        .mobile-nav-dropdown ul li {
            margin: 0;
            border-bottom: 1px solid #eee;
        }

        .mobile-nav-dropdown ul li:last-child {
            border-bottom: none;
        }

        .mobile-nav-dropdown ul li a {
            color: #333;
            text-decoration: none;
            font-size: 1.1em;
            padding: 12px 20px;
            display: block;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-weight: 500;
        }

        .mobile-nav-dropdown ul li a:hover {
            background-color: #f0f0f0;
            color: #e67e22; /* Orange hover color */
        }

        .mobile-nav-dropdown ul li.signup-btn a {
            background-color: #e67e22; /* Orange button */
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            margin-top: 10px;
            margin-bottom: 10px;
            width: fit-content;
            margin-left: auto;
            margin-right: auto;
            display: block;
            max-width: 250px;
        }
        .mobile-nav-dropdown ul li.signup-btn a:hover {
            background-color: #d35400; /* Darker orange */
        }

        body.no-scroll {
            overflow: hidden;
        }

        /* --- News Detail Page Specific Styles --- */
        .news-detail-container {
            max-width: 900px;
            margin: 40px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            box-sizing: border-box;
        }

        .news-header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #e67e22; /* Orange underline */
            padding-bottom: 20px;
        }

        .news-header h1 {
            font-size: 2.5em;
            color: #2c3e50;
            margin-bottom: 10px;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .news-header .author-info {
            font-size: 1.1em;
            color: #555;
            margin-bottom: 10px;
        }
        .news-header .author-info i {
            margin-right: 8px;
            color: #e67e22; /* Orange icon */
        }

        .news-meta-info {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 15px;
            font-size: 0.95em;
            color: #777;
        }
        .news-meta-info span {
            display: flex;
            align-items: center;
        }
        .news-meta-info span i {
            margin-right: 5px;
            color: #e67e22; /* Orange icon */
        }

        .news-picture {
            width: 100%;
            max-height: 400px; /* Limit max height */
            object-fit: cover;
            border-radius: 8px;
            margin-top: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .news-content-area {
            margin-top: 30px;
            line-height: 1.8;
            font-size: 1.05em;
            color: #444;
        }
        /* Styles for rich text content outputted by CKEditor */
        .news-full-description p,
        .news-full-description ul,
        .news-full-description ol,
        .news-full-description h1, /* Ensure h1-h6 inside content are styled */
        .news-full-description h2,
        .news-full-description h3,
        .news-full-description h4,
        .news-full-description h5,
        .news-full-description h6 {
            margin-bottom: 1em; /* Ensures spacing between elements */
        }
        .news-full-description ul,
        .news-full-description ol {
            padding-left: 25px; /* Indent lists */
        }
        .news-full-description li {
            margin-bottom: 0.5em; /* Spacing between list items */
        }
        .news-full-description strong {
            color: #2c3e50; /* Darker color for strong text */
        }
        .news-full-description a {
            color: #e67e22; /* Orange for links within content */
            text-decoration: underline;
        }
        .news-full-description a:hover {
            color: #d35400;
        }


        .action-buttons {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        .action-buttons .btn {
            display: inline-block;
            padding: 15px 30px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 1.1em;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .action-buttons .btn-primary-news { /* New style for the original source button */
            background-color: #e67e22; /* Orange */
            color: white;
        }
        .action-buttons .btn-primary-news:hover {
            background-color: #d35400; /* Darker orange */
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }

        .action-buttons .btn-secondary {
            background-color: #2c3e50; /* Dark blue/grey for Back to News */
            color: white;
        }
        .action-buttons .btn-secondary:hover {
            background-color: #34495e; /* Darker blue/grey */
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }

        /* Error/Not Found Message */
        .error-message {
            text-align: center;
            padding: 50px;
            font-size: 1.2em;
            color: #c0392b; /* Reddish color for errors */
            background-color: #ffebee; /* Light red background */
            border: 1px solid #e74c3c;
            border-radius: 8px;
            margin: 50px auto;
            max-width: 600px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        .error-message i {
            margin-right: 10px;
            color: #e74c3c;
        }


        /* Responsive adjustments */
        @media (max-width: 768px) {
            .main-header {
                padding: 15px;
                position: relative;
            }
            .hamburger-menu {
                display: block;
            }
            .main-nav {
                display: none;
            }

            .news-detail-container {
                margin: 20px auto;
                padding: 20px;
                border-radius: 8px;
            }

            .news-header h1 {
                font-size: 1.8em;
            }

            .news-header .author-info {
                font-size: 1em;
            }

            .news-meta-info {
                flex-direction: column;
                align-items: center;
                gap: 10px;
                font-size: 0.9em;
            }

            .news-picture {
                max-height: 250px; /* Smaller image on mobile */
            }

            .news-content-area {
                font-size: 1em;
            }

            .action-buttons {
                flex-direction: column;
                gap: 15px;
            }

            .action-buttons .btn { /* Apply to all buttons within action-buttons */
                width: calc(100% - 20px);
                max-width: 300px;
                padding: 12px 20px;
                font-size: 1em;
                margin-left: auto;
                margin-right: auto;
            }
            
            .error-message {
                padding: 30px 20px;
                font-size: 1em;
                margin: 30px auto;
            }
        }

        /* Further minor adjustments for very small screens (e.g., less than 400px) */
        @media (max-width: 400px) {
            .news-detail-container {
                padding: 15px;
            }
            .news-header h1 {
                font-size: 1.5em;
            }
            .news-content-area {
                font-size: 0.95em;
            }
            .action-buttons .btn {
                padding: 10px 15px;
                font-size: 0.9em;
            }
        }
    </style>
</head>
<body>
    <header class="main-header">
        <a href="index.php" class="logo">
            <img src="logo.png" alt="Bashjobz Logo" class="header-logo" onerror="this.onerror=null;this.src='https://placehold.co/150x50/cccccc/333333?text=Bashajobz';">
        </a>
        <nav class="main-nav">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="jobs.php">Jobs</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="news.php">News</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="cv_services.php">CV Revamp Services</a></li>
                <li><a href="login.php">Login</a></li>
                <li class="signup-btn"><a href="signup.php">Sign Up</a></li>
            </ul>
        </nav>
        <div class="hamburger-menu" onclick="toggleMobileMenu()">
            <i class="fas fa-bars" id="hamburgerIcon"></i>
        </div>

        <!-- Mobile Navigation Dropdown -->
        <nav class="mobile-nav-dropdown" id="mobileNavDropdown">
            <ul>
                <li><a href="index.php" onclick="toggleMobileMenu()">Home</a></li>
                <li><a href="jobs.php" onclick="toggleMobileMenu()">Jobs</a></li>
                <li><a href="blog.php" onclick="toggleMobileMenu()">Blog</a></li>
                <li><a href="news.php" onclick="toggleMobileMenu()">News</a></li>
                <li><a href="contact.php" onclick="toggleMobileMenu()">Contact</a></li>
                <li><a href="cv_services.php" onclick="toggleMobileMenu()">CV Revamp Services</a></li>
                <li><a href="login.php" onclick="toggleMobileMenu()">Login</a></li>
                <li class="signup-btn"><a href="signup.php" onclick="toggleMobileMenu()">Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <?php if ($db_connection_error): ?>
            <div class="error-message">
                <p><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($db_connection_error); ?></p>
                <a href="news.php" class="btn btn-secondary" style="margin-top: 20px;">Back to News</a>
            </div>
        <?php elseif ($news_not_found): ?>
            <div class="error-message">
                <p><i class="fas fa-exclamation-circle"></i> Sorry, the news article you are looking for could not be found or is no longer available.</p>
                <a href="news.php" class="btn btn-secondary" style="margin-top: 20px;">Back to News</a>
            </div>
        <?php else: ?>
            <section class="news-detail-container">
                <div class="news-header">
                    <h1><?php echo htmlspecialchars($news_details['Title']); ?></h1>
                    <p class="author-info">
                        <i class="fas fa-user"></i> Published By <?php echo htmlspecialchars($news_details['FirstName'] . ' ' . $news_details['LastName']); ?> 
                    </p>
                    <div class="news-meta-info">
                        <span><i class="fas fa-calendar-alt"></i> Published: <?php echo htmlspecialchars(date('M d, Y', strtotime($news_details['Created']))); ?></span>
                        <!-- Add views count here if you decide to retrieve and display it -->
                        <!-- <span><i class="fas fa-eye"></i> Views: <?php // echo htmlspecialchars($news_details['Views']); ?></span> -->
                    </div>
                </div>

                <?php 
                    $dynamic_news_picture_dir = "https://admin.bashajobz.co.za/Dashboards/" . htmlspecialchars($news_details['Account']) . "/uploads/News/";
                    $news_image_src = !empty($news_details['Picture']) ? htmlspecialchars($dynamic_news_picture_dir . $news_details['Picture']) : 'https://placehold.co/900x400?text=News+Image';
                ?>
                <img src="<?php echo $news_image_src; ?>" alt="<?php echo htmlspecialchars($news_details['Title']); ?>" class="news-picture" onerror="this.onerror=null;this.src='https://placehold.co/900x400?text=No+Image';">


                <div class="news-content-area">
                    <div class="news-full-description">
                        <?php echo $news_details['Description']; // Render HTML directly ?>
                    </div>
                </div>

                <!-- Action buttons: View Original Source and Back to News -->
                <div class="action-buttons">
                    <?php if (!empty($news_details['Original_URL'])): ?>
                        <a href="<?php echo htmlspecialchars($news_details['Original_URL']); ?>" class="btn btn-primary-news" target="_blank" rel="noopener noreferrer">View Original Source <i class="fas fa-external-link-alt"></i></a>
                    <?php endif; ?>
                    <a href="news.php" class="btn btn-secondary">Back to All News Articles</a>
                </div>
            </section>
        <?php endif; ?>
    </main>

    <?php
    // Include the reusable footer component
    include 'footer.php';
    ?>

    <script>
        function toggleMobileMenu() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerIcon = document.getElementById('hamburgerIcon');

            mobileNavDropdown.classList.toggle('open');
            if (mobileNavDropdown.classList.contains('open')) {
                hamburgerIcon.classList.remove('fa-bars');
                hamburgerIcon.classList.add('fa-times');
            } else {
                hamburgerIcon.classList.remove('fa-times');
                hamburgerIcon.classList.add('fa-bars');
            }
        }

        document.addEventListener('click', function(event) {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            const hamburgerMenu = document.querySelector('.hamburger-menu');

            if (mobileNavDropdown.classList.contains('open') && 
                !mobileNavDropdown.contains(event.target) && 
                !hamburgerMenu.contains(event.target)) {
                toggleMobileMenu();
            }
        });

        window.addEventListener('resize', function() {
            const mobileNavDropdown = document.getElementById('mobileNavDropdown');
            if (window.innerWidth > 768 && mobileNavDropdown.classList.contains('open')) {
                toggleMobileMenu();
            }
        });
    </script>

</body>
</html>
