<?php
session_start();

$errors = array();

// Database connection details
// It's highly recommended to move these credentials to a separate, secure config file
// e.g., require_once 'path/to/your/config.php';
$db_host = 'localhost';
$db_user = 'prolance_prolance';
$db_pass = '@Airbus360';
$db_name = 'prolance_bashajobz'; // Corrected to Bashjobz database

$db = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check database connection
if ($db->connect_error) {
    error_log("Bashjobz Login DB Connection Failed: " . $db->connect_error);
    array_push($errors, "Database connection failed. Please try again later.");
}

// Your reCAPTCHA secret key (Ensure this is the CORRECT secret key for the site key '6LchJW4rAAAAACoTTARqqmJ-Uvzv30kXNxBcSUzI')
$recaptcha_secret = '6LchJW4rAAAAALUIAev685QrrU4UbMzFy4OyvUjY'; // <-- IMPORTANT: Replace with your actual secret key!

// Check if the form is submitted
if (isset($_POST['login'])) {
    $Email = filter_var(trim($_POST['Email']), FILTER_SANITIZE_EMAIL);
    $Password = $_POST['Password']; // This is the plaintext password entered by the user

    // Input validation
    if (empty($Email)) { array_push($errors, "Email is required"); }
    if (empty($Password)) { array_push($errors, "Password is required"); }

    // reCAPTCHA verification
    if (isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response']) && count($errors) == 0) {
        $recaptcha_response = $_POST['g-recaptcha-response'];

        $recaptcha_url = 'https://www.google.com/recaptcha/api/siteverify';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $recaptcha_url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            'secret' => $recaptcha_secret,
            'response' => $recaptcha_response,
            'remoteip' => $_SERVER['REMOTE_ADDR']
        ]));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);

        if ($curl_error || $http_code != 200) {
            error_log("reCAPTCHA cURL error: " . $curl_error . " HTTP Code: " . $http_code);
            array_push($errors, "reCAPTCHA service error. Please try again.");
        } else {
            $recaptcha = json_decode($response, true);

            if (!$recaptcha || !$recaptcha['success']) {
                error_log("reCAPTCHA verification failed for email: " . $Email . " - Result: " . json_encode($recaptcha));
                array_push($errors, "reCAPTCHA verification failed. Please try again.");
            }
        }
    } elseif (count($errors) == 0) {
        array_push($errors, "Please complete the reCAPTCHA.");
    }


    // Proceed with login if no validation or reCAPTCHA errors
    if (count($errors) == 0 && $db) {
        // Use prepared statement to fetch user
        $stmt = $db->prepare("SELECT ID, Password, Status, Account, Verified FROM users WHERE Email = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param("s", $Email);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $stmt->close(); // Close statement as we have the result

            if ($user) {
                // Verify password using password_verify() against the hashed password from DB
                if (password_verify($Password, $user['Password'])) {
                    // Password matches, now check user status and redirect
                    $_SESSION['Email'] = $Email; // Store email in session

                    // Check Verified status first, as it's a gatekeeper for all other statuses
                    if ($user['Verified'] == 'No') {
                        $_SESSION['success'] = "Please verify your account via email.";
                        header('location: Dashboards/Verify/dashboard.php');
                        exit();
                    }
                    // If verified, then check Status and Account type
                    elseif ($user['Status'] == 'Active' && $user['Account'] == 'User') {
                        $_SESSION['success'] = "You are now logged in.";
                        header('location: Dashboards/Dashboard/dashboard.php');
                        exit();
                    }
                    // Specific check for Admin account
                    elseif ($user['Status'] == 'Active' && $user['Account'] == 'Admin') {
                        $_SESSION['success'] = "Welcome Admin!";
                        header('location: Dashboards/AdminDashboard/dashboard.php'); // Separate admin dashboard
                        exit();
                    }
                    // Suspended accounts
                    elseif ($user['Status'] == 'Suspended' && $user['Account'] == 'Suspended') {
                        $_SESSION['success'] = "Your account is suspended. Please contact support.";
                        header('location: Dashboards/Suspended/dashboard.php');
                        exit();
                    }
                    // New and Verified user, needs profile setup
                    elseif ($user['Status'] == 'New' && $user['Verified'] == 'Yes') {
                        $_SESSION['success'] = "Account verified. Please complete your profile setup.";
                        header('location: Dashboards/ProfileSetup/CreateProfile.php');
                        exit();
                    }
                    // Catch-all for any other unexpected combinations (shouldn't typically be hit if logic is sound)
                    else {
                        error_log("Unexpected user status combination for email: " . $Email . " - Status: " . $user['Status'] . ", Account: " . $user['Account'] . ", Verified: " . $user['Verified']);
                        array_push($errors, "An issue occurred with your account status. Please contact support.");
                    }
                } else {
                    // Password does not match
                    array_push($errors, "Wrong email/password combination.");
                }
            } else {
                // User not found
                array_push($errors, "Wrong email/password combination.");
            }
        } else {
            error_log("Error preparing login statement: " . $db->error);
            array_push($errors, "An internal error occurred. Please try again.");
        }
    }
}
// Close database connection at the end of the script execution if it was successfully opened
if ($db && !$db->connect_error) {
    $db->close();
}
?>